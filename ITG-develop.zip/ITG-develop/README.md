# ITG

#### This project is for Imperial Tobaco (itg) client. The main purpose of the project is to match stamps or any other confirmation singature with those in any kind od documents

---

##### Developer Requirements

1. GitFlow Workflow
2. (WEB Api) .Net Core 2.2
3. NodeJS > 10.9
4. WEB frontend Angular 8 [angular-ngrx-material-starter](https://github.com/tomastrajan/angular-ngrx-material-starter)
