docker run --rm \
--publish=2223:22 \
-v itg_smart-data1:/smart \
-v itg_itg-share1:/share1 \
--env ROOT_PASSWORD=MyRootPW123 \
plkrcon23q1:8083/itg/drakon/dotnet_mc
#drakon/dotnet_mc
#plkrcon23q1:8083/itg/drakon/mc
