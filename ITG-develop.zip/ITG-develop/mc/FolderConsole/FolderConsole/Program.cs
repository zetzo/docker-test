﻿using System;
using System.IO;
using System.Linq;

namespace FolderConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            string folderPath = @"";
            var invoiceDirectory = new DirectoryInfo(folderPath).GetDirectories().Where(directory => directory.Name.Equals("Listing Invoice & Recipts Processing")).Single();

            foreach (var file in invoiceDirectory.GetFiles())
            {
                Console.WriteLine(file.FullName);
            }
        }
    }
}
