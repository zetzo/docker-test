﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Web.Api.Data.Extensions;
using Web.Api.Data.Infrastructure;
using Application.Services.Extensions;
using AutoMapper;
using Application.Services.Configuration;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using MediatR;
using System.Reflection;
using Web.Api.Data.EventHandlers;
using Application.Services.Interfaces;
using Application.Services.Services;
using Microsoft.AspNetCore.Authorization;
using Web.Api.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Web.Api.Filters;
using Application.Services;
using Web.Api.Domain.Interfaces;
using Web.Api.Data.Repository;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using Microsoft.OpenApi.Models;
using System.Linq;
using Swashbuckle.AspNetCore.SwaggerUI;
using Web.Api.DTOs.User;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Primitives;
using System.Threading.Tasks;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace Web.Api
{
    public partial class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        private const string enGBCulture = "en-GB";
        private const string AllowSpecificOrigins = "_allowSpecificOrigins";

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var origins = new List<string>();
            Configuration.GetSection("CorsOrigins").Bind(origins);

            services.AddCors(options =>
            {
                options.AddPolicy(AllowSpecificOrigins,
                builder =>
                {
                    builder.WithOrigins(origins.ToArray())
                           .AllowAnyHeader()
                           .AllowAnyMethod();
                });
            });
            services.AddMvc(options =>
            {
                options.AllowEmptyInputInBodyModelBinding = true;
                options.Filters.Add(typeof(HttpGlobalExceptionFilter));
            }).SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            services.AddNHibernate(Configuration.GetConnectionString("ITG_DB"));            
            services.Configure<EndpointsConfiguration>(Configuration.GetSection("Endpoints"));
            services.Configure<PatternExtractTaskConfiguration>(Configuration.GetSection("Smart:PatternExtractTask"));
            services.Configure<PatternActionConfiguration>(Configuration.GetSection("PatternAction"));
            services.Configure<IBMIdConfiguration>(Configuration.GetSection("IBMID"));


            services.Configure<MinioStorageConfiguration>(Configuration.GetSection("MinioStorage"));
            services.AddMinioWrapper(Configuration);
            services.AddPatternService();
            services.AddMatchingService();
            services.AddContractService();
            services.AddUserService();
            services.AddDomainEventsService();
            services.AddResponseCaching();
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddAutoMapper(typeof(Startup));
            services.AddMediatR(typeof(LogEntryEventHandler).GetTypeInfo().Assembly);
            services.AddScoped<IMediator, Mediator>();
            services.AddSingleton<IAuthorizationPolicyProvider, AuthorizationPolicyProvider>();
            services.AddScoped<SmartIngestService>();
            services.AddScoped<IInfoRepository, InfoRepository>();
            services.AddScoped<IInfoService, InfoService>();
            services.AddScoped<IPageExtractRepository, PageExtractRepository>();
            services.AddScoped<IInnContractRepository, InnContractRepository>();
            services.AddScoped<IPageCutRepository, PageCutRepository>();
            services.AddScoped<IPatternImportRepository, PatternImportRepository>();
            services.AddScoped<IPatternImportLogRespository, PatternImportLogRespository>();
            services.AddScoped<IAuthorizationHandler, PermissionHandler>();
            services.AddScoped<IGetClaimsProvider, GetClaimsProvider>();
            services.Configure<TokenManagementConfiguration>(Configuration.GetSection("TokenManagement"));
            var token = Configuration.GetSection("TokenManagement").Get<TokenManagementConfiguration>();
            var secret = Encoding.ASCII.GetBytes(token.Secret);


            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Smart Application API", Version = "v1" });                
                c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
                c.DocumentFilter<ShowInSwaggerFilter>();
                c.AddSecurityDefinition("ApiKeyAuth", new OpenApiSecurityScheme()
                {
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = XAPIKeyAuthentication.XAPIKEY,
                    Description = "Insert API Key to access this API",
                    In = ParameterLocation.Header,
                    Name = XAPIKeyAuthentication.XAPIKEY,
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference {
                                Type = ReferenceType.SecurityScheme,
                                Id = "ApiKeyAuth" }
                        }, new List<string>() }
                });
            });

            services.Configure<XAPIKeyAuthenticationConfiguration>(Configuration.GetSection("XAPIKeyAuthentication"));
            
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;                
            }).AddJwtBearer(x =>
            {
                x.RequireHttpsMetadata = false;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(token.Secret)),
                    ValidIssuer = token.Issuer,
                    ValidAudience = token.Audience,
                    ValidateIssuer = false,
                    ValidateAudience = false
                };
            }).AddScheme<AuthenticationSchemeOptions, XAPIKeyAuthenticationHandler>(XAPIKeyAuthentication.XAPIKEY, null);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            //app.UseExceptionHandler("/error");
            app.UseCors(AllowSpecificOrigins);
            app.UseAuthentication();
            app.UseResponseCaching();
            app.UseHttpsRedirection();
            app.UseMvc();

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Smart Application API");
            });
        }
    }

    public class XAPIKeyAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        private readonly IOptions<XAPIKeyAuthenticationConfiguration> _XAPIKeyAuthenticationOptions;
        public XAPIKeyAuthenticationHandler(IOptions<XAPIKeyAuthenticationConfiguration> XAPIKeyAuthenticationOptions, IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger,
            UrlEncoder encoder, ISystemClock clock) : base(options, logger, encoder, clock)
        {
            _XAPIKeyAuthenticationOptions = XAPIKeyAuthenticationOptions;
        }

        protected override Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            if (Request.Headers.TryGetValue(XAPIKeyAuthentication.XAPIKEY, out StringValues values))
            {
                string xApiKeyValue = values.ToString();

                if (xApiKeyValue == _XAPIKeyAuthenticationOptions.Value.XAPIKEY)
                    return CreatePrincipal(_XAPIKeyAuthenticationOptions.Value.UserName);

                return Task.FromResult(AuthenticateResult.Fail(XAPIKeyAuthentication.Wrong_XAPIKEY));
            }

            return Task.FromResult(AuthenticateResult.Fail(XAPIKeyAuthentication.XAPIKEY_Missing));
        }

        private Task<AuthenticateResult> CreatePrincipal(string nameIdentifier)
        {
            var claims = new[] {
                        new Claim(ClaimTypes.NameIdentifier, nameIdentifier)};
            var identity = new ClaimsIdentity(claims, Scheme.Name);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);

            return Task.FromResult(AuthenticateResult.Success(ticket));
        }
    }

    public class XAPIKeyAuthenticationConfiguration
    {
        public string XAPIKEY { get; set; }
        public string UserName { get; set; }
    }

    //Only for static data
    public sealed class XAPIKeyAuthentication
    {
        public const string XAPIKEY = "X-API-KEY";
        public const string Wrong_XAPIKEY = "Wrong X-API-KEY";
        public const string XAPIKEY_Missing = "X-API-KEY missing";
        private XAPIKeyAuthentication() { }
    }
}
