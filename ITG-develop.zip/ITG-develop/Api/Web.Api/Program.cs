﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Application.Services;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Core;
using Serilog.Events;
using Serilog.Sinks.Elasticsearch;

namespace Web.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {

            var configuration = new ConfigurationBuilder()
                   .AddJsonFile("appsettings.json")
                   .Build();

            //Log.Logger = new LoggerConfiguration()
            //       .ReadFrom.Configuration(configuration)
            //       .CreateLogger();
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseSerilog()
                .UseStartup<Startup>()
                .ConfigureKestrel((context, serverOptions) =>
                {
                    serverOptions.Configure(context.Configuration.GetSection("Kestrel"));
                }).UseSerilog((hostingContext, logging) => {
                    logging.ReadFrom.Configuration(hostingContext.Configuration);

                    KibanaConfiguration kibanaConfiguration = new KibanaConfiguration();
                    var kibanaSection = hostingContext.Configuration.GetSection("Kibana");
                    kibanaSection.Bind(kibanaConfiguration);

                    if (kibanaSection.Exists())
                    {
                        logging.WriteTo.Elasticsearch(new ElasticsearchSinkOptions(new Uri(kibanaConfiguration.Uri))
                        {
                            MinimumLogEventLevel = Enum.Parse<Serilog.Events.LogEventLevel>(kibanaConfiguration.MinimumLevel, true),
                            AutoRegisterTemplate = kibanaConfiguration.AutoRegisterTemplate,
                            ModifyConnectionSettings = x => x.BasicAuthentication(kibanaConfiguration.User, kibanaConfiguration.Password).ServerCertificateValidationCallback((o, certificate, arg3, arg4) =>
                            {
                                return true;
                            }),
                            BatchPostingLimit = kibanaConfiguration.BatchPostingLimit,
                            QueueSizeLimit = kibanaConfiguration.QueueSizeLimit,
                            IndexFormat = kibanaConfiguration.IndexFormat,
                            AutoRegisterTemplateVersion = Enum.Parse<AutoRegisterTemplateVersion>(kibanaConfiguration.AutoRegisterTemplateVersion, true),
                            FailureCallback = e => Console.WriteLine("Unable to submit event " + e.MessageTemplate),
                            EmitEventFailure = EmitEventFailureHandling.WriteToSelfLog |
                                               EmitEventFailureHandling.WriteToFailureSink |
                                               EmitEventFailureHandling.RaiseCallback,
                        });
                    }
                });
    }
}
