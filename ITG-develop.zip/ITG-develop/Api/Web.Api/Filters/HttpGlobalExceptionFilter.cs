﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using Web.Api.ActionResults;
using Web.Api.Domain.Exceptions;
using Web.Api.DTOs.Error;
using Application.Services.Extensions;
using Application.Services.Exceptions;
using Application.Services;

namespace Web.Api.Filters
{
    public class HttpGlobalExceptionFilter : IExceptionFilter
    {
        private readonly IHostingEnvironment env;
        private readonly ILogger<HttpGlobalExceptionFilter> logger;


        public HttpGlobalExceptionFilter(IHostingEnvironment env, ILogger<HttpGlobalExceptionFilter> logger)
        {
            this.env = env;
            this.logger = logger;
        }

        public void OnException(ExceptionContext context)
        {
            Guid exceptionId = Guid.NewGuid();
            
            var json = JsonErrorResponseBuilder
                        .responses.GetByKeyOrUseDefaultKey(context.Exception.GetType(), typeof(Exception))
                        .Invoke(context.Exception.Message);

            json.SetExceptionId(exceptionId);

            logger.LogErrorDetail(context.Exception, context.Exception.Dump());

            if (env.IsDevelopment())
            {
                json.DeveloperMessage = context.Exception;
            }

            context.Result = new InternalServerErrorObjectResult(json);
            context.HttpContext.Response.StatusCode =
                        JsonErrorResponseBuilder
                                .statusCodes
                                .GetByKeyOrUseDefaultKey(context.Exception.GetType(), typeof(Exception));

            context.ExceptionHandled = true;
        }

        private class JsonErrorResponse
        {
            public string[] Messages { get; private set; }

            public object DeveloperMessage { get; set; }

            public ErrorTypeEnum CustomErrorCode { get; private set; }

            public Guid ExceptionId { get; private set; }

            private JsonErrorResponse() { }

            private JsonErrorResponse(string[] messages, ErrorTypeEnum customErrorCode) 
            {
                Messages = messages;
                CustomErrorCode = customErrorCode;
            }

            public static JsonErrorResponse Create(string[] messages, ErrorTypeEnum customErrorCode)
            {
                return new JsonErrorResponse(messages, customErrorCode);
            }

            public void SetExceptionId(Guid id)
            {
                ExceptionId = id;
            }
        }

        private static class JsonErrorResponseBuilder
        {
            private static Func<string, JsonErrorResponse> unauthorized = msg => JsonErrorResponse.Create(new string[] { "Unauthorized Error", msg }, ErrorTypeEnum.Unauthorized);
            private static Func<string, JsonErrorResponse> dbError = msg => JsonErrorResponse.Create(new string[] { "Database Connection Failed", msg }, ErrorTypeEnum.DatabaseConnFailed);
            private static Func<string, JsonErrorResponse> internalServerError = msg => JsonErrorResponse.Create(new string[] { "Internal Server Error", msg }, ErrorTypeEnum.InternalServerError);
            private static Func<string, JsonErrorResponse> fileNotFound = msg => JsonErrorResponse.Create(new string[] { "File Not Found", msg }, ErrorTypeEnum.FileNotExist);
            private static Func<string, JsonErrorResponse> directoryNotFound = msg => JsonErrorResponse.Create(new string[] { "Directory Not Found", msg }, ErrorTypeEnum.DirectoryNotExist);
            private static Func<string, JsonErrorResponse> patternContentNotFound = msg => JsonErrorResponse.Create(new string[] { "Pattern Content Not Found", msg }, ErrorTypeEnum.PatternContentNotFound);

            public static Dictionary<Type, Func<string, JsonErrorResponse>> responses =
                new Dictionary<Type, Func<string, JsonErrorResponse>>()
                {
                    { typeof(UnauthorizedException), unauthorized },
                    { typeof(DatabaseConnectionFailedException), dbError },
                    { typeof(FileNotExistException), fileNotFound },
                    { typeof(DirectoryNotExistException), directoryNotFound },
                    { typeof(PatternContentNotFoundException), patternContentNotFound },
                    { typeof(Exception), internalServerError }
                };

            public static Dictionary<Type, int> statusCodes =
                new Dictionary<Type, int>()
                {
                    { typeof(UnauthorizedException), 401 },
                    { typeof(DatabaseConnectionFailedException), 500 },
                    { typeof(FileNotExistException), 404 },
                    { typeof(DirectoryNotExistException), 404 },
                    { typeof(PatternContentNotFoundException), 404 },
                    { typeof(Exception), 500 }
                };
        }
    }
}
