﻿using Application.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models.Roles;

namespace Web.Api.Authorization
{
    public class PermissionHandler : AuthorizationHandler<PermissionRequirement>
    {
        private readonly IGetClaimsProvider _claimsProvider;
        public PermissionHandler(IGetClaimsProvider claimsProvider)
        {
            _claimsProvider = claimsProvider;
        }
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionRequirement requirement)
        {
            var permissionsClaims = _claimsProvider.Permissions;

            if (permissionsClaims == null || !permissionsClaims.Any())
                return Task.CompletedTask;

            if (permissionsClaims.Contains((Permissions)Enum.Parse(typeof(Permissions), requirement.PermissionName)))
                context.Succeed(requirement);

            return Task.CompletedTask;
        }
    }
}
