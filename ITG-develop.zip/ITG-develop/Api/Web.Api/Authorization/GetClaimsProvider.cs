﻿using Application.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models.Roles;

namespace Web.Api.Authorization
{
    public class GetClaimsProvider : IGetClaimsProvider
    {
        public virtual string UserId { get; private set; }
        public virtual IEnumerable<Permissions> Permissions { get; private set; }

        public GetClaimsProvider(IHttpContextAccessor accessor)
        {
            UserId = accessor.HttpContext?.User.Claims.SingleOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            var permissions = accessor.HttpContext?.User.Claims.Where(x => x.Type == ClaimTypes.Role)?.Select(x => x.Value.UnpackPermissionsFromString()) ?? null;

            if (permissions != null)
            {
                var permissionList = new List<Permissions>();
                foreach (var list in permissions)
                {
                    permissionList = permissionList.Union(list).ToList();
                }
                Permissions = permissionList;
            }
        }
    }
}
