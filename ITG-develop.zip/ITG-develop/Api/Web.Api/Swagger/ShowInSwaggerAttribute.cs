﻿using System;

namespace Web.Api
{
    public partial class Startup
    {
        [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
        public class ShowInSwaggerAttribute : Attribute
        {

        }
    }  
}
