﻿using System.Reflection;
using Microsoft.OpenApi.Models;
using System.Linq;
using Swashbuckle.AspNetCore.SwaggerGen;
using Microsoft.AspNetCore.Mvc.Controllers;

namespace Web.Api
{
    public partial class Startup
    {
        public class ShowInSwaggerFilter : IDocumentFilter
        {
            public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
            {
                FixScoringDTOSchema(swaggerDoc);

                foreach (var contextApiDescription in context.ApiDescriptions)
                {
                    var actionDescriptor = (ControllerActionDescriptor)contextApiDescription.ActionDescriptor;

                    if (actionDescriptor.ControllerTypeInfo.GetCustomAttributes<ShowInSwaggerAttribute>().Any() ||
                        actionDescriptor.MethodInfo.GetCustomAttributes<ShowInSwaggerAttribute>().Any())
                    {
                        continue;
                    }
                    else
                    {
                        var key = "/" + contextApiDescription.RelativePath.TrimEnd('/');
                        var pathItem = swaggerDoc.Paths[key];
                        if (pathItem == null)
                            continue;

                        switch (contextApiDescription.HttpMethod.ToUpper())
                        {
                            case "GET":
                                pathItem.Operations[OperationType.Get] = null;
                                break;
                            case "POST":
                                pathItem.Operations[OperationType.Post] = null;
                                break;
                            case "PUT":
                                pathItem.Operations[OperationType.Put] = null;
                                break;
                            case "DELETE":
                                pathItem.Operations[OperationType.Delete] = null;
                                break;
                        }

                        if (pathItem.Operations.All(x => x.Value == null))
                            swaggerDoc.Paths.Remove(key);
                    }
                }
            }

            //TOOD Please someone refactor this someday
            private void FixScoringDTOSchema(OpenApiDocument swaggerDoc)
            {
                var copy = swaggerDoc.Components.Schemas.Where(x => x.Key == "ScoringDTO").First();
                swaggerDoc.Components.Schemas.Clear();
                swaggerDoc.Components.Schemas.Add(copy);

            }
        }
    }  
}
