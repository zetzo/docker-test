﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;
using Web.Api.Domain.ValueObjects;
using Web.Api.Dtos;

namespace Web.Api.Mappings
{
    public class PatternProfile : Profile
    {
        public PatternProfile()
        {
            CreateMap<Pattern, PatternDTO>()
                .ForMember(x => x.Id, opt => opt.MapFrom(map => map.Id))
                .ForMember(x => x.ContractId, opt => opt.MapFrom(map => map.ContractId))
                .ForMember(x => x.ImageHash, opt => opt.MapFrom(map => map.EntityId))
                .ForMember(x => x.ImageType, opt => opt.MapFrom(map => map.ContentType.Extension))
                .ForMember(x => x.Description, opt => opt.MapFrom(map => map.Description))
                .ForMember(x => x.FileName, opt => opt.MapFrom(map => map.ImportFileName))
                .ForMember(x => x.ImportDate, opt => opt.MapFrom(map => map.ImportDate))
                .ForMember(x => x.CreationDate, opt => opt.MapFrom(map => map.CreationDate))
                .ForMember(x => x.Age, opt => opt.MapFrom(map => map.Age))
                .ForMember(x => x.Status, opt => opt.MapFrom(map => Enum.Parse(typeof(PatternStatusEnum), map.Status)))
                .ForMember(x => x.Icon, opt => opt.MapFrom(map => Convert.ToBase64String(map.Icon)))
                .ForMember(x => x.ImageData, opt => opt.Ignore());

            CreateMap<PatternDTO, Pattern>()
                .ForMember(x => x.Id, opt => opt.Ignore())
                .ForMember(x => x.ContractId, opt => opt.MapFrom(map => map.ContractId))
                .ForMember(x => x.EntityId, opt => opt.Ignore())
                .ForMember(x => x.ImportFileName, opt => opt.MapFrom(map => map.FileName))
                .ForMember(x => x.ImportDate, opt => opt.MapFrom(map => map.ImportDate))
                .ForMember(x => x.CreationDate, opt => opt.MapFrom(map => map.CreationDate))
                .ForMember(x => x.ContentType, opt => opt.MapFrom(map => PatternContentType.CreateNewByExtension(map.ImageType)))
                .ForMember(x => x.Status, opt => opt.MapFrom(map => map.Status.ToString()))
                .ForMember(x => x.Age, opt => opt.Ignore());

            CreateMap<PatternContent, PatternDTO>()
                .ForMember(x => x.ImageData, opt => opt.MapFrom(map => Convert.ToBase64String(map.Value)))
                .ForMember(x => x.Id, opt => opt.Ignore())
                .ForMember(x => x.ContractId, opt => opt.Ignore())
                .ForMember(x => x.ImageHash, opt => opt.Ignore())
                .ForMember(x => x.ImageType, opt => opt.Ignore())
                .ForMember(x => x.Description, opt => opt.Ignore())
                .ForMember(x => x.FileName, opt => opt.Ignore());
        }
    }
}
