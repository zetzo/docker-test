﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.DomainEvent;
using Web.Api.Domain.Models.Roles;
using Web.Api.DTOs.Log;
using Web.Api.DTOs.Role;
using Web.Api.DTOs.User;

namespace Web.Api.Mappings
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<User, UserDTOForCreation>();
            CreateMap<UserDTOForCreation, User>();

            CreateMap<User, UserDTO>()
                .ForMember(x => x.FirstName, opt => opt.MapFrom(map => map.FirstName))
                .ForMember(x => x.LastName, opt => opt.MapFrom(map => map.LastName))
                .ForMember(x => x.Username, opt => opt.MapFrom(map => map.Username))
                .ForMember(x => x.Username, opt => opt.MapFrom(map => map.Username))
                .ForMember(x => x.Roles, opt => opt.MapFrom(map => map.Roles))
                .ForMember(x => x.IsAdmin, opt => opt.MapFrom(map => map.IsAdmin))
                .ForMember(x => x.IsConfirmed, opt => opt.MapFrom(map => map.IsConfirmed));

            CreateMap<Role, RoleDTO>()
                .ForMember(x => x.Id, opt => opt.MapFrom(map => map.Id))
                .ForMember(x => x.Name, opt => opt.MapFrom(map => map.Name))
                .ForMember(x => x.Description, opt => opt.MapFrom(map => map.Description))
                .ForMember(x => x.IsActive, opt => opt.MapFrom(map => map.IsActive))
                .ForMember(x => x.Permissions, opt => opt.MapFrom(map => PermissionToPermissionDTO(PermissionPackers.UnpackPermissionsFromString(map.AggregatedPermissionList))));

            CreateMap<RoleDTO, Role>()
                .ForMember(x => x.Id, opt => opt.MapFrom(map => map.Id))
                .ForMember(x => x.Name, opt => opt.MapFrom(map => map.Name))
                .ForMember(x => x.Description, opt => opt.MapFrom(map => map.Description))
                .ForMember(x => x.IsActive, opt => opt.MapFrom(map => map.IsActive))
                .ForMember(x => x.AggregatedPermissionList, opt => opt.MapFrom(map => map.Permissions.Select(k => k.Id).PackPermissionsIntoString()));

            CreateMap<IEnumerable<Permissions>, List<PermissionDTO>>()
                .ConstructUsing(x => PermissionToPermissionDTO(x));

            CreateMap<List<PermissionDTO>, IEnumerable<Permissions>>()
                .ConstructUsing(x => x.Select(k => k.Id));

            CreateMap<LogEntry, LogEntryDTO>()
                .ForMember(x => x.Id, opt => opt.MapFrom(map => map.Id))
                .ForMember(x => x.DateCreated, opt => opt.MapFrom(map => map.DateCreated))
                .ForMember(x => x.DomainType, opt => opt.MapFrom(map => map.DomainModelType))
                .ForMember(x => x.ActionType, opt => opt.MapFrom(map => map.ActionType))
                .ForMember(x => x.ActionResult, opt => opt.MapFrom(map => map.ActionResult))
                .ForMember(x => x.RelatedObjectId, opt => opt.MapFrom(map => map.RelatedObjectId))
                .ForMember(x => x.Message, opt => opt.MapFrom(map => map.Message))
                .ForMember(x => x.UserId, opt => opt.MapFrom(map => map.UserId));
        }

        private List<PermissionDTO> PermissionToPermissionDTO(IEnumerable<Permissions> permissions)
        {
            return permissions.Select(x => new PermissionDTO()
            {
                Id = x,
                Name = typeof(Permissions).GetMember(x.ToString())[0].GetCustomAttribute<DisplayAttribute>().GroupName + " " +
                       typeof(Permissions).GetMember(x.ToString())[0].GetCustomAttribute<DisplayAttribute>().Name,
                Description = typeof(Permissions).GetMember(x.ToString())[0].GetCustomAttribute<DisplayAttribute>().Description
            }).ToList();
        }
    }
}
