﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Web.Api.Domain.Dtos;
using Web.Api.Domain.Models;

namespace Web.Api.Mappings
{
    public class MatchingProfile : Profile
    {
        public MatchingProfile()
        {
            CreateMap<MatchingResult, ScoringDTO>();               
        }
    }
}
