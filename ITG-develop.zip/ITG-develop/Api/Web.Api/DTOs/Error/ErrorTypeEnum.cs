﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Api.DTOs.Error
{
    public enum ErrorTypeEnum
    {
        DatabaseConnFailed = 1000,
        Unauthorized = 1001,
        IncorrectCredencial = 1002,
        UserNotConfirmed = 1003,
        FileNotExist = 1004,
        DirectoryNotExist = 1005,
        PatternContentNotFound = 1006,
        InternalServerError = 1099
    }
}
