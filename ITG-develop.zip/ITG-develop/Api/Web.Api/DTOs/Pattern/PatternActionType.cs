﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Api.DTOs.Pattern
{
    public enum PatternActionType
    {
        ConstrastAdjust,
        ImageCrop
    }
}
