﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Dtos
{
    public class PatternDTO
    {
        public long Id { get; set; }
        public string ContractId { get; set; }
        public string ImageData { get; set; }
        public string ImageHash { get; set; }
        public string ImageType { get; set; }
        public string Description { get; set; }
        public string FileName { get; set; }
        public DateTime ImportDate { get; set; }
        public DateTime CreationDate { get; set; }
        public int Age { get; set; }
        public PatternStatusEnum Status { get; set; }
        public string Icon { get; set; }
    }
}
