﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Api.DTOs.Pattern
{
    public class PatternFilterRequest
    {
        public List<PatternFilter> Filters { get; set; }
    }

    public class PatternFilter
    {
        public int Id { get; set; }
        public string Property { get; set; }
        public string FilterType { get; set; }
        public string Value1 { get; set; }
        public string Value2 { get; set; }
    }
}
