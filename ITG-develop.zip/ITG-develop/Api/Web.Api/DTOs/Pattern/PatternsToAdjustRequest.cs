﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Api.DTOs.Pattern
{
    public class PatternsToAdjustRequest
    {
        public IEnumerable<long> PatternIds { get; set; }
        public PatternActionType ActionType { get; set; }
    }
}
