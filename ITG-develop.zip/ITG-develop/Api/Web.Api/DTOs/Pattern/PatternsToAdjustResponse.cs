﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.DTOs.Pattern
{
    public class PatternsToAdjustResponse
    {
        public PatternActionType ActionType { get; set; }
        public IEnumerable<PatternImageRefitted> Patterns { get; set; }
    }
}
