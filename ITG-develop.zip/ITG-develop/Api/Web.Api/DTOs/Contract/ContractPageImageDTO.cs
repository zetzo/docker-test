﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.DTOs.Contract
{
    public class ContractPageImageDTO
    {
        public int Height { get; set; }
        public int Width { get; set; }
        public int PageNumber { get; set; }
        public string Content { get; set; }
    }
}
