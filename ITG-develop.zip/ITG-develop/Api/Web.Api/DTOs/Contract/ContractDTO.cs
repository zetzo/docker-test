﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.DTOs.Contract
{
    public class ContractDTO
    {
        public string ContractCode { get; set; }
        public IEnumerable<ContractPageImageDTO> Pages { get; set; }
    }
}
