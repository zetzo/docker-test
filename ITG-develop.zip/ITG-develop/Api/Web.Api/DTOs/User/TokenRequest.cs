﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.DTOs.User
{
    public class TokenRequest
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
