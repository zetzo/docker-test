﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.DTOs.User
{
    public class UserMessageDTO
    {
        public string Message { get; set; }
        public string Details { get; set; }
    }
}
