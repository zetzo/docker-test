﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models.Roles;

namespace Web.Api.DTOs.Role
{
    public class PermissionDTO
    {
        public string Name { get; set; }
        public Permissions Id { get; set; }
        public string Description { get; set; }
    }
}
