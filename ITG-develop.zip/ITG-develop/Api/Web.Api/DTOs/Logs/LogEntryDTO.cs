﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Api.DTOs.Log
{
    public class LogEntryDTO
    {
        public int Id { get; set; }
        public DateTime DateCreated { get; set; }
        public string DomainType { get; set; }
        public string ActionType { get; set; }
        public string ActionResult { get; set; }
        public int? RelatedObjectId { get; set; }
        public string Message { get; set; }
        public int UserId { get; set; }
    }
}
