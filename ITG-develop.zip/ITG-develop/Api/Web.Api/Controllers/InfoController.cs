﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web.Api.Domain.Models;
using Web.Api.DTOs.User;

namespace Web.Api.Controllers
{
    //[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class InfoController : BaseController
    {
        private readonly IInfoService _infoService;
        public InfoController(IInfoService infoService)
        {
            _infoService = infoService;
        }

        [HttpGet("versions/{number}")]
        public async Task<IActionResult> GetVersionInfo(int number)
        {
            var result = await _infoService.GetLatestVersionInfo(number);

            return FromResult<IEnumerable<VersionInfo>>(result);
        }

        [HttpGet("messages/{number}")]
        public async Task<IActionResult> GetMessages(int number)
        {
            var result = await _infoService.GetLatestUserMessages(number);

            return FromResult<IEnumerable<MessageForUsers>>(result);
        }

        [HttpPost("messages")]
        public async Task<IActionResult> CreateUserMessage([FromBody] UserMessageDTO userMessageDTO)
        {
            if (userMessageDTO == null)
                return BadRequest("User message cannot be null");

            var message = new MessageForUsers()
            {
                DateCreated = DateTime.UtcNow,
                Message = userMessageDTO.Message,
                Details = userMessageDTO.Details
            };

            await _infoService.CreateUserMessage(message);

            return Ok(true);
        }
    }
}
