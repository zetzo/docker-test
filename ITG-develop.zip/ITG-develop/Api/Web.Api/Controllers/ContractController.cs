﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Application.Services.Interfaces;
using Application.Services.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web.Api.Authorization;
using Web.Api.Domain.Models.Roles;
using Web.Api.DTOs.Contract;

namespace Web.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Obsolete]
    public class ContractController : BaseController
    {
        private readonly IContractService _contractService;
        public ContractController(IContractService contractService)
        {
            _contractService = contractService;
        }

        [HttpPost("split")]
        [HasPermission(Permissions.PatternCreate)]
        public async Task<IActionResult> SplitContractPdfToImages([FromForm(Name = "contract")] IFormFile file)
        {
            byte[] pdfBytes;
            string pdfBase64 = "";

            if (file.Length > 0)
            {
                using (var memoryStream = new MemoryStream())
                {
                    await file.CopyToAsync(memoryStream);
                    pdfBytes = memoryStream.ToArray();
                    pdfBase64 = Convert.ToBase64String(pdfBytes);
                }
            }

            if (string.IsNullOrEmpty(pdfBase64))
                return BadRequest("Failed to convert PDF file to base64.");

            var result = await _contractService.SplitPdfIntoImages(new ContractPdfRequest() { Content = pdfBase64 });

            if (result.IsSuccess)
            {
                var contractDTO = new ContractDTO()
                {
                    ContractCode = _contractService.CutOutContractCodeFromFileName(file.FileName),
                    Pages = result.Value.Result.Pages.Select(x => new ContractPageImageDTO()
                    {
                        Height = x.Height,
                        Width = x.Width,
                        PageNumber = x.PageNumber,
                        Content = x.Content
                    })
                };

                return Ok<ContractDTO>(contractDTO);
            }

            return FromResult(result);
        }
    }
}
