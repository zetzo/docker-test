﻿using Application.Services;
using Application.Services.Interfaces;
using Application.Services.ViewModels;
using AutoMapper;
using CSharpFunctionalExtensions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Mime;
using System.Threading.Tasks;
using Web.Api.Authorization;
using Web.Api.Domain.Exceptions;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Paging;
using Web.Api.Domain.Models.PatternActions;
using Web.Api.Domain.Models.Roles;
using Web.Api.Dtos;
using Web.Api.DTOs;
using Web.Api.DTOs.Contract;
using Web.Api.DTOs.Pattern;

namespace Web.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PatternsController : BaseController
    {
        private readonly IPatternService _patternService;
        private readonly SmartIngestService _smartIngestService;
        private readonly IMapper _mapper;
        private readonly ILogger<PatternsController> _logger;

        public PatternsController(IPatternService patternService, SmartIngestService smartIngestService,  IMapper mapper, ILogger<PatternsController> logger)
        {
            _patternService = patternService;
            _smartIngestService = smartIngestService;
            _mapper = mapper;
            _logger = logger;
        }
       
        [HttpGet("{sha256}")]
        [HasPermission(Permissions.PatternRead)]
        [ResponseCache(Duration = 3600, Location = ResponseCacheLocation.Client)]
        public async Task<IActionResult> GetPatternFile(string sha256)
        {
            var result = await _patternService.GetPatternContent(sha256);

            if (result.IsSuccess)
                return File(result.Value.Content, result.Value.ContentType);

            return NotFound();
        }

        [HttpGet("{sha256}/base64")]
        [HasPermission(Permissions.PatternRead)]
        [ResponseCache(Duration = 3600, Location = ResponseCacheLocation.Client)]
        public async Task<IActionResult> GetPatternContent(string sha256)
        {
            var result = await _patternService.GetPatternContent(sha256);

            if (result.IsFailure)
                throw new PatternContentNotFoundException(result.Error);

            return Ok(Convert.ToBase64String(result.Value.Content));
        }

        [HttpGet("index")]
        [HasPermission(Permissions.PatternRead)]
        public async Task<IActionResult> GetPatterns(int pageIndex, int pageSize)
        {
            PagedResult<Pattern> patterns = await _patternService.GetPagedAsync(pageIndex, pageSize);

            IEnumerable<PatternContent> patternContents =
                await _patternService.GetMultiplePatternContent(patterns.Results.Select(x => x.EntityId).ToArray());

            IEnumerable<PatternDTO> patternDtos =
                patterns.Results.SelectMany(pattern => patternContents.Where(x => x.Key == pattern.EntityId),
                (p, c) =>
                {
                    var patternMap = _mapper.Map<Pattern, PatternDTO>(p);
                    return _mapper.Map<PatternContent, PatternDTO>(c, patternMap);
                }
            );

            PagedResult<PatternDTO> result = new PagedResult<PatternDTO>()
            {
                CurrentPage = patterns.CurrentPage,
                PageCount = patterns.PageCount,
                PageSize = patterns.PageSize,
                RowCount = patterns.RowCount,
                Results = patternDtos.ToList()
            };

            return Ok(result);
        }

        [HttpPost("search/{pageIndex}/{pageSize}")]
        [HasPermission(Permissions.PatternRead)]
        public async Task<IActionResult> GetPatterns(int pageIndex, int pageSize, [FromBody] PatternFilterRequest filters)
        {
            var filterList = filters?.Filters == null
                ? new List<FilterModel>()
                : filters.Filters.Select(x => new FilterModel() { PropertyName = x.Property, Operator = (OperatorEnum)Enum.Parse(typeof(OperatorEnum), x.FilterType), Value = x.Value1, Value2 = x.Value2 }).ToList();

            PagedResult<Pattern> patterns = await _patternService.GetPagedAsync(pageIndex, pageSize, filterList);

            var patternDtos = _mapper.Map<IEnumerable<Pattern>, IEnumerable<PatternDTO>>(patterns.Results);

            PagedResult<PatternDTO> result = new PagedResult<PatternDTO>()
            {
                CurrentPage = patterns.CurrentPage,
                PageCount = patterns.PageCount,
                PageSize = patterns.PageSize,
                RowCount = patterns.RowCount,
                Results = patternDtos.ToList()
            };

            return Ok(result);
        }

        [HttpPost]
        [HasPermission(Permissions.PatternCreate)]
        public async Task<IActionResult> CreatePattern([FromBody] PatternDTO patternDTO)
        {
            if (patternDTO == null)
            {
                return BadRequest();
            }

            var pattern = _mapper.Map<Pattern>(patternDTO);

            Result result = await _patternService.AddNewPattern(pattern, patternDTO.ImageData, GetUserId());

            return FromResult(result);
        }

        [HttpDelete]
        [HasPermission(Permissions.PatternDelete)]
        public async Task<IActionResult> DeletePattern(string entityId)
        {
            Result result = await _patternService.DeletePattern(entityId, GetUserId());

            if (result.IsSuccess)
                return FromResult(await _patternService.DeletePatternContent(entityId));

            return FromResult(result);
        }

        [HttpPut("{id}")]
        [HasPermission(Permissions.PatternUpdate)]
        public async Task<IActionResult> UpdatePattern([FromRoute] long id, [FromBody] PatternDTO patternDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (id != patternDTO.Id)
                return BadRequest();
            
            Result<Pattern> patternCurrent = await _patternService.GetPatternById(id);

            if (patternCurrent.IsFailure)
                return FromResult(patternCurrent);

            Pattern patternNew = _mapper.Map<Pattern>(patternDTO);
            var userId = GetUserId();

            var result =
                await _patternService.UpdatePattern(patternCurrent.Value, patternNew.ContractId, patternNew.INN,
                                       patternNew.Description, patternNew.EntityId, patternNew.ImportFileName, patternDTO.ImageData, patternNew.Status, userId);
            
            if(patternDTO.Status == PatternStatusEnum.Confirmed)
            {
                await _smartIngestService.SetPatternToImportByContractId(patternDTO.ContractId, string.Empty, PatternStatusEnum.Confirmed);
            }
            
            if (result.IsSuccess)
            {
                var pattern = await _patternService.GetPatternById(id);
                return Ok(_mapper.Map<Pattern, PatternDTO>(pattern.Value));
            }

            return FromResult(result);
        }

        [HttpPost("adjust")]
        [HasPermission(Permissions.PatternUpdate)]
        public async Task<IActionResult> AdjustPatternImage([FromBody] PatternsToAdjustRequest patterns)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            Result<PatternsToAdjustResponse> result;

            switch (patterns.ActionType)
            {
                case PatternActionType.ConstrastAdjust:
                    result = await _patternService.AdjustContrast(patterns.PatternIds)
                        .Map<IEnumerable<PatternImageRefitted>, PatternsToAdjustResponse>
                                (x => new PatternsToAdjustResponse() { ActionType = PatternActionType.ConstrastAdjust, Patterns = x });
                    
                    break;
                case PatternActionType.ImageCrop:
                    result = await _patternService.CropImage(patterns.PatternIds)
                        .Map<IEnumerable<PatternImageRefitted>, PatternsToAdjustResponse>
                                (x => new PatternsToAdjustResponse() { ActionType = PatternActionType.ImageCrop, Patterns = x });
                    break;
                default:
                    return BadRequest("Action not recognized");
            }

            return FromResult(result);
        }

        [HttpGet("contract/{id}")]
        [HasPermission(Permissions.PatternRead)]
        public async Task<IActionResult> GetPattern(string id)
        {
            var pattern = await _patternService.GetPatternByContractId(id);

            if (pattern.HasValue)
            {
                var content = await _patternService.GetPatternContent(pattern.Value.EntityId);
                var patternDto = _mapper.Map<Pattern, PatternDTO>(pattern.Value);
                patternDto.ImageData = content.IsSuccess ? Convert.ToBase64String(content.Value.Content) : null;

                return Ok(patternDto);
            }
            
            return NotFound();
        }

        [HttpPost("mapping")]
        [HasPermission(Permissions.MappingsCreate)]
        public async Task<IActionResult> UploadMappings([FromForm(Name = "file")] IFormFile file)
        {
            byte[] fileContent;

            if (file.Length > 0)
            {
                using (var memoryStream = new MemoryStream())
                {
                    file.CopyTo(memoryStream);
                    fileContent = memoryStream.ToArray();
                }

                var result = await _patternService.AddMappingFile(fileContent, "global", "CONTRACTS_LS_INN.XLS");
                if (result.IsFailure)
                    return BadRequest(result.Error);

                return Ok();
            }

            return BadRequest("Empty File Sent");            
        }
    }
}