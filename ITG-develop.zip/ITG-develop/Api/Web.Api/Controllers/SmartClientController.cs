﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Services;
using Application.Services.Interfaces;
using AutoMapper;
using CSharpFunctionalExtensions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using Web.Api.Domain.Dtos;
using Web.Api.Domain.Models;
using static Web.Api.Startup;

namespace Web.Api.Controllers
{
    [Route("api/smart")]
    [ApiController]
    [ShowInSwagger]
    [Authorize(AuthenticationSchemes = XAPIKeyAuthentication.XAPIKEY)]
    public class SmartClientController : ControllerBase
    {
        private readonly IMatchingResultService _matchingResultService;
        private readonly IPatternService _patternService;
        private readonly SmartIngestService _smartIngestService;
        private readonly IMapper _mapper;
        public SmartClientController(IMatchingResultService matchingResultService, IMapper mapper, 
            IPatternService patternService, SmartIngestService smartIngestService)
        {
            _matchingResultService = matchingResultService;
            _mapper = mapper;
            _patternService = patternService;
            _smartIngestService = smartIngestService;
        }


        [HttpGet("scoring")]       
        public async Task<ActionResult<ScoringDTO>> GetScoringForAll()
        {
            var matchingResults = await _matchingResultService.GetMatchingResultAsync();

            var matchingResultDtos = matchingResults.Select(x => _mapper.Map<ScoringDTO>(x)).ToList();

            if(matchingResultDtos.Count > 0)
                return Ok(matchingResultDtos);

            return NotFound();
        }

        [HttpGet("scoring/{date}/{hourFrom?}/{hourTo?}")]
        public async Task<ActionResult<ScoringDTO>> GetScoringForAllBy(string date, int hourFrom = 0, int hourTo = 24)
        {
            var _date = DateTime.Parse(date);
            var matchingResults = await _matchingResultService.GetMatchingResultByAsync(_date, hourFrom, hourTo);

            var matchingResultDtos = matchingResults.Select(x => _mapper.Map<ScoringDTO>(x)).ToList();

            if (matchingResultDtos.Count > 0)
                return Ok(matchingResultDtos);

            return NotFound();
        }

        [HttpPost]
        public async Task<ActionResult> ChangeStatus(StatusChangeDto statusChangeDto) 
        {
            await _patternService.UpdatePatternStatus(statusChangeDto.ContractId, statusChangeDto.Status);

            if (statusChangeDto.Status == PatternStatusEnum.Confirmed.ToString())
            {
                await _smartIngestService.SetPatternToImportByContractId(statusChangeDto.ContractId, string.Empty, PatternStatusEnum.Confirmed);
            }            

            return Ok();
        }

        public class StatusChangeDto
        {
            public string ContractId { get; set; }
            public string Status { get; set; }
        }
    }
}