﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Services.Interfaces;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web.Api.Authorization;
using Web.Api.Domain.Models.Roles;
using Web.Api.DTOs.Role;

namespace Web.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : BaseController
    {

        private readonly IRoleService _roleService;
        private readonly IMapper _mapper;

        public RoleController(IRoleService roleService, IMapper mapper)
        {
            _roleService = roleService;
            _mapper = mapper;
        }

        [HttpGet]
        [HasPermission(Permissions.RoleRead)]
        public async Task<IActionResult> Get()
        {
            var result = await _roleService.GetAll();

            if (result.IsFailure)
                return Error(result.Error);

            var roles = _mapper.Map<IEnumerable<RoleDTO>>(result.Value);

            return Ok(roles);
        }

        [HttpGet("{id}")]
        [HasPermission(Permissions.RoleRead)]
        public async Task<IActionResult> Get(int id)
        {
            var result = await _roleService.Get(id);

            if (result.IsSuccess && result.Value == null)
                return NotFound();

            if (result.IsFailure)
                return Error(result.Error);

            var roleDTO = _mapper.Map<RoleDTO>(result.Value);

            return Ok(roleDTO);
        }

        [HttpPost]
        [HasPermission(Permissions.RoleCreate)]
        public async Task<IActionResult> Post([FromBody] RoleDTO roleDTO)
        {
            if (roleDTO == null)
                return BadRequest();

            var role = Role.Create(roleDTO.Name, roleDTO.Description, roleDTO.Permissions.Select(x => x.Id), roleDTO.IsActive);
            var result = await _roleService.Create(role, GetUserId());

            return FromResult(result);
        }

        [HttpPut("{id}")]
        [HasPermission(Permissions.RoleChange)]
        public async Task<IActionResult> Put(int id, [FromBody] RoleDTO roleDTO)
        {
            if (id != roleDTO.Id)
                return BadRequest();

            var roleResult = await _roleService.Get(id);

            if (roleResult.Value == null)
                return NotFound();

            var result = await _roleService.Update(roleResult.Value, roleDTO.Name, roleDTO.Description, roleDTO.Permissions.Select(x => x.Id), roleDTO.IsActive, GetUserId());

            if (result.IsSuccess)
                return Ok(roleDTO);

            return FromResult(result);
        }

        [HttpGet("permission")]
        [HasPermission(Permissions.RoleRead)]
        public async Task<IActionResult> GetPermissions()
        {
            var permissions = Enum.GetValues(typeof(Permissions));

            var permissionDTOs = _mapper.Map<List<PermissionDTO>>(permissions);

            return Ok(permissionDTOs);
        }
    }
}
