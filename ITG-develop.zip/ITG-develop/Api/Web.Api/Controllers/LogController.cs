﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Application.Services.Interfaces;
using Web.Api.Authorization;
using Web.Api.Domain.Models.Roles;
using AutoMapper;
using Web.Api.DTOs.Log;
using Web.Api.Domain.Models.Paging;
using Microsoft.Extensions.Logging;
using Web.Api.DTOs.Error;
using Web.Api.Domain.Exceptions;

namespace Web.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class LogController : BaseController
    {
        private readonly ILogEntryService _logEntryService;
        private readonly IMapper _mapper;
        private readonly ILogger<LogController> _logger;
        public LogController(ILogEntryService logEntryService, IMapper mapper, ILogger<LogController> logger)
        {
            _logEntryService = logEntryService;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet]
        [HasPermission(Permissions.PatternRead)]
        public async Task<IActionResult> Get(int pageIndex, int pageSize)
        {
            var result = await _logEntryService.GetPagedAsync(pageIndex, pageSize);

            if (result.IsFailure)
                return Error(result.Error ?? "");

            var logEntryDTOList = _mapper.Map<IList<LogEntryDTO>>(result.Value.Results);
            var pagedResult = new PagedResult<LogEntryDTO>()
            {
                CurrentPage = result.Value.CurrentPage,
                PageCount = result.Value.PageCount,
                PageSize = result.Value.PageSize,
                RowCount = result.Value.RowCount,
                Results = logEntryDTOList
            };

            return Ok(pagedResult);
        }

        [HttpPost("error")]
        [HasPermission(Permissions.PatternRead)]
        public IActionResult LogError([FromBody] AppErrorDto error)
        {
            Guid exceptionId = Guid.NewGuid();
            /* Log error from angular app */
            _logger.LogError(
                new WebClientException($"{exceptionId}: {error.Message}", error.Route, error.Stack, error.Filename),
                $"{exceptionId}: {error.Message}");

            return Ok(exceptionId);
        }

        [HttpPost("scripts/error")]
        [Authorize(AuthenticationSchemes = XAPIKeyAuthentication.XAPIKEY)]
        public IActionResult LogScriptsError([FromBody] string formattedErrorContent)
        {
            _logger.LogError(formattedErrorContent);
            return Ok();
        }
    }
}
