﻿using Application.Services.Configuration;
using Application.Services.Interfaces;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Authorization;
using Web.Api.Domain.Exceptions;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Roles;
using Web.Api.DTOs.Error;
using Web.Api.DTOs.User;
using Web.Api.Models;

namespace Web.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : BaseController
    {
        private readonly IUserService _userService;
        private readonly IMapper _mapper;
        private readonly IBMIdConfiguration _config;
        private readonly EndpointsConfiguration _endpointsConfig;
        private readonly ILogger<UserController> _logger;

        public UserController(IUserService userService, IMapper mapper, 
            IOptions<IBMIdConfiguration> ibmIdConfiguration, IOptions<EndpointsConfiguration> endpointsConfig, 
            ILogger<UserController> logger)
        {
            _userService = userService;
            _mapper = mapper;
            _config = ibmIdConfiguration.Value;
            _endpointsConfig = endpointsConfig.Value;
            _logger = logger;
        }

        [AllowAnonymous]
        [HttpPost("authenticate")]
        public async Task<IActionResult> Authenticate([FromBody]TokenRequest tokenRequest)
        {
            var user = await _userService.Authenticate(tokenRequest.Login, tokenRequest.Password);

            #if DEBUG
                user = _userService.DebugMode();
            #endif

            if (user == null)
                return BadRequest(new { message = "Username or password is incorrect", customErrorCode = ErrorTypeEnum.IncorrectCredencial });

            if (user.IsConfirmed == false)
                return BadRequest(new { message = "User not confirmed.", customErrorCode = ErrorTypeEnum.UserNotConfirmed });

            var tokenString = _userService.GenerateUserToken(user);

            return Ok(new
            {
                Id = user.Id,
                Username = user.Username,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Token = tokenString,
                IsAdmin = user.IsAdmin,
                Settings = user.Settings
            });
        }

        [AllowAnonymous]
        [HttpPost("loginrequest")]
        public IActionResult Login()
        {
            var returnUrl = $"{_config.AuthorizationEndpoint}?response_type=code&scope=openid&client_id={_config.ClientId}&state=af1Ef";

            return Ok(returnUrl);
        }

        [AllowAnonymous]
        [HttpGet("login")]
        public async Task<IActionResult> LoginIBMId(string scope, string code, string state)
        {
            if (code == null)
                return BadRequest("An error occurred while processing your request.");

            var client = new RestClient(_config.TokenEndpoint);
            var request = new RestRequest(Method.POST);

            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/x-www-form-urlencoded");

            string myHostUrl = $"{HttpContext.Request.Scheme}://{HttpContext.Request.Host}";
            string requestParams = "scope=openid&grant_type=authorization_code&client_id=" + _config.ClientId + "&client_secret=" + _config.ClientSecret + "&code=" + code + "&redirect_uri=" + _endpointsConfig.SmartApi + "/user/login";
            request.AddParameter("application/x-www-form-urlencoded", requestParams, ParameterType.RequestBody);
            SSOToken ssoToken = null;
            IRestResponse response = null;

            try
            {
                response = client.Execute(request);
                ssoToken = SSOToken.Create(response.Content);
            }
            catch (Exception e)
            {
                _logger.LogError("Failed to craete sso token", e);
                return BadRequest("An error occurred while processing your request.");
            }

            if (ssoToken == null || ssoToken.IdToken == null)
                return BadRequest("An error occurred while processing your request.");

            var userResult = await _userService.GetByUsername(ssoToken.LoggedUserEmail);
            User user = userResult.Value;

            if (userResult.Value == null)
                user = await _userService.CreateIbmIdUser(ssoToken.LoggedUserEmail, ssoToken.Firstname, ssoToken.Lastname);

            if (user.IsConfirmed == false)
                return Redirect($"{_endpointsConfig.SmartWeb}/#/login/user-to-confirm");

            var tokenString = _userService.GenerateUserToken(user);

            var userReturnInfo = new
            {
                Id = user.Id,
                Username = user.Username,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Token = tokenString,
                IsAdmin = user.IsAdmin,
                IsConfirmed = user.IsConfirmed,
                Settings = user.Settings
            };

            string objectString = JsonConvert.SerializeObject(userReturnInfo, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
            byte[] objectBytes = Encoding.ASCII.GetBytes(objectString);
            string smartWebParameter = Convert.ToBase64String(objectBytes);

            var redirect = $"{_endpointsConfig.SmartWeb}/#/login/ibmid/{smartWebParameter}";

            return Redirect(redirect);
        }

        [HttpGet]
        [HasPermission(Permissions.UserRead)]
        public async Task<IActionResult> GetAll()
        {
            var result = await _userService.GetAll();

            if (result.IsSuccess)
            {
                var users = _mapper.Map<IEnumerable<UserDTO>>(result.Value);
                var userDtoList = users.Where(x => x.FirstName != "Admin" && x.LastName != "Admin");
                return Ok(userDtoList);
            }

            return Error(result.Error);
        }

        [HttpPost("create")]
        [HasPermission(Permissions.UserCreate)]
        public async Task<IActionResult> Create([FromBody]UserDTOForCreation userDto)
        {
            var user = _mapper.Map<User>(userDto);

            try
            {
                await _userService.Create(user, userDto.Password);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut()]
        [HasPermission(Permissions.UserChange)]
        public async Task<IActionResult> UpdateRoles([FromBody]UserDTO userDto)
        {
            var userFromDb = await _userService.GetByUsername(userDto.Username);
            if (userFromDb.Value == null)
                return NotFound();

            User user = userFromDb.Value;
            var roles = _mapper.Map<IEnumerable<Role>>(userDto.Roles);

            try
            {
                var result = await _userService.Update(user, userDto.Username, userDto.FirstName, userDto.LastName, roles, userDto.IsAdmin, userDto.IsConfirmed, user.Settings, GetUserId());
                if (result.IsSuccess)
                    return Ok(userDto);

                return FromResult(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }

        }

        [HttpPut("settings")]
        public async Task<IActionResult> SetUserSettings([FromBody] string settings)
        {
            var user = await _userService.GetById(GetUserId());
            if (user.Value == null)
                return NotFound();

            var result = await _userService.Update(user.Value, user.Value.Username, user.Value.FirstName, user.Value.LastName, user.Value.Roles, user.Value.IsAdmin, user.Value.IsConfirmed, settings, GetUserId());

            return FromResult(result);
        }
    }
}
