﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static Web.Api.Startup;

namespace Web.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize(AuthenticationSchemes = XAPIKeyAuthentication.XAPIKEY)]
    [ShowInSwagger]
    public class TestController : ControllerBase
    {
        [HttpGet("ping")]
        public async Task<string> Ping()
        {
            return await Task.FromResult("pong");
        }

        [HttpGet("exception")]
        public async Task<string> Exception()
        {
            throw new Exception("exception from TestController");
            await Task.CompletedTask;
        }
    }
}