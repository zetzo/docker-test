﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web.Api.Authorization;
using Web.Api.Domain.Models.Roles;

namespace Web.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class MatchingController : BaseController
    {
        private readonly IMatchingResultService _matchingResultService;

        public MatchingController(IMatchingResultService matchingResultService)
        {
            _matchingResultService = matchingResultService;
        }

        [HttpGet]
        [HasPermission(Permissions.MatchingResultRead)]
        public async Task<IActionResult> GetPaged(int pageIndex, int pageSize, string filterType = "", string filterContent = "")
        {
            var result = await _matchingResultService.GetPagedAsync(pageIndex, pageSize, filterType, filterContent);

            if (result.IsFailure)
                return Error(result.Error);
            
            return Ok(result.Value);
        }
    }
}
