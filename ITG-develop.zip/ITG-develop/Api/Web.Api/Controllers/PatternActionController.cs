﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Services;
using Application.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web.Api.Authorization;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.PatternActions;
using Web.Api.Domain.Models.Roles;

namespace Web.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PatternActionController : BaseController
    {
        private readonly IPatternActionService _patternActionService;
        private readonly SmartIngestService _smartIngestService;
        private readonly ContractFinder _contractFinder;

        public PatternActionController(IPatternActionService patternActionService, 
            SmartIngestService smartIngestService, ContractFinder contractFinder)
        {
            _patternActionService = patternActionService;
            _smartIngestService = smartIngestService;
            _contractFinder = contractFinder;
        }

        [HttpGet("folder/structure")]
        [HasPermission(Permissions.PatternRead)]
        public IActionResult GetEntireFolderStructure()
        {
            var result = _patternActionService.GetEntireFolderStructure();

            return FromResult<IEnumerable<FileElement>>(result);
        }

        [HttpGet("folder/structure/{contract}")]
        [HasPermission(Permissions.PatternRead)]
        public IActionResult GetFolderStructure(string contract)
        {
            var result = _patternActionService.GetFolderStructure(contract);

            return FromResult<PatternSourceFolderStructure>(result);
        }

        [HttpPost("folder/file")]
        [HasPermission(Permissions.PatternRead)]
        public async Task<IActionResult> GetContent([FromBody] string path, [FromQuery(Name = "compression")] bool? withCompression)
        {
            var resultByte = await _patternActionService.GetFileContent(path, withCompression.GetValueOrDefault(false));
            var resultString = Convert.ToBase64String(resultByte);

            return Ok(resultString);
        }

        [HttpPost("action/extract/{fileName}/{page}")]
        [HasPermission(Permissions.PatternCreate)]
        public async Task<IActionResult> SchedulePatternExtract(string fileName, int page)
        {
            await _smartIngestService.AddPageForExtractBy(fileName, page);

            return Ok();
        }

        [HttpPost("action/set/{fileName}")]
        [HasPermission(Permissions.PatternUpdate)]
        public async Task<IActionResult> SetCurrentPattern(string fileName)
        {
            await _smartIngestService.SetPatternToImport(fileName);

            return Ok();
        }

        [HttpPost("action/crop/{fileName}/{leftShift}/{bottomShift}")]
        [HasPermission(Permissions.PatternUpdate)]
        public async Task<IActionResult> CropPatternImage(string fileName, int leftShift, int bottomShift)
        {
            await _smartIngestService.AddOverridePageCut(fileName, leftShift, bottomShift);

            return Ok();
        }

        [HttpGet("action/crop/{fileName}")]
        [HasPermission(Permissions.PatternUpdate)]
        public IActionResult GetScheduledPatternCut(string fileName)
        {
            var result = _smartIngestService.GetOverridePageCut(fileName);

            if (result.HasNoValue)
                return Ok(new { Result = false });

            return Ok(new { Result = true });
        }

        [HttpGet("action/extract/{fileName}")]
        [HasPermission(Permissions.PatternUpdate)]
        public IActionResult GetScheduledPatternExtract(string fileName)
        {
            var result = _smartIngestService.GetPageForExtractBy(fileName);

            if (result.HasNoValue)
                return Ok(new { Result = false });

            return Ok(new { Result = true });
        }

        [HttpGet("action/set/{fileName}")]
        [HasPermission(Permissions.PatternUpdate)]
        public IActionResult GetScheduledPatternSet(string fileName)
        {
            var contractIdResult = _contractFinder.GetFromFile(fileName);

            if (contractIdResult.IsFailure)
                return Ok(new { Result = false });
                
            var patternImport = _smartIngestService.GetPatternToImportBy(contractIdResult.Value);

            if (patternImport.HasNoValue)
                return Ok(new { Result = false });

            return Ok(new { Result = true });
        }
    }
}