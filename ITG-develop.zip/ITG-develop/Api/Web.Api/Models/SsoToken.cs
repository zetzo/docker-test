﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft;
using Newtonsoft.Json;

namespace Web.Api.Models
{
    public class SSOToken
    {
        public static SSOToken Create(string content)
        {

            SSOToken token = new SSOToken();
            var jsonSerializerSettings = new JsonSerializerSettings();
            jsonSerializerSettings.MissingMemberHandling = MissingMemberHandling.Ignore;
            token = JsonConvert.DeserializeObject<SSOToken>(content, jsonSerializerSettings);

            return token;
        }

        public JwtSecurityToken IdToken { get; set; }

        public string LoggedUserEmail
        {
            get
            {
                return IdToken.Subject;
            }
        }

        public string Firstname
        {
            get
            {
                return IdToken.Payload["given_name"].ToString();
            }
        }

        public string Lastname
        {
            get
            {
                return IdToken.Payload["family_name"].ToString();
            }
        }


        public SSOToken()
        {
        }

        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        [JsonProperty("token_type")]
        public string TokenType { get; set; }

        [JsonProperty("expires_in")]
        public string ExpiresIn { get; set; }

        [JsonProperty("scope")]
        public string Scope { get; set; }

        [JsonProperty("refresh_token")]
        public string RefreshToken { get; set; }

        private string _idToken;

        [JsonProperty("id_token")]
        public string _IdToken
        {
            get
            {
                return _idToken;
            }
            set
            {
                _idToken = value;
                IdToken = new JwtSecurityToken(value);
            }
        }

    }
}
