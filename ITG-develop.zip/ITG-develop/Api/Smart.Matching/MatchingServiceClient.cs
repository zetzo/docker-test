﻿using IBM.NetCore.RabbitMQ;
using System;
using System.Collections.Generic;
using System.Text;

namespace Smart.Matching
{
    public sealed class MatchingServiceClient : IMatchingServiceClient
    {
        private readonly RpcQueueSender _rpcQueueSender;

        public MatchingServiceClient(RpcQueueSender rpcQueueSender)
        {
            _rpcQueueSender = rpcQueueSender;
        }

        public int Match(byte[] patternContent, byte[] imageContent, string contractId, string fileName, decimal distance)
        {
            var patterMatchingRequest = new MatchingRequest
            {
                PatternContent = Convert.ToBase64String(patternContent),
                ClosingDocumentContent = Convert.ToBase64String(imageContent),
                ContractId = contractId,
                FileName = fileName,
                Distance = distance
            };

            var response = _rpcQueueSender.SendAndReceive<MatchingRequest, MatchingResponse>(patterMatchingRequest);

            return response.Message.Result.Score;
        }
    }
}
