﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smart.Matching
{
    public sealed class MatchingRequest
    {
        public string FileName { get; set; }
        public string ContractId { get; set; }
        public string ClosingDocumentContent { get; set; }
        public string PatternContent { get; set; }
        public decimal Distance { get; set; }
    }
}
