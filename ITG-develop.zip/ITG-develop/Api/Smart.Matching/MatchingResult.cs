﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smart.Matching
{
    public class MatchingResult
    {
        public string FileName { get; set; }
        public string ContractId { get; set; }
        public int Score { get; set; }
    }

    public class MatchingResponse
    {
        public MatchingResult Result { get; set; }
    }
}
