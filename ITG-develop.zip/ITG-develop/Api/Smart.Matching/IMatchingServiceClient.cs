﻿namespace Smart.Matching
{
    public interface IMatchingServiceClient
    {
        int Match(byte[] patternContent, byte[] imageContent, string contractId, string fileName, decimal distance);
    }
}