﻿using CSharpFunctionalExtensions;
using ImageMagick;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace Smart.Matching.DocumentProvider.Chains
{
    public abstract class MatchingHandler
    {
        private MatchingHandler _nextHandler;
        protected IMatchingServiceClient _matchingServiceClient;

        public MatchingHandler(IMatchingServiceClient matchingServiceClient)
        {
            _matchingServiceClient = matchingServiceClient;
        }

        public void AddNext(MatchingHandler nextHanlder)
        {
            if (_nextHandler != null) _nextHandler.AddNext(nextHanlder);
            else
                _nextHandler = nextHanlder;
        }

        public virtual int Handle(int previousScore, MatchingPayload payload) => _nextHandler == null ? 0 : _nextHandler.Handle(previousScore, payload);
    }


    public class RawMatchingHandler : MatchingHandler
    {
        public RawMatchingHandler(IMatchingServiceClient matchingServiceClient) : base(matchingServiceClient)
        {

        }

        public override int Handle(int previousScore, MatchingPayload payload)
        {
            Console.WriteLine(nameof(RawMatchingHandler));

            int score = _matchingServiceClient.Match(payload.PatternContent, payload.ImageContent, payload.ContractId, payload.FileName, payload.Distance);
            Console.WriteLine(score);
            if (score > 250)
                return score;

            return base.Handle(Math.Max(previousScore, score), payload);
        }
    }

    public class RightAutoGammaMatchingHandler : MatchingHandler
    {
        public RightAutoGammaMatchingHandler(IMatchingServiceClient matchingServiceClient) : base(matchingServiceClient)
        {

        }

        public override int Handle(int previousScore, MatchingPayload payload)
        {
            Console.WriteLine(nameof(RightAutoGammaMatchingHandler));

            var imageWithAutoGammaResult = AutoGamma(payload.ImageContent);
            if (imageWithAutoGammaResult.IsSuccess)
            {
                int score = _matchingServiceClient.Match(payload.PatternContent, imageWithAutoGammaResult.Value, payload.ContractId, payload.FileName, payload.Distance);                
                previousScore = Math.Max(previousScore, score);
                Console.WriteLine(score);
                if (score > 250)
                    return score;
                else
                    return base.Handle(previousScore, payload);
            }

            return previousScore;
        }
        protected Result<byte[]> AutoGamma(byte[] imageData)
        {
            //if (imageData.Length == 0)
            //    return Result.Failure<byte[]>("no image in bytes array");

            return Result.Try<byte[]>(() =>
            {
                using (var outPutData = new MemoryStream())
                using (var image = new MagickImage(imageData))
                { 
                    image.AutoGamma();
                    image.Write(outPutData);

                    return outPutData.ToArray();
                }
            });
        }
    }

    public class BothAutoGammaMatchingHandler : RightAutoGammaMatchingHandler
    {
        public BothAutoGammaMatchingHandler(IMatchingServiceClient matchingServiceClient) : base(matchingServiceClient)
        {

        }

        public override int Handle(int previousScore, MatchingPayload payload)
        {
            Console.WriteLine(nameof(BothAutoGammaMatchingHandler));

            var imageWithAutoGammaResult = AutoGamma(payload.ImageContent);
            var patternWithAutoGammaResult = AutoGamma(payload.PatternContent);
            if (imageWithAutoGammaResult.IsSuccess && patternWithAutoGammaResult.IsSuccess)
            {
                int score = _matchingServiceClient.Match(patternWithAutoGammaResult.Value, imageWithAutoGammaResult.Value, payload.ContractId, payload.FileName, payload.Distance);
                Console.WriteLine(score);
                return Math.Max(previousScore, score);
            }
            return previousScore;
        }

    }

    public sealed class MatchingPayload
    {
        public byte[] PatternContent { get; private set; }
        public byte[] ImageContent { get; private set; }
        public decimal Distance { get; private set; } = 0.6M;
        public string FileName { get; private set; }
        public string ContractId { get; private set; }

        private MatchingPayload(byte[] patternContent, byte[] imageContent, string contractId, string fileName, decimal distance)
        {
            PatternContent = patternContent;
            ImageContent = imageContent;
            ContractId = contractId;
            FileName = fileName;
            Distance = distance;
        }

        public static MatchingPayload Create(byte[] patternContent, byte[] imageContent, string contractId, string fileName, decimal distance = 0.6M) => new MatchingPayload(patternContent, imageContent, contractId, fileName, distance);
    }
}

