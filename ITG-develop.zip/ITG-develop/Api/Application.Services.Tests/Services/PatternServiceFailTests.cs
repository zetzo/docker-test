﻿using Application.Services.ViewModels;
using CSharpFunctionalExtensions;
using Moq;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;
using Xunit;
using FluentAssertions;
using Web.Api.Data.Common;
using Application.Services.Interfaces;
using Microsoft.Extensions.Options;
using Application.Services.Configuration;

namespace Application.Services.Tests.Services
{
    public class PatternServiceFailTests
    {
        private readonly IPatternService _patternService;

        public PatternServiceFailTests()
        {
            var patternStorageRespository = new Mock<IStorageRepository>();
            var patternRepository = new Mock<IPatternRepository>();
            var publisher = new Mock<IDomainEventsPublisher>();
            var minio = new Mock<IOptions<MinioStorageConfiguration>>();


            patternStorageRespository.Setup(x => x.GetById(It.IsAny<string>(), It.Is<string>(v => v == "sha103"))).ReturnsAsync(new byte[] { });
            patternRepository.Setup(x => x.GetByEntityId(It.Is<string>(v => v == "sha102"), default(CancellationToken))).ReturnsAsync(default(Pattern));
            patternRepository.Setup(x => x.GetByEntityId(It.Is<string>(v => v == "sha103"), default(CancellationToken))).ReturnsAsync(Pattern.CreateNew("2", "sample2.png", "", "sha103"));
            patternRepository.Setup(x => x.GetById(It.IsAny<long>(), default(CancellationToken))).ReturnsAsync((Pattern)null);
            patternRepository.Setup(x => x.Delete(It.IsAny<Pattern>(), default(CancellationToken))).Returns(Task.CompletedTask);

            _patternService = new PatternService(patternRepository.Object, patternStorageRespository.Object, new ContractFinder(), new CryptoHelper(), publisher.Object, minio.Object, null);
        }

        [Fact]
        public async Task Check_if_getting_file_pattern_returns_pattern_not_found_result()
        {
            Result<PatternContentResult> result = await _patternService.GetPatternContent("sha102");
            result.IsFailure.Should().BeTrue();
            result.Error.Should().Be("Pattern not found");            
        }

        [Fact]
        public async Task Check_if_getting_file_pattern_returns_pattern_pattern_file_not_found()
        {
            Result<PatternContentResult> result = await _patternService.GetPatternContent("sha103");
            result.IsFailure.Should().BeTrue();
            result.Error.Should().Be("Pattern file not found");
        }

        [Fact]
        public async Task Get_pattern_by_id_return_result_error_when_not_found()
        {
            Result<Pattern> result = await _patternService.GetPatternById(456789);
            result.IsFailure.Should().BeTrue();
            result.Error.Should().Be("Pattern not found");
        }


        [Fact]
        public async Task Delete_pattern_by_image_hash_return_result_failed_when_not_found()
        {
            Result result = await _patternService.DeletePattern("sha102", 100);
            result.IsFailure.Should().BeTrue();
            result.Error.Should().Be("Pattern not found for entity ID: sha102");
        }
    }
}
