﻿using Application.Services.Configuration;
using Application.Services.Interfaces;
using Application.Services.Services;
using Application.Services.ViewModels;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using FluentAssertions;

namespace Application.Services.Tests.Services
{
    public class ContractServiceSuccessTests
    {
        private readonly IContractService _contractService;

        public ContractServiceSuccessTests()
        {
            var requestProvider = new Mock<IRequestProvider>();
            requestProvider.Setup(x => x.PostAsync<ContractImagesResponse>(It.IsAny<string>(), It.IsAny<StringContent>()))
                    .ReturnsAsync(new ContractImagesResponse());

            var configuration = new EndpointsConfiguration()
            {
                CapturifyAPI = ""
            };

            _contractService = new ContractService(requestProvider.Object, Options.Create(configuration));
        }

        [Fact]
        public async Task SplitPdfIntoImages_Returns_Result_Success_When_External_Service_Return_Ok()
        {
            var contract = new ContractPdfRequest()
            {
                Content = "test"
            };

            var result = await _contractService.SplitPdfIntoImages(contract);

            result.IsSuccess.Should().Equals(true);
            result.Value.Should().BeOfType(typeof(ContractImagesResponse));
        }
    }
}
