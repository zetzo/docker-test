﻿using Application.Services.ViewModels;
using CSharpFunctionalExtensions;
using Moq;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;
using Xunit;
using FluentAssertions;
using Web.Api.Data.Common;
using System;
using Application.Services.Interfaces;
using Application.Services.Configuration;
using Microsoft.Extensions.Options;

namespace Application.Services.Tests.Services
{
    public class PatternServiceSuccessTests
    {
        private readonly IPatternService _patternService;
        private readonly CryptoHelper _cryptoHelper;

        public PatternServiceSuccessTests()
        {
            var patternStorageRespository = new Mock<IStorageRepository>();
            var patternRepository = new Mock<IPatternRepository>();
            var publisher = new Mock<IDomainEventsPublisher>();
            var minio = new Mock<IOptions<MinioStorageConfiguration>>();

            patternStorageRespository.Setup(x => x.GetById(It.IsAny<string>(), It.Is<string>(v => v == "sha101"))).ReturnsAsync(new byte[] { 1 });
            patternStorageRespository.Setup(x => x.Add(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<byte[]>())).ReturnsAsync(true);
            patternRepository.Setup(x => x.GetByEntityId(It.Is<string>(v => v == "sha101"), default(CancellationToken))).ReturnsAsync(Pattern.CreateNew("1", "sample.png", "", "sha101"));
            patternRepository.Setup(x => x.Update(It.IsAny<Pattern>(), default(CancellationToken))).Returns(Task.CompletedTask);
            patternRepository.Setup(x => x.Delete(It.IsAny<Pattern>(), default(CancellationToken))).Returns(Task.CompletedTask);

            _patternService = new PatternService(patternRepository.Object, patternStorageRespository.Object, new ContractFinder(), new CryptoHelper(), publisher.Object, minio.Object, null);
            _cryptoHelper = new CryptoHelper();
        }

        [Fact]
        public async Task Check_if_getting_file_pattern_from_storage_is_working()
        {
            Result<PatternContentResult> result = await _patternService.GetPatternContent("sha101");
            result.IsSuccess.Should().BeTrue();
            result.Value.Should().NotBeNull();
            result.Value.Content.Should().BeEquivalentTo(new byte[] { 1 });
        }

        //[Fact]
        //public async Task Update_pattern_invoke_pattern_content_update_when_image_hash_change()
        //{
        //    Pattern pattern = Pattern.CreateNew("10000", "sample.jpg", "desc", "bmJoZmduZm5oaGZn", "1235554647");
        //    PatternContent patternContent = PatternContent.Create("unique", new byte[] { 1 });
        //    var minio = new Mock<IOptions<MinioStorageConfiguration>>();

        //    var patternStorageRespository = new Mock<IStorageRepository>();
        //    patternStorageRespository.Setup(x => x.Add(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<byte[]>())).ReturnsAsync(true);
        //    var patternRespository = new Mock<IPatternRepository>();
        //    var publisher = new Mock<IDomainEventsPublisher>();
        //    var patternService = new PatternService(patternRespository.Object, patternStorageRespository.Object, new ContractFinder(), new CryptoHelper(), publisher.Object, minio.Object);

        //    var newImageData = "ZHNmc2RkZnM=";
        //    var newImageDataHash = _cryptoHelper.GenSha256FromBytes(Convert.FromBase64String(newImageData));

        //    var result = await patternService.UpdatePattern(pattern, "10000", "1235554647", "desc", "abc45343", "sample.jpg", "ZHNmc2RkZnM=", 0);

        //    patternStorageRespository.Verify(x => x.Add(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<byte[]>()), Times.Once);
        //}

        //[Fact]
        //public async Task Update_pattern_do_not_invoke_pattern_content_update_when_image_hash_same()
        //{
        //    Pattern pattern = Pattern.CreateNew("10000", "sample.jpg", "desc", "3CA6ABEA19FE781990D3A547AD70CC8BEE97E26D1DE936B9D7FA1EC0D3FF4453", "1235554647");
        //    var minio = new Mock<IOptions<MinioStorageConfiguration>>();

        //    var patternStorageRespository = new Mock<IStorageRepository>();
        //    patternStorageRespository.Setup(x => x.Add(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<byte[]>())).ReturnsAsync(true);
        //    var patternRespository = new Mock<IPatternRepository>();
        //    var publisher = new Mock<IDomainEventsPublisher>();
        //    var patternService = new PatternService(patternRespository.Object, patternStorageRespository.Object, new ContractFinder(), new CryptoHelper(), publisher.Object, minio.Object);

        //    var result = await patternService.UpdatePattern(pattern, "10000", "1235554647", "desc", "3CA6ABEA19FE781990D3A547AD70CC8BEE97E26D1DE936B9D7FA1EC0D3FF4453", "sample.jpg", "bmJoZmduZm5oaGZn", 0);

        //    patternStorageRespository.Verify(x => x.Add(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<byte[]>()), Times.Never);
        //}

        //[Fact]
        //public async Task Update_pattern_on_updated_return_result_success()
        //{
        //    Pattern pattern = Pattern.CreateNew("10000", "sample.jpg", "desc", "3CA6ABEA19FE781990D3A547AD70CC8BEE97E26D1DE936B9D7FA1EC0D3FF4453", "1235554647");

        //    var result = await _patternService.UpdatePattern(pattern, "10000", "1235554647", "desc", "3CA6ABEA19FE781990D3A547AD70CC8BEE97E26D1DE936B9D7FA1EC0D3FF4453", "sample.jpg", "bmJoZmduZm5oaGZn", 0);

        //    result.IsSuccess.Should().BeTrue();
        //}

        [Fact]
        public async Task Delete_pattern_on_deleted_return_result_success()
        {
            var result = await _patternService.DeletePattern("sha101", 100);
            result.IsSuccess.Should().BeTrue();
        }


        [Fact]
        public void Pattern_should_be_obsolete()
        {
            bool shouldBeOld = false;
            Pattern pattern = Pattern.CreateNew("10000", "sample.jpg", "desc", "3CA6ABEA19FE781990D3A547AD70CC8BEE97E26D1DE936B9D7FA1EC0D3FF4453", "1235554647");
            pattern.SetImportDate(DateTime.Now);

            if (pattern.ImportDate > DateTime.Now.AddHours(DeleteContractsScaffoldTaskConfiguration.DeleteAfter48Hours))
            {
                shouldBeOld = true;
            }
                
            shouldBeOld.Should().BeTrue();
        }

        [Fact]
        public void Pattern_shouldnt_be_obsolete()
        {
            bool shouldBeOld = false;
            Pattern pattern = Pattern.CreateNew("10000", "sample.jpg", "desc", "3CA6ABEA19FE781990D3A547AD70CC8BEE97E26D1DE936B9D7FA1EC0D3FF4453", "1235554647");
            pattern.SetImportDate(DateTime.Now.AddHours(-49));

            if (pattern.ImportDate > DateTime.Now.AddHours(DeleteContractsScaffoldTaskConfiguration.DeleteAfter48Hours))
            {
                shouldBeOld = true;
            }

            shouldBeOld.Should().BeFalse();
        }
    }
}
