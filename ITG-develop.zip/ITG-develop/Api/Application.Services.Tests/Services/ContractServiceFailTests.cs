﻿using Application.Services.Configuration;
using Application.Services.Exceptions;
using Application.Services.Interfaces;
using Application.Services.Services;
using Application.Services.ViewModels;
using CSharpFunctionalExtensions;
using Microsoft.Extensions.Options;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using FluentAssertions;

namespace Application.Services.Tests.Services
{
    public class ContractServiceFailTests
    {
        private readonly IContractService _contractService;

        public ContractServiceFailTests()
        {
            var requestProvider = new Mock<IRequestProvider>();
            requestProvider.Setup(x => x.PostAsync<ContractImagesResponse>(It.IsAny<string>(), It.IsAny<StringContent>()))
                    .Throws(new HttpRequestExceptionEx(System.Net.HttpStatusCode.InternalServerError, "Internal Server Error"));

            var configuration = new EndpointsConfiguration()
            {
                CapturifyAPI = ""
            };

            _contractService = new ContractService(requestProvider.Object, Options.Create(configuration));
        }

        [Fact]
        public async Task SplitPdfIntoImages_Returns_Result_Failed_When_External_Server_Return_Error()
        {
            var contract = new ContractPdfRequest()
            {
                Content = "test"
            };

            var result = await _contractService.SplitPdfIntoImages(contract);

            result.IsFailure.Should().Equals(true);
            result.Error.Should().Equals("Internal Server Error");
        }
    }
}
