﻿using CSharpFunctionalExtensions;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Application.Services.Tests
{
    public class ContractFinderTests
    {
        [Theory]
        //[InlineData("test-12.pdf", 12)]
        //[InlineData("test-13.pdf", 13)]
        //[InlineData("СтройЭконом_ДС 1_ЛС-52883.PDF", "LS-52883")]
        //[InlineData("ДОГОВОР ЛС-46603 ИП ДИБИРОВА С.Э.PDF","LS-46603")]
        //[InlineData("ИП Слащилина С.А.Контракт_ЛС-29673 Прил.1-3.pdf", "LS-29673")]
        //[InlineData("Берегиня_ДС 2_ЛС-42712_WARNING_.PDF", "LS-42712")]
        //[InlineData("АКСЕНОВА ЛИ_ДОГОВОР_ЛС-73793.PNG", "LS-73793")]
        //[InlineData("Вега-Юг_Договор_ЛС-82950", "LS-82950")]
        //[InlineData("Абу-Зарук УХ_Договор_ЛС-57335", "LS-57335")]
        //[InlineData("АВ Логистик_ДС 1_ЛС-52845", "LS-52845")]
        //[InlineData("АМ-СЕРВИС_Договор_ЛС-67692", "LS-67692")]
        //[InlineData("Ам-Сервис_ДС 1_ЛС-52008", "LS-52008")]       
        //[InlineData("Агат Контракт_ЛС-21262 Прил.1-2.pdf","LS-21262")]
        //[InlineData("Сочилина ЛВ_.Договор_ЛС-79041.PDF", "LS-79041")]    
        //[InlineData("А.С.Д._ДС 1_ЛС-71637.PDF","LS-71637")]
        [InlineData("Кулик КД_ДС 1_)ЛС-66493.PDF", "LS-66493")]
        public void Check_if_file_contains_correct_contract_id(string fileName, string contractId)
        {
            ContractFinder contractFinder = new ContractFinder();

            Result<string> contractResult = contractFinder.GetFromFile(fileName);

            contractResult.IsSuccess.Should().BeTrue();
            contractResult.IsFailure.Should().BeFalse();

            contractResult.Value.Should().Be(contractId);
        }

        [Theory]
        //[InlineData("Вега-Юг_Договор_ЛС-82950", -1)]
        //[InlineData("Абу-Зарук УХ_Договор_ЛС-57335", -1)]          
        //[InlineData("Вега-Юг_Договор_ЛС-82950", -1)]
        [InlineData("ДОГОВОР ЛС-46603 ИП ДИБИРОВА С.Э.PDF", 8)]
        //[InlineData("Аб-Зарук УХ_Договор_ЛС-57335", -1)]
        //[InlineData("А-Зарук УХ_Договор_ЛС-57335", -1)]
        //[InlineData("-Зарук УХ_Договор_ЛС-57335", -1)]
        //[InlineData("Абу-Зарук УХ_Договор_ЛС-57335", 21)]
        public void find_correct_index_in_contract_id(string fileName, int correctIndex)
        {
            ContractFinder contractFinder = new ContractFinder();

            int index = contractFinder.FindCorrectIndex(fileName);

            index.Should().Be(correctIndex);
        }

        [Theory]
        [InlineData("test.pdf")]
        [InlineData("test13")]
        //[InlineData("tester-.pdf")]
        public void Check_finder_against_wrong_file_names(string fileName)
        {
            ContractFinder contractFinder = new ContractFinder();

            Result<string> contractResult = contractFinder.GetFromFile(fileName);
            contractResult.IsFailure.Should().BeTrue();
            contractResult.Error.Should().Be(ContractFinder.WrongNamingConventionErrorMessage);
        }

        [Theory]
        [InlineData("test-asa12.pdf")]
        //[InlineData("-as12.pdf")]
        //[InlineData("sad12-.pdf")]
        //[InlineData("tester-.pdf")]
        public void Check_finder_if_contract_file_part_cannot_be_parsed(string fileName)
        {
            ContractFinder contractFinder = new ContractFinder();

            Result<string> contractResult = contractFinder.GetFromFile(fileName);
            contractResult.IsFailure.Should().BeTrue();
            contractResult.Error.Should().Be(ContractFinder.FilePartCannotBeParsedErrorMessage);
        }

        [Theory]
        [InlineData("НЕСЬКИН ИП_ЗД_ЛС-60835_01.10.19-15.10.19.PDF", "LS-60835")]
        public void Check_finder_if_contract_is_in_closing_document(string fileName, string contractId)
        {
            ContractFinder contractFinder = new ContractFinder();
            Result<string> contractResult = contractFinder.GetFromClosingDocument(fileName);
            contractResult.IsSuccess.Should().BeTrue();
            contractResult.Value.Should().Be(contractId);
        }

        [Theory]
        [InlineData(1, 0)]
        [InlineData(2, 1)]
        [InlineData(3, 1)]
        [InlineData(4, 1)]
        public void Get_specific_page_from_closing_documnet(int pageCount, int expectedPage)
        {
            ContractFinder contractFinder = new ContractFinder();
            int expected = contractFinder.GetSpecificPageFromClosingDocument(pageCount);
            expected.Should().Be(expectedPage);
        }

        [Theory]
        [InlineData(9, 4)]
        [InlineData(8, 4)]
        [InlineData(7, 3)]
        [InlineData(6, 3)]
        [InlineData(5, 3)]
        [InlineData(4, 4)]
        [InlineData(3, 3)]
        [InlineData(2, 2)]
        [InlineData(1, 1)]
        public void Get_specific_page_from_contract(int pageCount, int expectedPage)
        {
            ContractFinder contractFinder = new ContractFinder();
            int expected = contractFinder.GetSpecificPageFromContract(pageCount);
            expected.Should().Be(expectedPage);
        }
    }
}
