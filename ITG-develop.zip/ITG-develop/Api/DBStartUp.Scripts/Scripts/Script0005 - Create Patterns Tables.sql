CREATE TABLE smart.patterns (
	id serial NOT NULL,
	import_file_name varchar(255) NOT NULL,
	latin_import_file_name varchar(255) NOT NULL,
	import_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	creation_date timestamp NULL,
	description text NULL,
	entity_id text NULL,
	content_type varchar(255) NULL,
	confirmed bool NULL DEFAULT false,
	contract_id varchar(50) NULL,
	inn varchar NULL,
	CONSTRAINT patterns_contract_id_key UNIQUE (contract_id),
	CONSTRAINT patterns_pkey PRIMARY KEY (id)
);