﻿CREATE TABLE smart.pattern_import_log (
	id serial NOT NULL,
	contract_id varchar(255) NULL,
	file_name varchar(255) NULL,
	message text NULL,
	import_time timestamp NULL,
	task_name varchar(255) NULL,
	CONSTRAINT pattern_import_log_pkey PRIMARY KEY (id)
);