CREATE TABLE smart.pattern_import (
	id serial NOT NULL,
	contract_id varchar(50) NULL,
	import_file_name varchar(255) NULL,
	CONSTRAINT pattern_import_import_file_name_key UNIQUE (import_file_name),
	CONSTRAINT pattern_import_pkey PRIMARY KEY (id)
);
