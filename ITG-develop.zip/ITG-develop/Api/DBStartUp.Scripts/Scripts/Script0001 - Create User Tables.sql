CREATE SCHEMA IF NOT EXISTS smart;

CREATE TABLE IF NOT EXISTS smart.users (
	id serial primary key,
	first_name varchar(150),
	last_name varchar(150),
	username varchar(100),
	password_hash bytea,
	password_salt bytea,
	is_admin bool,
	is_confirmed bool,
	settings varchar(200)
);

CREATE TABLE IF NOT EXISTS smart.roles (
	id serial primary key,
	name varchar(100) not null,
	description varchar(1000) null,
	aggregated_permission_list varchar(1000) not null,
	is_active bool not null
);


CREATE TABLE IF NOT EXISTS smart.user_role (
	id serial primary key,
	role_id int not null,
	user_id int not null
);


ALTER TABLE smart.user_role
ADD CONSTRAINT user_role_user_fk
FOREIGN KEY (user_id)
REFERENCES smart.users(id)
ON DELETE CASCADE;