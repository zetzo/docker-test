
CREATE TABLE smart.logs (
	id serial primary key,
	date_created timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	domain_model_type varchar(50),
	action_type varchar(50),
	action_result varchar(50),
	message varchar(1000),
	related_object_id int,
	user_id int
);
