
CREATE TABLE smart.version_info(
    id SERIAL primary KEY,
    date_created date,
    version_code varchar(50)
);

CREATE TABLE smart.version_info_changes(
    id SERIAL primary KEY,
    description varchar(500)
);

CREATE TABLE smart.version_version_changes(
	version_info_id int,
	change_id int,
	unique(version_info_id, change_id)
);

ALTER TABLE smart.version_version_changes ADD CONSTRAINT version_version_changes_fk FOREIGN KEY (version_info_id) REFERENCES smart.version_info(id);
ALTER TABLE smart.version_version_changes ADD CONSTRAINT version_version_info_fk FOREIGN KEY (change_id) REFERENCES smart.version_info_changes(id);


CREATE TABLE smart.user_message(
    id SERIAL primary KEY,
    message varchar(150),
    date_created date,
    details varchar(500)
);

