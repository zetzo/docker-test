﻿CREATE OR REPLACE PROCEDURE update_mappings()
LANGUAGE SQL
AS $$
 insert into smart.inn_contract_map (inn, contract_id, import_date )
 select inn, contract_id , current_timestamp  from smart.inn_contract_map_latest l
 where l.contract_id not in(select contract_id  from smart.inn_contract_map icm )
$$;
