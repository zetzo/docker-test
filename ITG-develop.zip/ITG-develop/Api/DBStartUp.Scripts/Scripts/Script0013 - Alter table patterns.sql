﻿

CREATE OR REPLACE FUNCTION 
f_pattern_age(import_date timestamp)
RETURNS int
AS $$
BEGIN
    RETURN ROUND((EXTRACT(EPOCH FROM CURRENT_TIMESTAMP) - EXTRACT(EPOCH FROM import_date))/3600);
END
$$
LANGUAGE plpgsql immutable;



ALTER TABLE smart.patterns ADD COLUMN IF not exists age INT GENERATED ALWAYS AS ( f_pattern_age(import_date) ) STORED;
