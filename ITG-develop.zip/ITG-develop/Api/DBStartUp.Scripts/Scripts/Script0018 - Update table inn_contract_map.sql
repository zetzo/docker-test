﻿drop view IF EXISTS smart.v_inn_contract;
drop table smart.inn_contract_map;
create table smart.inn_contract_map
(
	id integer not null primary key,
 	inn text not null,
	contract_id text not null,
	import_date timestamp default current_timestamp
);

CREATE UNIQUE INDEX contract_id_key
ON smart.inn_contract_map (contract_id);