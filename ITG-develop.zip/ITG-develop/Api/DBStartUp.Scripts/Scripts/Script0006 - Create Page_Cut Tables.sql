CREATE TABLE smart.page_cut (
	id serial NOT NULL,
	import_file_name varchar(255) NULL,
	cut_left int4 NULL,
	cut_bottom int4 NULL,
	reverse bool NULL,
	CONSTRAINT page_cut_import_file_name_key UNIQUE (import_file_name),
	CONSTRAINT page_cut_pkey PRIMARY KEY (id)
);