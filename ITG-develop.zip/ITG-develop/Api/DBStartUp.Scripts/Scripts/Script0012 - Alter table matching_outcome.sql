﻿ALTER TABLE smart.matching_outcome
DROP COLUMN IF EXISTS score_evaluation_name;