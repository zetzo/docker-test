﻿CREATE TABLE smart.matching_rules(
    id SERIAL primary KEY,
    contract_Id varchar(50),
    matched smallint,
    unmatched smallint,    
    distance decimal
);