CREATE TABLE smart.page_extract (
	id serial NOT NULL,
	import_file_name varchar(255) NULL,
	page_number int4 NULL,
	CONSTRAINT page_extract_import_file_name_key UNIQUE (import_file_name),
	CONSTRAINT page_extract_pkey PRIMARY KEY (id)
);