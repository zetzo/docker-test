﻿create table smart.inn_contract_map
(
	id serial,
 	inn text not null,
	contract_id text not null
);


CREATE UNIQUE INDEX contract_id_key
ON smart.inn_contract_map (contract_id);