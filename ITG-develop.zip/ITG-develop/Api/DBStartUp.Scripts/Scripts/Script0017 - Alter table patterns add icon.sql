﻿ALTER TABLE smart.patterns
ADD COLUMN IF not exists icon bytea null
