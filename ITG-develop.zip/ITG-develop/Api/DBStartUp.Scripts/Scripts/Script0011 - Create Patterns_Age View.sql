﻿create view smart.v_patterns_age
as
select contract_id as ContractId, (EXTRACT(EPOCH FROM current_timestamp) - EXTRACT(EPOCH FROM import_date))/3600 as Hours from smart.patterns