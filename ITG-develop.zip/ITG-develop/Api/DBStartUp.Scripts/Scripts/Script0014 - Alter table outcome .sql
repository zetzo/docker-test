﻿drop table IF EXISTS smart.matching_outcome_log;
create table smart.matching_outcome_error
(
	id SERIAL,
	file_name varchar(100),
	error_message text,
	created_date timestamp, 	
	CONSTRAINT matching_outcome_error_pkey PRIMARY KEY (id)
);