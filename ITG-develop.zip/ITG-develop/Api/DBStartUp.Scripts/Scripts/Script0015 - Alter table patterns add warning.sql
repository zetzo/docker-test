﻿ALTER TABLE smart.patterns DROP COLUMN IF EXISTS inn;
ALTER TABLE smart.patterns ADD COLUMN status varchar(20) default '';