CREATE TABLE smart.matching_outcome(
	id SERIAL primary KEY,
	date_created timestamp,
	contract_id varchar(30),
	file_name varchar(100),
	score int,
	score_evaluation_name varchar(100)
);


CREATE TABLE smart.matching_outcome_log(
    id SERIAL,
    model varchar(200),
    error_message varchar(500),
    created date
);