﻿create view smart.v_inn_contract_map
as
select icm.id, icm.inn , icm.contract_id from smart.inn_contract_map icm inner join smart.patterns p 
on icm.contract_id  = p.contract_id;