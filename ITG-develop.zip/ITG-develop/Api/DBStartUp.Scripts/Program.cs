﻿using DbUp;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Linq;
using System.Reflection;

namespace DBStartUp.Scripts
{
    internal class Program
    {
        private static int Main(string[] args)
        {
            var connection = GetConnectionString("DefaultConnection");
            EnsureDatabase.For.PostgresqlDatabase(connection);
            var upgrader =
                DeployChanges.To
                    .PostgresqlDatabase(connection)                    
                    .WithScriptsFromFileSystem("Scripts")
                    .LogToConsole()
                    .Build();

            var result = upgrader.PerformUpgrade();

            if (!result.Successful)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(result.Error);
                Console.ResetColor();
#if DEBUG
                Console.ReadLine();
#endif
                return -1;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Success!");
            Console.ResetColor();
            return 0;
        }

        private static string GetConnectionString(string name)
        {
            return GetConfigurationBuilder().Build().GetConnectionString(name);
        }

        private static IConfigurationBuilder GetConfigurationBuilder()
        {
            return new ConfigurationBuilder()
                            .SetBasePath(Directory.GetCurrentDirectory())
                            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                            .AddEnvironmentVariables();
        }
    }
}