﻿using Cairo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Pinta.Core
{
    public sealed class ImageHelper
    {
        //Pinta AutoLevel setup
        //TODO Autolevel dziala poprawnie jestli zaladujemy -> public ImageSurface(string filename) jesli zaladujemy wczesniej byte[] to nie dziala        
        public static void AutoLevel(ref byte[] data, Format format, int width,int height, int stride)
        {
            var src = new ImageSurface(data, Cairo.Format.Argb32, width, height, stride);

            Status status = src.Status;

            var live_preview_surface = new ImageSurface(Cairo.Format.Argb32, src.Width, src.Height);

            Render(src, live_preview_surface, new[] { new Gdk.Rectangle(0, 0, width, height) });

            live_preview_surface.Flush();

            live_preview_surface.WriteToPng("F:\\test_al.png");
        }

        //Orginal Code from Pinta
        public static void Render(ImageSurface src, ImageSurface dest, Gdk.Rectangle[] rois)
        {
            UnaryPixelOps.Level op;

            HistogramRgb histogram = new HistogramRgb();
            histogram.UpdateHistogram(src, new Gdk.Rectangle(0, 0, src.Width, src.Height));

            op = histogram.MakeLevelsAuto();

            if (op.isValid)
                op.Apply(dest, src, rois);
        }
    }
}
