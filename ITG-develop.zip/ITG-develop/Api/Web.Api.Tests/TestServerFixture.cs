﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Data.Infrastructure;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace Web.Api.Tests
{
    public class TestServerFixture : IDisposable
    {
        private readonly TestServer _testServer;
        public HttpClient Client { get; }
        public IConfiguration Configuration { get; }

        public TestServerFixture()
        {


            //var builder = new WebHostBuilder()
            //    .UseContentRoot(GetContentRootPath())
            //    .UseEnvironment("Development")
            //    .UseStartup<Web.Api.Startup>()
            //    .ConfigureServices(x =>
            //    {
            //        x.AddScoped<RedisConnection>(_ => new RedisConnection(Configuration.GetConnectionString("ITG_STORAGE_DB")));
            //    })
            //    .UseApplicationInsights();
        }

        private string GetContentRootPath()
        {
            string testProjectPath = PlatformServices.Default.Application.ApplicationBasePath;

            var relativePathToWebProject = @"..\..\..\..\..\Web.Api";

            return Path.Combine(testProjectPath, relativePathToWebProject);
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
