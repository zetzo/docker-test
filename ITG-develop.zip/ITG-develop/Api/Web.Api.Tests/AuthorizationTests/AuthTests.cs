﻿using FluentAssertions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Moq;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Authorization;
using Web.Api.Domain.Models.Roles;
using Xunit;

namespace Web.Api.Tests.AuthorizationTests
{
    public class AuthTests
    {
        private readonly Mock<IHttpContextAccessor> _mockHttpContextAccessor;
        private readonly ClaimsPrincipal user;
        private readonly PermissionRequirement[] requirements;
        public AuthTests() 
        {

            requirements = new[] { new PermissionRequirement("PatternRead") };
            user = new ClaimsPrincipal(
                        new ClaimsIdentity(
                            new Claim[] {
                                new Claim(ClaimTypes.NameIdentifier, "10"),
                                new Claim(ClaimTypes.Role, "H4-001000110012001300200021002200300031003200400041")
                            },
                            "Basic")
                        );

            _mockHttpContextAccessor = new Mock<IHttpContextAccessor>();
        }


        [Fact]
        public void ClaimsProvider_ClaimsNumberMatchClaimsFromContext()
        {
            //Arrange
            var defaultContext = new DefaultHttpContext() { User = user };
            _mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(defaultContext);

            //Act
            var claimsProvider = new GetClaimsProvider(_mockHttpContextAccessor.Object);

            //Assert
            claimsProvider.Permissions.Should().HaveCount(12);
            claimsProvider.UserId.Should().Equals(10);
        }

        [Fact]
        public async Task HasPermissionAttribute_AuthorizationHandler_Should_Succeed()
        {
            //Arrange    
            var defaultContext = new DefaultHttpContext() { User = user };
            _mockHttpContextAccessor.Setup(_ => _.HttpContext).Returns(defaultContext);

            var claimsProvider = new GetClaimsProvider(_mockHttpContextAccessor.Object);
            var context = new AuthorizationHandlerContext(requirements, user, null);
            var subject = new PermissionHandler(claimsProvider);

            //Act
            await subject.HandleAsync(context);

            //Assert
            context.HasSucceeded.Should().BeTrue();
        }

    }
}
