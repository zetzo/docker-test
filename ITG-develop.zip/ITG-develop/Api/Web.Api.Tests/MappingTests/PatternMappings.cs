﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Mappings;
using Xunit;

namespace Web.Api.Tests.MappingTests
{
    public class PatternMappings
    {
        [Fact]
        public void AutoMapper_Configuration_IsValid()
        {
            var configuration = new MapperConfiguration(cfg => {
                cfg.AddProfile<PatternProfile>();
            });

            configuration.AssertConfigurationIsValid();
        }
    }
}
