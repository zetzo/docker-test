﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using System;
using Web.Api.Data.Extensions;
using Microsoft.Extensions.Logging;
using Web.Api.Data.Infrastructure;

namespace Web.Api.Tests
{
    public class CustomWebApplicationFactory<TStartup> : WebApplicationFactory<TStartup> where TStartup: class
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.ConfigureServices(services =>
            {
                // Create a new service provider.
                var serviceProvider = new ServiceCollection()
                    //.AddEntityFrameworkInMemoryDatabase()
                    .BuildServiceProvider();

                // Add a database context (ApplicationDbContext) using an in-memory 
                // database for testing.
                services.AddNHibernate("Server=10.48.106.122;port=5432;Database=ITGDB;User Id=pguser01;Password=Ataesert12#");
                //services.AddScoped<RedisConnection>(_ => new RedisConnection("plkrcon23q1:6379,password=foobared"));

                // Build the service provider.
                var sp = services.BuildServiceProvider();
            });
        }
    }
}
