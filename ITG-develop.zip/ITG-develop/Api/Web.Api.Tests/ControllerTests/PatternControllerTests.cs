﻿using Application.Services;
using Application.Services.Interfaces;
using Application.Services.ViewModels;
using AutoMapper;
using CSharpFunctionalExtensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Controllers;
using Web.Api.Data.Common;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Paging;
using Web.Api.Dtos;
using Web.Api.Utils;
using Xunit;

namespace Web.Api.Tests.ControllerTests
{
    public class PatternControllerTests
    {
        private readonly Mock<IPatternService> _patternService;
        private readonly PatternsController _controller;
        private readonly Mock<IMapper> _mapper;
        private readonly Mock<IPatternRepository> _patternRepository;
        private readonly Mock<IStorageRepository> _patternStorageRepository;

        public PatternControllerTests()
        {
            _patternRepository = new Mock<IPatternRepository>();
            _patternStorageRepository = new Mock<IStorageRepository>();
            _patternService = new Mock<IPatternService>();
            _mapper = new Mock<IMapper>();
            _controller = new PatternsController(_patternService.Object, null, _mapper.Object, null);

            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
                            {
                                new Claim(ClaimTypes.NameIdentifier, "10")
                            }, "someAuthTypeName"))
                }
            };
        }

        [Fact]
        public async Task GetPattern_return_NotFound_when_pattern_content_not_found()
        {
            //arrange
            _patternService.Setup(x => x.GetPatternContent(It.IsAny<string>()))
                .ReturnsAsync(Result.Fail<PatternContentResult>("Pattern Content Not Found"));

            //act
            var result = await _controller.GetPatternFile("hash");

            //assert
            var notFoundResult = Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public async Task GetPatterns_return_PatternDTO_paged_result_when_data_exist()
        {
            //arrange
            PagedResult<Pattern> patternPageResult = new PagedResult<Pattern>()
            {
                CurrentPage = 1,
                PageCount = 1,
                PageSize = 3,
                RowCount = 3,
                Results = new List<Pattern>()
                {
                    Pattern.CreateNew("10000", "sample.jpg", "tsfd", "fdsfsd1", "fdsfd"),
                    Pattern.CreateNew("10001", "sample2.jpg", "tsfd", "fdsfsd2", "fdsfd"),
                    Pattern.CreateNew("10002", "sample3.jpg", "tsfd", "fdsfsd3", "fdsfd")
                }
            };

            _patternService.Setup(x => x.GetPagedAsync(It.IsAny<int>(), It.IsAny<int>()))
                .ReturnsAsync(patternPageResult);

            _patternService.Setup(x => x.GetMultiplePatternContent(new string[] { "fdsfsd1", "fdsfsd2", "fdsfsd3" }))
                .ReturnsAsync(new List<PatternContent>()
                {
                    PatternContent.Create("fdsfsd1", new byte[]{ 1 }),
                    PatternContent.Create("fdsfsd2", new byte[]{ 1 }),
                    PatternContent.Create("fdsfsd3", new byte[]{ 1 }),
                });

            //act
            var result = await _controller.GetPatterns(1, 3);

            var okResult = (OkObjectResult)result;
            var envelope = (Envelope<PagedResult<PatternDTO>>)okResult.Value;

            //assert
            Assert.IsType<Envelope<PagedResult<PatternDTO>>>(okResult.Value);
            Assert.Equal(HttpStatusCode.OK, (HttpStatusCode)okResult.StatusCode);
            Assert.Equal(3, envelope.Result.Results.Count);
        }

        [Fact]
        public async Task CreatePattern_return_BadRequest_when_pattern_is_null()
        {
            var result = await _controller.CreatePattern((PatternDTO)null);

            Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task CreatePattern_return_OK_when_pattern_created_successfully()
        {
            //arrange
            var patternDTO = new PatternDTO()
            {
                Id = 10,
                ContractId = "15000",                
                ImageData = "fsfds",
                ImageHash = "dsds",
                ImageType = "jpg",
                Description = "",
                FileName = "sample.jpg"
            };
            var pattern = Pattern.CreateNew("15000", "sample.jpg", "", "dsds", "");

            _patternService.Setup(x => x.AddNewPattern(It.IsAny<Pattern>(), It.IsAny<string>(), It.IsAny<int>()))
                           .ReturnsAsync(Result.Ok);
            _mapper.Setup(x => x.Map<PatternDTO, Pattern>(patternDTO))
                   .Returns(pattern);

            //act
            var result = await _controller.CreatePattern(patternDTO);

            //assert
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public async Task DeletePattern_delete_PatternContent_when_pattern_removed_successfully()
        {
            //arrange
            _patternService.Setup(x => x.DeletePattern(It.IsAny<string>(), It.IsAny<int>()))
                           .ReturnsAsync(Result.Ok);

            _patternService.Setup(x => x.DeletePatternContent(It.IsAny<string>()))
                           .ReturnsAsync(Result.Ok);

            //act
            var result = await _controller.DeletePattern("hash");

            //assert
            _patternService.Verify(x => x.DeletePatternContent(It.IsAny<string>()), Times.Once);
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public async Task DeletePattern_delete_PatternContent_deletion_not_invoked_when_Pattern_not_removed()
        {
            //arrange
            _patternService.Setup(x => x.DeletePattern(It.IsAny<string>(), It.IsAny<int>()))
                           .ReturnsAsync(Result.Fail("Failed to delete Pattern"));

            _patternService.Setup(x => x.DeletePatternContent(It.IsAny<string>()))
                           .ReturnsAsync(Result.Ok);

            //act
            var result = await _controller.DeletePattern("hash");

            //assert
            _patternService.Verify(x => x.DeletePatternContent(It.IsAny<string>()), Times.Never);
            Assert.IsType<BadRequestObjectResult>(result);
        }

        //[Fact]
        //public async Task UpdatePattern_return_BadRequest_when_pattern_not_found()
        //{
        //    //arrange
        //    var patternDTO = new PatternDTO()
        //    {
        //        Id = 10,
        //        ContractId = "15000",                
        //        ImageData = "fsfds",
        //        ImageHash = "dsds",
        //        ImageType = "jpg",
        //        Description = "",
        //        FileName = "sample.jpg"
        //    };

        //    _patternService.Setup(x => x.GetPatternById(It.IsAny<long>()))
        //        .ReturnsAsync(Result.Fail<Pattern>("Pattern Not Found"));

        //    //act
        //    var result = await _controller.UpdatePattern((long)10, patternDTO);

        //    //assert
        //    _patternService.Verify(x => x.UpdatePattern(It.IsAny<Pattern>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Never);
        //    Assert.IsType<BadRequestObjectResult>(result);
        //}

        //[Fact]
        //public async Task UpdatePattern_return_Ok_when_pattern_updated_successfully()
        //{
        //    //arrange
        //    var patternDTO = new PatternDTO()
        //    {
        //        Id = 10,
        //        ContractId = "15000",                
        //        ImageData = "fsfds",
        //        ImageHash = "dsds",
        //        ImageType = "jpg",
        //        Description = "",
        //        FileName = "sample.jpg"
        //    };
        //    var pattern = Pattern.CreateNew("15000", "sample.jpg", "", "dsds", "");

        //    _patternService.Setup(x => x.GetPatternById(It.IsAny<long>()))
        //        .ReturnsAsync(Result.Ok<Pattern>(pattern));
        //    _patternService.Setup(x => x.UpdatePattern(It.IsAny<Pattern>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()))
        //        .ReturnsAsync(Result.Ok());
        //    _mapper.Setup(x => x.Map<Pattern>(patternDTO))
        //        .Returns(pattern);

        //    //act
        //    var result = await _controller.UpdatePattern((long)10, patternDTO);

        //    //assert
        //    _patternService.Verify(x => x.UpdatePattern(It.IsAny<Pattern>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        //    Assert.IsType<OkObjectResult>(result);
        //}
    }
}
