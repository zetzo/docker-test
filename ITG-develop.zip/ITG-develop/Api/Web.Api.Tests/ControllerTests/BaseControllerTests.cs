﻿using Application.Services.Interfaces;
using AutoMapper;
using Moq;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;
using System.Threading;
using Web.Api.Controllers;
using Xunit;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.CompilerServices;

namespace Web.Api.Tests.ControllerTests
{
    public class BaseControllerTests
    {
        private readonly PatternsController _controller;
        private readonly Mock<IPatternService> _patternService;
        private readonly Mock<IMapper> _mapper;

        public BaseControllerTests()
        {
            _patternService = new Mock<IPatternService>();
            _mapper = new Mock<IMapper>();
            _controller = new PatternsController(_patternService.Object, null, _mapper.Object, null);
        }

        [Fact]
        public void BaseController_UserClaims_GetUserId()
        {
            // Arrange
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
                    {
                                        new Claim(ClaimTypes.NameIdentifier, "10")
                    }, "someAuthTypeName"))
                }
            };

            // Act
            var userId = _controller.GetUserId();

            // Assert
            userId.Should().Equals(10);
        }
    }
}
