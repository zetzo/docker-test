﻿using Microsoft.AspNetCore.Mvc.Testing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Web.Api.Tests.IntegrationTests
{
    public class PatternTests : IClassFixture<CustomWebApplicationFactory<Web.Api.Startup>>
    {
        private readonly HttpClient _client;
        private CustomWebApplicationFactory<Web.Api.Startup> _factory;

        public PatternTests(CustomWebApplicationFactory<Web.Api.Startup> factory)
        {
            _factory = factory;
            _client = factory.CreateClient(new WebApplicationFactoryClientOptions
            {
                AllowAutoRedirect = false
            });
        }

        //public async Task 
    }
}
