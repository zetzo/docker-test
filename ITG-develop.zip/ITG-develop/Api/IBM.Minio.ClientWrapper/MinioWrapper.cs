﻿using Minio;
using Minio.DataModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace IBM.Minio.ClientWrapper
{
    public class MinioWrapper
    {
        private readonly MinioClient _minioClient;
        public MinioWrapper(MinioClient minioClient)
        {
            _minioClient = minioClient;
        }

        public async Task<byte[]> GetObjectAsync(string bucketName, string objectName, CancellationToken cancellationToken = default)
        {
            await _minioClient.StatObjectAsync(bucketName, objectName, cancellationToken: cancellationToken);
            using (MemoryStream ms = new MemoryStream())
            {
                await _minioClient.GetObjectAsync(bucketName, objectName, (x) => x.CopyTo(ms));
                return ms.ToArray();
            }
        }

        public  Task<bool> BucketExistsAsync(string bucketName, CancellationToken cancellationToken = default) => _minioClient.BucketExistsAsync(bucketName, cancellationToken);
        public Task MakeBucketAsync(string bucketName, CancellationToken cancellationToken = default) => _minioClient.MakeBucketAsync(bucketName, cancellationToken: cancellationToken);
        
        public Task PutObjectAsync(string bucketName, string key, Stream stream, long size, CancellationToken cancellationToken = default)
            => _minioClient.PutObjectAsync(bucketName, key, stream, size, cancellationToken: cancellationToken);

        public Task RemoveObjectAsync(string bucketName, string key, CancellationToken cancellationToken = default)
            => _minioClient.RemoveObjectAsync(bucketName, key, cancellationToken: cancellationToken);       
        
        public Task<IReadOnlyList<MinioItem>> ListObjectAsync(string bucketName, string prefix = null)
        {
            List<MinioItem> minioItems = new List<MinioItem>();
            IObservable<Item> observable = _minioClient.ListObjectsAsync(bucketName, prefix);            
            //IDisposable subscription = observable.Subscribe(
            //        item => Console.WriteLine("OnNext: {0}", item.Key),
            //        ex => Console.WriteLine("OnError: {0}", ex.Message),
            //        () => Console.WriteLine("OnComplete: {0}"));

            IDisposable subscription = observable.Subscribe(item => minioItems.Add(new MinioItem { Key = item.Key }));            
            return Task.FromResult((IReadOnlyList<MinioItem>)minioItems.AsReadOnly());
        }        
    }

    public class MinioItem
    {
        public string Key { get; set; }
    }
}
