﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RabbitMQ.Client;
using Serilog;
using Serilog.Sinks.Elasticsearch;
using System;
using System.Text;
using System.Threading.Tasks;
using Coravel;
using Microsoft.Extensions.Options;
using Smart.Matching.DocumentProvider.Tasks;
using Application.Services.Configuration;
using Application.Services;
using Matching.OutcomeProcessor.Providers.Dapper;
using IBM.NetCore.RabbitMQ;
using IBM.NetCore.RabbitMQ.Interfaces;
using IBM.Minio.ClientWrapper;
using Minio;
using Application.Services.Extensions;
using Web.Api.Data.Extensions;
//using RabbitMQ.ClientWrapper;
//using RabbitMQ.ClientWrapper.Interfaces;

namespace Smart.Matching.DocumentProvider
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            await Service(args);
        }

        private static async Task Service(string[] args)
        {
            IHostBuilder builder = new HostBuilder()
             .ConfigureAppConfiguration((hostingContext, config) =>
             {
                 if (args != null)
                 {
                     config.AddCommandLine(args);
                 }

                 config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
                 config.AddJsonFile($"appsettings.{hostingContext.HostingEnvironment.EnvironmentName}.json", optional: true, reloadOnChange: true);
                 config.AddEnvironmentVariables();
             })
           .ConfigureServices((hostingContext, services) =>
           {
               services.AddOptions();
               services.AddNHibernate(hostingContext.Configuration.GetConnectionString("ITG_DB"));               
               
               services.Configure<RabbitSettings>(hostingContext.Configuration.GetSection("RabbitMq"));

               var connectionFactory = new ConnectionFactory();
               hostingContext.Configuration.GetSection("RabbitMq:RabbitMqConnection").Bind(connectionFactory);
               services.AddScoped<IConnectionFactory>(sp => connectionFactory);

               services.AddTransient<IRabbitMQPersistentConnection, DefaultRabbitMQPersistentConnection>();               
               services.AddTransient<IRpcQueueConsumer, RpcQueueConsumer>();
               services.AddScoped<DapperProvider>(_ => new DapperProvider(hostingContext.Configuration.GetConnectionString("ITG_DB")));               
               
               services.AddMinioWrapper(hostingContext.Configuration);
               services.AddScoped<MinioWrapper>();

               services.Configure<MatchingReceiverTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:MatchingReceiverTask"));
               services.Configure<MinioStorageConfiguration>(hostingContext.Configuration.GetSection("MinioStorage"));

               services.AddTransient<MatchingReceiverTask>();
               services.AddScheduler();
           })
           .UseSerilog((hostingContext, logging) =>
           {
               logging.ReadFrom.Configuration(hostingContext.Configuration);

               KibanaConfiguration kibanaConfiguration = new KibanaConfiguration();
               var kibanaSection = hostingContext.Configuration.GetSection("Kibana");
               kibanaSection.Bind(kibanaConfiguration);

               if (kibanaSection.Exists())
               {
                   logging.WriteTo.Elasticsearch(new ElasticsearchSinkOptions(new Uri(kibanaConfiguration.Uri))
                   {
                       MinimumLogEventLevel = System.Enum.Parse<Serilog.Events.LogEventLevel>(kibanaConfiguration.MinimumLevel, true),
                       AutoRegisterTemplate = kibanaConfiguration.AutoRegisterTemplate,
                       ModifyConnectionSettings = x => x.BasicAuthentication(kibanaConfiguration.User, kibanaConfiguration.Password).ServerCertificateValidationCallback((o, certificate, arg3, arg4) =>
                       {
                           return true;
                       }),
                       BatchPostingLimit = kibanaConfiguration.BatchPostingLimit,
                       QueueSizeLimit = kibanaConfiguration.QueueSizeLimit,
                       IndexFormat = kibanaConfiguration.IndexFormat,
                       AutoRegisterTemplateVersion = System.Enum.Parse<AutoRegisterTemplateVersion>(kibanaConfiguration.AutoRegisterTemplateVersion, true),
                       FailureCallback = e => Console.WriteLine("Unable to submit event " + e.MessageTemplate),
                       EmitEventFailure = EmitEventFailureHandling.WriteToSelfLog |
                                          EmitEventFailureHandling.WriteToFailureSink |
                                          EmitEventFailureHandling.RaiseCallback,
                   });
               }
           });
            var host = builder.Build();
            host.Services.UseScheduler(scheduler =>
            {                
                var sendToMatchingTaskConfiguration = host.Services.GetService<IOptions<MatchingReceiverTaskConfiguration>>();
                scheduler.Schedule<MatchingReceiverTask>().EveryFiveSeconds().PreventOverlapping(nameof(MatchingReceiverTask)).When(() => Task.FromResult(sendToMatchingTaskConfiguration.Value.Enabled));
            });

            await host.RunAsync();
        }
    }
}
