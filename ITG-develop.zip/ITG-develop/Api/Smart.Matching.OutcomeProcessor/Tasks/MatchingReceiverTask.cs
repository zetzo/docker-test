﻿using Application.Services.Configuration;
using Application.Services.Extensions;
using IBM.NetCore.Coravel;
using IBM.NetCore.RabbitMQ.Interfaces;
using Matching.OutcomeProcessor.Providers.Dapper;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Minio.DataModel;
using Polly;
//using RabbitMQ.ClientWrapper.Interfaces;
using Smart.Matching.DocumentProvider.Models;
using Smart.Matching.OutcomeProcessor.Models;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace Smart.Matching.DocumentProvider.Tasks
{
    internal class MatchingReceiverTask : InvocableBase<MatchingReceiverTask>
    {
        private readonly IRpcQueueConsumer _consumer;
        private readonly DapperProvider _dapperProvider;
        private readonly IOptions<MatchingReceiverTaskConfiguration> _matchingReceiverConfiguration;     

        public MatchingReceiverTask(ILogger<MatchingReceiverTask> logger, IOptions<MatchingReceiverTaskConfiguration> matchingReceiverConfiguration, IRpcQueueConsumer consumer, DapperProvider dapperProvider) : base(logger)
        {
            _consumer = consumer;
            _matchingReceiverConfiguration = matchingReceiverConfiguration;
            _dapperProvider = dapperProvider;
        }

        protected override async Task ExecuteAsync()
        {
            _logger.LogInformation("MatchingReceiverTask - Started");

            _consumer.Receive<MatchingResultModel>(Handle);

            await Task.Delay(int.MaxValue);

            _logger.LogInformation("MatchingReceiverTask - Ended");
            await Task.CompletedTask;
        }

        private async Task Handle(MatchingResultModel matchingResultModel)
        {
            _logger.LogInformation($"Mathing Result {matchingResultModel.ContractId} : {matchingResultModel.Score}");
            await _dapperProvider.Insert(new OutcomeModel()
            {
                DateCreated = DateTime.UtcNow,
                ContractId = matchingResultModel.ContractId,
                FileName = matchingResultModel.FileName,
                Score = matchingResultModel.Score
            });

            string closingDocumentName = Path.Combine(_matchingReceiverConfiguration.Value.ClosingDocumentsInProgressPath, matchingResultModel.FileName);
            string destinationFilePath = Path.Combine(_matchingReceiverConfiguration.Value.ClosingDocumentsUnMatchedPath, Path.GetFileName(matchingResultModel.FileName));

            if (matchingResultModel.Score > 300)
            {
                destinationFilePath = Path.Combine(_matchingReceiverConfiguration.Value.ClosingDocumentsMatchedPath, Path.GetFileName(matchingResultModel.FileName));
                
            }
            else if(matchingResultModel.Score > 11 || matchingResultModel.Score < 299)
            {
                destinationFilePath = Path.Combine(_matchingReceiverConfiguration.Value.ClosingDocumentsAmbiguousPath, Path.GetFileName(matchingResultModel.FileName));
            }            

            if(File.Exists(closingDocumentName))
                await FileExt.MoveFileAsync(closingDocumentName, destinationFilePath, true, CancellationToken.None);

            //_logger.LogInformation($"Deleting {closingDocumentName}");

            //var deleteFilePolicy = Policy.Handle<Exception>()
            //                .WaitAndRetry(3, retryAttempt =>
            //                TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));

            //deleteFilePolicy.Execute(() =>
            //    FileExt.DeleteIfExists(closingDocumentName)
            //);

            //

            await Task.CompletedTask;
        }
    }
}
