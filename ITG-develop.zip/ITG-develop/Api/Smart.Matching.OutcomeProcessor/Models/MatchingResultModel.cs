﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smart.Matching.DocumentProvider.Models
{
    public sealed class MatchingResultModel
    {
        public string FileName { get; set; }
        public string ContractId { get; set; }
        public int Score { get; set; }
    }
}
