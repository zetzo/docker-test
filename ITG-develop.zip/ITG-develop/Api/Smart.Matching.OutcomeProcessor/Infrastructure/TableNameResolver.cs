﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Dapper.SimpleCRUD;

namespace Matching.OutcomeProcessor.Providers.Dapper
{
    public class TableNameResolver : ITableNameResolver
    {
        public string ResolveTableName(Type type)
        {
            return $"smart.matching_outcome";
        }
    }
}
