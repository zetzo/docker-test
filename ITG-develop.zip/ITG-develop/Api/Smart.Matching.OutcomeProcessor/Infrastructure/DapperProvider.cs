﻿using System;
using System.Threading.Tasks;
using Npgsql;
using Dapper;
using Smart.Matching.OutcomeProcessor.Models;

namespace Matching.OutcomeProcessor.Providers.Dapper
{
    public class DapperProvider
    {
        private readonly string _connectionString;

        public DapperProvider(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task Insert(OutcomeModel outcome)
        {
            var resolver = new TableNameResolver();
            SimpleCRUD.SetTableNameResolver(resolver);
            SimpleCRUD.SetDialect(SimpleCRUD.Dialect.PostgreSQL);

            using (var connection = new NpgsqlConnection(_connectionString))
            {
                await connection.InsertAsync<int, OutcomeModel>(outcome);
            };
        }

        //public async Task InsertLog(ProcessingFailedLog log)
        //{
        //    //var resolver = new TableNameResolver();
        //    //SimpleCRUD.SetTableNameResolver(resolver);
        //    SimpleCRUD.SetDialect(SimpleCRUD.Dialect.PostgreSQL);

        //    using (var connection = new NpgsqlConnection(ConfigurationProvider.GetConnectionString("DefaultConnection")))
        //    {
        //        var result = await connection.InsertAsync<ProcessingFailedLog>(log);
        //    };
        //}
    }
}
