﻿using Application.Services;
using Application.Services.Configuration;
using Application.Services.Extensions;
using Application.Services.Helpers;
using Application.Services.Services;
using Capturify.Api;
using CSharpFunctionalExtensions;
using IBM.NetCore.Coravel;
using ImageMagick;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SixLabors.ImageSharp.Metadata;
using Smart.Matching.DocumentProvider.Chains;
using Smart.Matching.DocumentProvider.Infrastructure;
using Smart.Matching.OutcomeProcessor.Models;
using System;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Smart.Matching.DocumentProvider.Tasks
{
    internal class ClosingDocumentMatchingTask : InvocableBase<ClosingDocumentMatchingTask>
    {        
        private readonly ContractFinder _contractFinder;
        private readonly IOptions<SendToMatchingTaskConfiguration> _sendToMatchingTaskConfiguration;     
        private readonly PatternMatchingService _patternMatchingService;
        private readonly IMatchingServiceClient _matchingServiceClient;
        private readonly DapperProvider _dapperProvider;
        private readonly MatchingHandler _matchingHandler;
        private readonly SyncClient _syncClient;

        public ClosingDocumentMatchingTask(ILogger<ClosingDocumentMatchingTask> logger, IMatchingServiceClient matchingServiceClient, ContractFinder contractFinder, IOptions<SendToMatchingTaskConfiguration> sendToMatchingTaskConfiguration,
            PatternMatchingService patternMatchingService, DapperProvider dapperProvider, SyncClient syncClient) : base(logger)
        {
            _contractFinder = contractFinder;
            _matchingServiceClient = matchingServiceClient;
            _sendToMatchingTaskConfiguration = sendToMatchingTaskConfiguration;
            _patternMatchingService = patternMatchingService;
            _dapperProvider = dapperProvider;
            _syncClient = syncClient;

            _matchingHandler = new RawMatchingHandler(matchingServiceClient);
            _matchingHandler.AddNext(new RightAutoGammaMatchingHandler(matchingServiceClient));
            _matchingHandler.AddNext(new BothAutoGammaMatchingHandler(matchingServiceClient));
        }

        protected async Task<ClosingDocumentValidationResult> ValidateClosingDocument(FileInfo closingDocumentFile)
        {
            var pdfMetaData = PdfHelper.Instance.ReadMetadaFromFile(closingDocumentFile.FullName);

            if (pdfMetaData.IsFailure)
                return ClosingDocumentValidationResult.NotPdf;

            Result<string> contractResult = _contractFinder.GetFromClosingDocument(closingDocumentFile.Name);

            if (contractResult.IsFailure)
                return ClosingDocumentValidationResult.WrongFileName;

            _logger.LogInformation($"Contract found: {contractResult.Value}");

            var patternContentResult = await _patternMatchingService.GetPatternByContractIdNew(contractResult.Value);

            if (patternContentResult.IsFailure)
                return ClosingDocumentValidationResult.ContractNotFound;
            else if(patternContentResult.IsSuccess && patternContentResult.Value.IsVendorHasNoStamp)
                return ClosingDocumentValidationResult.NoStamp;

            return ClosingDocumentValidationResult.Success(contractResult.Value, patternContentResult.Value.Content, pdfMetaData.Value.PagesCount);
        }
              
        private byte[] GetBytesFromPDF(string fullFileName, int pageToTake)
        {
            var fileContent = File.ReadAllBytes(fullFileName);

            _syncClient.CutPdf(null, fileContent, pageToTake);

            if (_syncClient.Result.Status != "Error")
            {
                byte[] imageResulInBytes = _syncClient.Result.Result.Pages.First().Content;

                return imageResulInBytes;
            }

            return new byte[0];            
        }       

        private async Task ExtractHelper(string contractId, string fullName, int pageCount, byte[] patternContent)
        {
            try
            {
                string destFolder = Path.Combine($"/smart/pairs/{contractId}");

                if (!Directory.Exists(destFolder))
                    Directory.CreateDirectory(destFolder);

                string pagePath = Path.Combine(destFolder, $"{contractId}_0.png");
                string patternPath = Path.Combine(destFolder, $"{contractId}.png");

                if (File.Exists(pagePath))
                    pagePath = GenerateNameWithIteration(pagePath);

                //if (!File.Exists(patternPath))
                //{
                var matchingRule = await _patternMatchingService.GetMatchingRule(contractId);

                byte[] imageBytes = GetBytesFromPDF(fullName, pageCount);

                try
                {
                    imageBytes = await AutoGammaAsync(imageBytes).TimeoutAfter(TimeSpan.FromSeconds(6));
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                }

                await File.WriteAllBytesAsync(pagePath, imageBytes);

                try
                {
                    patternContent = await AutoGammaAsync(patternContent).TimeoutAfter(TimeSpan.FromSeconds(6));
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

                if (!File.Exists(patternPath))
                    await File.WriteAllBytesAsync(patternPath, patternContent);
                //}
            }
            catch (Exception e)
            {

            }
        }

        private async Task<byte[]> AutoGammaAsync(byte[] imageData)
        {
            if (imageData.Length == 0)
                return imageData;

            return await Task.Run<byte[]>(() =>
            {
                using (var outPutData = new MemoryStream())
                using (var image = new MagickImage(imageData))
                {
                    image.AutoGamma();
                    image.Write(outPutData);

                    return outPutData.ToArray();
                }
            });
        }

        private string GenerateNameWithIteration(string start)
        {
            int i = 0;
            while (File.Exists(start))
            {
                start = start.Replace($"_{i}".ToString(), $"_{(++i)}".ToString());
            }
            return start;
        }

        protected async Task HelperExportAsync()
        {
            foreach (var closingDocumentFile in new DirectoryInfo(_sendToMatchingTaskConfiguration.Value.ClosingDocumentsSourcePath).GetFiles().Take(_sendToMatchingTaskConfiguration.Value.ImportBatchSize))
            {
                _logger.LogInformation($"exporting {closingDocumentFile.FullName}");

                ClosingDocumentValidationResult closingDocumentValidationResult = await ValidateClosingDocument(closingDocumentFile);

                string destinationFilePath = Path.Combine(_sendToMatchingTaskConfiguration.Value.ClosingDocumentsUnMatchedPath, closingDocumentFile.Name);

                if (closingDocumentValidationResult.IsSuccess)
                {
                    int expectedPage = _contractFinder.GetSpecificPageFromClosingDocument(closingDocumentValidationResult.PageCount);

                    await ExtractHelper(closingDocumentValidationResult.ContractId, closingDocumentFile.FullName, expectedPage, closingDocumentValidationResult.PatternContent);
                }
            }
        }

       

        protected override async Task ExecuteAsync()
        {
            //await HelperExportAsync();

            _logger.LogInformation("SendToMatchingTask - Started");

            foreach (var closingDocumentFile in new DirectoryInfo(_sendToMatchingTaskConfiguration.Value.ClosingDocumentsSourcePath).GetFiles().Take(_sendToMatchingTaskConfiguration.Value.ImportBatchSize))
            {
                _logger.LogInformation($"Processing {closingDocumentFile.FullName}");

                ClosingDocumentValidationResult closingDocumentValidationResult = await ValidateClosingDocument(closingDocumentFile);

                string destinationFilePath = Path.Combine(_sendToMatchingTaskConfiguration.Value.ClosingDocumentsUnMatchedPath, closingDocumentFile.Name);

                if (closingDocumentValidationResult.IsSuccess)
                {
                    var matchingRule = await _patternMatchingService.GetMatchingRule(closingDocumentValidationResult.ContractId);

                    int expectedPage = _contractFinder.GetSpecificPageFromClosingDocument(closingDocumentValidationResult.PageCount);

                    _logger.LogInformation($"taking {expectedPage} page");

                    byte[] closingDocumentContent = GetBytesFromPDF(closingDocumentFile.FullName, expectedPage);

                    int score = _matchingHandler.Handle(-1, MatchingPayload.Create(closingDocumentValidationResult.PatternContent, closingDocumentContent, closingDocumentValidationResult.ContractId, closingDocumentFile.Name));

                    _logger.LogInformation($"score is {score}");

                    if (score >= matchingRule.Matched)
                    {
                        destinationFilePath = Path.Combine(_sendToMatchingTaskConfiguration.Value.ClosingDocumentsMatchedPath, closingDocumentFile.Name);

                    }
                    else if (score > matchingRule.UnMatched && score < matchingRule.Matched)
                    {
                        destinationFilePath = Path.Combine(_sendToMatchingTaskConfiguration.Value.ClosingDocumentsAmbiguousPath, closingDocumentFile.Name);
                    }

                    await _dapperProvider.Insert(new OutcomeModel
                    {
                        ContractId = closingDocumentValidationResult.ContractId,
                        DateCreated = DateTime.Now,
                        FileName = closingDocumentFile.Name,
                        Score = score
                    });

                    await FileExt.MoveFileAsync(closingDocumentFile.FullName, destinationFilePath, true, CancellationToken.None);
                }
                else
                {
                    destinationFilePath = Path.Combine(_sendToMatchingTaskConfiguration.Value.ClosingDocumentsUnMatchedPath, closingDocumentFile.Name);
                    if(closingDocumentValidationResult.VendorHasNoStamp)
                    {
                        destinationFilePath = Path.Combine(_sendToMatchingTaskConfiguration.Value.ClosingDocumentsNoStampPath, closingDocumentFile.Name);
                    }                

                    await FileExt.MoveFileAsync(closingDocumentFile.FullName, destinationFilePath, true, CancellationToken.None);
                }
            }
            _logger.LogInformation("SendToMatchingTask - Ended");
        }

        internal class ClosingDocumentValidationResult
        {
            public string ContractId { get; set; }
            public byte[] PatternContent { get; set; }
            public int PageCount { get; set; }

            public bool IsPdf { get; set; }
            public bool ContractNameInFileNotFound { get; set; }
            public bool ContractIdNotFound { get; set; }

            public bool VendorHasNoStamp { get; set; }
            public bool IsSuccess { get; set; }

            public static ClosingDocumentValidationResult NotPdf => new ClosingDocumentValidationResult { IsPdf = false };
            public static ClosingDocumentValidationResult WrongFileName => new ClosingDocumentValidationResult { ContractNameInFileNotFound = true };
            public static ClosingDocumentValidationResult ContractNotFound => new ClosingDocumentValidationResult { ContractIdNotFound = true };

            public static ClosingDocumentValidationResult NoStamp => new ClosingDocumentValidationResult { VendorHasNoStamp = true , IsSuccess = false };

            public static ClosingDocumentValidationResult Success(string contractId, byte[] patternContent, int pageCount) =>
                new ClosingDocumentValidationResult { IsSuccess = true, IsPdf = true, ContractId = contractId, PatternContent = patternContent, PageCount = pageCount };
        }
    }
}
