﻿using System;
using System.Threading.Tasks;
using Npgsql;
using Dapper;
using Smart.Matching.OutcomeProcessor.Models;

namespace Smart.Matching.DocumentProvider.Infrastructure
{
    public class DapperProvider
    {
        private readonly string _connectionString;

        public DapperProvider(string connectionString)
        {
            _connectionString = connectionString;
        }
       
        public async Task Insert(OutcomeModel outcome)
        {
            var resolver = new TableNameResolver();
            SimpleCRUD.SetTableNameResolver(resolver);
            SimpleCRUD.SetDialect(SimpleCRUD.Dialect.PostgreSQL);

            using (var connection = new NpgsqlConnection(_connectionString))
            {
                await connection.InsertAsync<int, OutcomeModel>(outcome);
            };
        }
    }
}
