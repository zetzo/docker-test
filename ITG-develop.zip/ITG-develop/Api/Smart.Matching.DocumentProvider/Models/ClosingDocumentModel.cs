﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smart.Matching.DocumentProvider.Models
{
    public sealed class ClosingDocumentModel
    {
        public string FileName { get; private set; }
        public string ContractId { get; private set; }
        public string Content { get; private set; }
        public bool HasError { get; private set; }

        private ClosingDocumentModel(string fileName)
        {
            FileName = fileName;
        }

        public static ClosingDocumentModel Create(string fileName) => new ClosingDocumentModel(fileName);

        public void SetError()
        {
            HasError = true;
        }

        public void SetContractIdAndContent(string contractId, string content)
        {
            ContractId = contractId;
            Content = content;
        }
    }
}
