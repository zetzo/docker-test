﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using Serilog;
using Serilog.Sinks.Elasticsearch;
using System;
using System.Text;
using System.Threading.Tasks;
using Capturify.Api.Extensions.DependencyInjection;
using Coravel;
using Microsoft.Extensions.Options;
using Smart.Matching.DocumentProvider.Tasks;
using Application.Services.Configuration;
using IBM.NetCore.RabbitMQ;
using IBM.NetCore.RabbitMQ.Interfaces;
using Application.Services;
using Web.Api.Data.Repository;
using Web.Api.Domain.Interfaces;
using Application.Services.Services;
using Web.Api.Data.Extensions;
using Web.Api.Data.Common;
using Application.Services.Extensions;
using Smart.Matching.DocumentProvider.Infrastructure;
using IBM.NetCore.Coravel;

namespace Smart.Matching.DocumentProvider
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            await Service(args);
        }

        private static async Task Service(string[] args)
        {
            IHostBuilder builder = new HostBuilder()
             .ConfigureAppConfiguration((hostingContext, config) =>
             {
                 //if (args != null)
                 //{
                 //    config.AddCommandLine(args);
                 //}

                 config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
                 config.AddJsonFile($"appsettings.{hostingContext.HostingEnvironment.EnvironmentName}.json", optional: true, reloadOnChange: true);
                 config.AddEnvironmentVariables();
             })
           .ConfigureServices((hostingContext, services) =>
           {
               services.AddOptions();

               services.AddNHibernate(hostingContext.Configuration.GetConnectionString("ITG_DB"));

               IConnectionFactory patternMatchingConnectionFactory = new ConnectionFactory();
               hostingContext.Configuration.GetSection("RabbitMq_MATCH:RabbitMqConnection").Bind(patternMatchingConnectionFactory);

               services.Configure<PatternMatchingRabbitSettings>(hostingContext.Configuration.GetSection("RabbitMq_MATCH"));

               services.AddScoped<RpcQueueSender>(x =>
                 new PatternMatchingRpcQueueSender(new PatternMatchingRabbitMQPersistentConnection(patternMatchingConnectionFactory, x.GetRequiredService<ILogger<DefaultRabbitMQPersistentConnection>>()), x.GetRequiredService<ILogger<PatternMatchingRpcQueueSender>>(), x.GetRequiredService<IOptions<PatternMatchingRabbitSettings>>()));

               services.AddScoped<IMatchingServiceClient, MatchingServiceClient>();

               services.AddMinioWrapper(hostingContext.Configuration);

               services.AddScoped<DapperProvider>(_ => new DapperProvider(hostingContext.Configuration.GetConnectionString("ITG_DB")));
               services.Configure<MinioStorageConfiguration>(hostingContext.Configuration.GetSection("MinioStorage"));

               services.AddScoped<IRabbitMQPersistentConnection, DefaultRabbitMQPersistentConnection>();
               services.AddScoped<IRpcQueueSender, RpcQueueSender>();

               services.AddSingleton<ContractFinder>();

               services.AddSingleton<CryptoHelper>();
               services.AddScoped<IPatternRepository, PatternRepository>();
               services.AddScoped<IInnContractRepository, InnContractRepository>();
               services.AddScoped<IStorageRepository, StorageRepository>();
               services.AddScoped<IMatchingRulesRepository, MatchingRulesRepository>();
               services.AddSingleton<PatternMatchingService>();

               services.Configure<SendToMatchingTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:ClosingDocumentMatchingTask"));

               services.AddCapturify(hostingContext.Configuration);

               services.AddTransient<ClosingDocumentMatchingTask>();
               services.AddScheduler();
           })
           .UseSerilog((hostingContext, logging) =>
           {
               logging.ReadFrom.Configuration(hostingContext.Configuration);

               KibanaConfiguration kibanaConfiguration = new KibanaConfiguration();
               var kibanaSection = hostingContext.Configuration.GetSection("Kibana");
               kibanaSection.Bind(kibanaConfiguration);

               if (kibanaSection.Exists())
               {
                   logging.WriteTo.Elasticsearch(new ElasticsearchSinkOptions(new Uri(kibanaConfiguration.Uri))
                   {
                       MinimumLogEventLevel = Enum.Parse<Serilog.Events.LogEventLevel>(kibanaConfiguration.MinimumLevel, true),
                       AutoRegisterTemplate = kibanaConfiguration.AutoRegisterTemplate,
                       ModifyConnectionSettings = x => x.BasicAuthentication(kibanaConfiguration.User, kibanaConfiguration.Password).ServerCertificateValidationCallback((o, certificate, arg3, arg4) =>
                       {
                           return true;
                       }),
                       BatchPostingLimit = kibanaConfiguration.BatchPostingLimit,
                       QueueSizeLimit = kibanaConfiguration.QueueSizeLimit,
                       IndexFormat = kibanaConfiguration.IndexFormat,
                       AutoRegisterTemplateVersion = Enum.Parse<AutoRegisterTemplateVersion>(kibanaConfiguration.AutoRegisterTemplateVersion, true),
                       FailureCallback = e => Console.WriteLine("Unable to submit event " + e.MessageTemplate),
                       EmitEventFailure = EmitEventFailureHandling.WriteToSelfLog |
                                          EmitEventFailureHandling.WriteToFailureSink |
                                          EmitEventFailureHandling.RaiseCallback,
                   });
               }
           });
            var host = builder.Build();
            
            host.Services.UseScheduler(scheduler =>
            {
                var sendToMatchingTaskConfiguration = host.Services.GetService<IOptions<SendToMatchingTaskConfiguration>>();
                scheduler.Schedule<ClosingDocumentMatchingTask>().BuildWithTime(sendToMatchingTaskConfiguration.Value.Time).PreventOverlapping(nameof(ClosingDocumentMatchingTask)).When(() => Task.FromResult(sendToMatchingTaskConfiguration.Value.Enabled));
            });

            await host.RunAsync();
        }
    }
}
