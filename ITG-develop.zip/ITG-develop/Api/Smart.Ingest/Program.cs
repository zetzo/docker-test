﻿using Application.Services;
using Application.Services.Configuration;
using Application.Services.Extensions;
using Coravel;
using CSharpFunctionalExtensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using Serilog;
using Serilog.Sinks.Elasticsearch;
using Smart.Ingest.Tasks;
using System;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Data.Extensions;
using Web.Api.Data.Infrastructure;
using Web.Api.Data.Repository;
using Web.Api.Domain.Interfaces;
using Capturify.Api.Extensions.DependencyInjection;
using IBM.NetCore.RabbitMQ;
using Smart.Tasks;
using Application.Services.Services;
using MicroOrm.Dapper.Repositories.Config;
using MicroOrm.Dapper.Repositories.SqlGenerator;
using System.Data;
using Npgsql;
using Smart.Matching;

namespace Smart.Ingest
{
    class Program
    {
        static async Task Main(string[] args)
        {            
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            Console.OutputEncoding = Encoding.UTF8;
            await Service(args);
        }

        private static async Task Service(string[] args)
        {
            IHostBuilder builder = new HostBuilder()
               .ConfigureAppConfiguration((hostingContext, config) =>
               {
                   if (args != null)
                   {
                       config.AddCommandLine(args);
                   }

                   config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
                   config.AddJsonFile($"appsettings.{hostingContext.HostingEnvironment.EnvironmentName}.json", optional: true, reloadOnChange: true);
                   config.AddEnvironmentVariables();
               })
             .ConfigureServices((hostingContext, services) =>
             {
                 services.AddOptions();
                 services.AddNHibernate(hostingContext.Configuration.GetConnectionString("ITG_DB"));                 
                 services.AddMinioWrapper(hostingContext.Configuration);

                 services.Configure<PatternExtractRabbitSettings>(hostingContext.Configuration.GetSection("RabbitMq_EXTRACT"));
                 services.Configure<PatternMatchingRabbitSettings>(hostingContext.Configuration.GetSection("RabbitMq_MATCH"));

                 IConnectionFactory patternExtractConnectionFactory = new ConnectionFactory();
                 IConnectionFactory patternMatchingConnectionFactory = new ConnectionFactory();

                 hostingContext.Configuration.GetSection("RabbitMq_EXTRACT:RabbitMqConnection").Bind(patternExtractConnectionFactory);
                 hostingContext.Configuration.GetSection("RabbitMq_MATCH:RabbitMqConnection").Bind(patternMatchingConnectionFactory);
                 
                 services.AddScoped<PatternExtractRpcQueueSender>(x=>
                    new PatternExtractRpcQueueSender(new PatternExtractRabbitMQPersistentConnection(patternExtractConnectionFactory, x.GetRequiredService<ILogger<DefaultRabbitMQPersistentConnection>>()), x.GetRequiredService<ILogger<PatternExtractRpcQueueSender>>(), x.GetRequiredService<IOptions<PatternExtractRabbitSettings>>()));
                 services.AddScoped<RpcQueueSender>(x =>
                    new PatternMatchingRpcQueueSender(new PatternMatchingRabbitMQPersistentConnection(patternMatchingConnectionFactory, x.GetRequiredService<ILogger<DefaultRabbitMQPersistentConnection>>()), x.GetRequiredService<ILogger<PatternMatchingRpcQueueSender>>(), x.GetRequiredService<IOptions<PatternMatchingRabbitSettings>>()));

                 MicroOrmConfig.SqlProvider = SqlProvider.PostgreSQL;

                 services.AddScoped<IDbConnection>(sp=>new NpgsqlConnection(hostingContext.Configuration.GetConnectionString("ITG_DB")));
                 services.AddScoped<IInnContractPairRepository,InnContractPairRepository>();

                 services.Configure<DispatchTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:DispatchTask"));
                 services.Configure<PageExtractTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:PageExtractTask"));
                 services.Configure<PageCutTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:PageCutTask"));
                 services.Configure<PatternExtractTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:PatternExtractTask"));
                 services.Configure<PatternImportTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:PatternImportTask"));
                 services.Configure<KeepAliveTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:KeepAliveTask"));
                 services.Configure<SftpDownloaderTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:SftpDownloaderTask"));
                 services.Configure<DeleteContractsScaffoldTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:DeleteContractsScaffoldTask"));
                 services.Configure<NewPatternImportTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:NewPatternImportTask"));
                 services.Configure<LoadInn2ContractMapTaskConfiguration>(hostingContext.Configuration.GetSection("Smart:LoadInn2ContractMapTask"));                 
                 services.Configure<CopyFilesFromStorageConfiguration>(hostingContext.Configuration.GetSection("Smart:CopyFilesFromStorageTask"));
                 services.Configure<LoadInn2ContractMapConfiguration>(hostingContext.Configuration.GetSection("Smart:LoadInn2ContractMapTask"));
                 services.Configure<MinioStorageConfiguration>(hostingContext.Configuration.GetSection("MinioStorage"));                 

                 services.AddPatternService();
                 services.AddScoped<IMatchingServiceClient, MatchingServiceClient>();
                 services.AddScoped<IPageExtractRepository, PageExtractRepository>();
                 services.AddScoped<IPageCutRepository, PageCutRepository>();
                 services.AddScoped<IInnContractRepository, InnContractRepository>();
                 services.AddScoped<IPatternImportRepository, PatternImportRepository>();
                 services.AddScoped<IPatternImportLogRespository, PatternImportLogRespository>();
                 services.AddScoped<IMatchingRulesRepository, MatchingRulesRepository>();
                 services.AddSingleton<SmartIngestService>();
                 services.AddSingleton<PatternMatchingService>();
                 services.AddSingleton<ContractFinder>();

                 services.AddTransient<SftpDownloaderTask>();
                 services.AddTransient<DispatchDocumentTask>();
                 services.AddTransient<PageExtractTask>();
                 services.AddTransient<PageCutTask>();
                 services.AddTransient<PatternExtractTask>();                 
                 services.AddTransient<KeepAliveTask>();
                 services.AddTransient<NewPatternImportTask>();
                 services.AddTransient<DeleteContractsScaffoldTask>();                 
                 services.AddTransient<LoadInn2ContractMapTask>();
                 services.AddTransient<CopyFilesFromStorageTask>();
                 
                 services.AddCapturify(hostingContext.Configuration);
                 
                 services.AddJaeger(hostingContext.Configuration.GetSection("Jaeger").Get<JaegerConfiguration>());

                 services.AddScheduler();
             })
             .UseSerilog((hostingContext, logging) =>
             {
                 logging.ReadFrom.Configuration(hostingContext.Configuration);

                 KibanaConfiguration kibanaConfiguration = new KibanaConfiguration();
                 var kibanaSection = hostingContext.Configuration.GetSection("Kibana");
                 kibanaSection.Bind(kibanaConfiguration);

                 if (kibanaSection.Exists())
                 {
                     logging.WriteTo.Elasticsearch(new ElasticsearchSinkOptions(new Uri(kibanaConfiguration.Uri))
                     {
                         MinimumLogEventLevel = System.Enum.Parse<Serilog.Events.LogEventLevel>(kibanaConfiguration.MinimumLevel, true),
                         AutoRegisterTemplate = kibanaConfiguration.AutoRegisterTemplate,
                         ModifyConnectionSettings = x => x.BasicAuthentication(kibanaConfiguration.User, kibanaConfiguration.Password).ServerCertificateValidationCallback((o, certificate, arg3, arg4) =>
                         {
                             return true;
                         }),
                         BatchPostingLimit = kibanaConfiguration.BatchPostingLimit,
                         QueueSizeLimit = kibanaConfiguration.QueueSizeLimit,
                         IndexFormat = kibanaConfiguration.IndexFormat,
                         AutoRegisterTemplateVersion = System.Enum.Parse<AutoRegisterTemplateVersion>(kibanaConfiguration.AutoRegisterTemplateVersion, true),
                         FailureCallback = e => Console.WriteLine("Unable to submit event " + e.MessageTemplate),
                         EmitEventFailure = EmitEventFailureHandling.WriteToSelfLog |
                                            EmitEventFailureHandling.WriteToFailureSink |
                                            EmitEventFailureHandling.RaiseCallback,
                     });
                 }                
              });

            var host = builder.Build();

            host.Services.UseScheduler(scheduler =>
            {
                var sftpDownloaderTaskConfiguration = host.Services.GetService<IOptions<SftpDownloaderTaskConfiguration>>();
                var dispatchTaskConfiguration = host.Services.GetService<IOptions<DispatchTaskConfiguration>>();
                var pageExtractTaskConfiguration = host.Services.GetService<IOptions<PageExtractTaskConfiguration>>();
                var pageCutTaskConfiguration = host.Services.GetService<IOptions<PageCutTaskConfiguration>>();
                var patternExtractTaskConfiguration = host.Services.GetService<IOptions<PatternExtractTaskConfiguration>>();                
                var keepAliveTaskConfiguration = host.Services.GetService<IOptions<KeepAliveTaskConfiguration>>();
                var deleteContractsScaffoldTaskConfiguration = host.Services.GetService<IOptions<DeleteContractsScaffoldTaskConfiguration>>();
                var newPatternImportTaskConfiguration = host.Services.GetService<IOptions<NewPatternImportTaskConfiguration>>();
                var loadInn2ContractMapTaskConfiguration = host.Services.GetService<IOptions<LoadInn2ContractMapTaskConfiguration>>();
                var copyContractsFromStorageConfiguration = host.Services.GetService<IOptions<CopyFilesFromStorageConfiguration>>();
                //var confirmPatternTaskConfiguration = host.Services.GetService<IOptions<ConfirmPatternTaskConfiguration>>();

                scheduler.Schedule<SftpDownloaderTask>().BuildWithTime(sftpDownloaderTaskConfiguration.Value.Time).PreventOverlapping(nameof(SftpDownloaderTask)).When(() => Task.FromResult(sftpDownloaderTaskConfiguration.Value.Enabled));
                scheduler.Schedule<DispatchDocumentTask>().BuildWithTime(dispatchTaskConfiguration.Value.Time).PreventOverlapping(nameof(DispatchDocumentTask)).When(() => Task.FromResult(dispatchTaskConfiguration.Value.Enabled));
                scheduler.Schedule<PageExtractTask>().BuildWithTime(pageExtractTaskConfiguration.Value.Time).PreventOverlapping(nameof(PageExtractTask)).When(() => Task.FromResult(pageExtractTaskConfiguration.Value.Enabled));
                scheduler.Schedule<PageCutTask>().BuildWithTime(pageCutTaskConfiguration.Value.Time).PreventOverlapping(nameof(PageCutTask)).When(() => Task.FromResult(pageCutTaskConfiguration.Value.Enabled));
                scheduler.Schedule<PatternExtractTask>().BuildWithTime(patternExtractTaskConfiguration.Value.Time).PreventOverlapping(nameof(PatternExtractTask)).When(() => Task.FromResult(patternExtractTaskConfiguration.Value.Enabled));                
                scheduler.Schedule<KeepAliveTask>().BuildWithTime(keepAliveTaskConfiguration.Value.Time).PreventOverlapping(nameof(KeepAliveTask)).When(() => Task.FromResult(keepAliveTaskConfiguration.Value.Enabled));                
                scheduler.Schedule<DeleteContractsScaffoldTask>().BuildWithTime(deleteContractsScaffoldTaskConfiguration.Value.Time).PreventOverlapping(nameof(DeleteContractsScaffoldTask)).When(() => Task.FromResult(deleteContractsScaffoldTaskConfiguration.Value.Enabled));
                scheduler.Schedule<NewPatternImportTask>().BuildWithTime(newPatternImportTaskConfiguration.Value.Time).PreventOverlapping(nameof(NewPatternImportTask)).When(() => Task.FromResult(newPatternImportTaskConfiguration.Value.Enabled));
                scheduler.Schedule<LoadInn2ContractMapTask>().BuildWithTime(loadInn2ContractMapTaskConfiguration.Value.Time).PreventOverlapping(nameof(LoadInn2ContractMapTask)).When(() => Task.FromResult(loadInn2ContractMapTaskConfiguration.Value.Enabled));
                scheduler.Schedule<CopyFilesFromStorageTask>().BuildWithTime(copyContractsFromStorageConfiguration.Value.Time).PreventOverlapping(nameof(CopyFilesFromStorageTask)).When(() => Task.FromResult(copyContractsFromStorageConfiguration.Value.Enabled));                
                //scheduler.Schedule<ConfirmPatternTask>().BuildWithTime(confirmPatternTaskConfiguration.Value.Time).PreventOverlapping(nameof(ConfirmPatternTask)).When(() => Task.FromResult(confirmPatternTaskConfiguration.Value.Enabled));
            });

            // Run it!
            await host.RunAsync();
            //await builder.RunConsoleAsync();
        }
    }
}
