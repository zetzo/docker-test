﻿using IBM.NetCore.RabbitMQ;
using IBM.NetCore.RabbitMQ.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace Smart.Ingest
{
    public sealed class PatternExtractRpcQueueSender : RpcQueueSender
    {
        public PatternExtractRpcQueueSender(IRabbitMQPersistentConnection persistentConnection, ILogger<RpcQueueSender> logger, IOptions<RabbitSettings> rabbitSettings) : base(persistentConnection, logger, rabbitSettings)
        {

        }
    }

    public sealed class PatternMatchingRpcQueueSender : RpcQueueSender
    {
        public PatternMatchingRpcQueueSender(IRabbitMQPersistentConnection persistentConnection, ILogger<RpcQueueSender> logger, IOptions<RabbitSettings> rabbitSettings) : base(persistentConnection, logger, rabbitSettings)
        {

        }
    }

    public sealed class PageCutRpcQueueSender : RpcQueueSender
    {
        public PageCutRpcQueueSender(IRabbitMQPersistentConnection persistentConnection, ILogger<RpcQueueSender> logger, IOptions<RabbitSettings> rabbitSettings) : base(persistentConnection, logger, rabbitSettings)
        {

        }
    }

    public sealed class PatternExtractRabbitMQPersistentConnection : DefaultRabbitMQPersistentConnection
    {
        public PatternExtractRabbitMQPersistentConnection(IConnectionFactory connectionFactory, ILogger<DefaultRabbitMQPersistentConnection> logger) : base(connectionFactory, logger)
        {

        }
    }

    public sealed class PatternMatchingRabbitMQPersistentConnection : DefaultRabbitMQPersistentConnection
    {
        public PatternMatchingRabbitMQPersistentConnection(IConnectionFactory connectionFactory, ILogger<DefaultRabbitMQPersistentConnection> logger) : base(connectionFactory, logger)
        {

        }
    }

    public sealed class PageCutRabbitMQPersistentConnection : DefaultRabbitMQPersistentConnection
    {
        public PageCutRabbitMQPersistentConnection(IConnectionFactory connectionFactory, ILogger<DefaultRabbitMQPersistentConnection> logger) : base(connectionFactory, logger)
        {

        }
    }

    public sealed class PatternExtractRabbitSettings : RabbitSettings
    {

    }

    public sealed class PatternMatchingRabbitSettings : RabbitSettings
    {

    }

    //public sealed class PatternMatchingConnectionFactory : ConnectionFactory
    //{

    //}
    //public sealed class PatternExtractConnectionFactory : ConnectionFactory
    //{

    //}

    //public sealed class PageCutExtractConnectionFactory : ConnectionFactory
    //{

    //}
}
