﻿using CommandLine;
using Jaeger.Thrift;
using OpenTracing;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace Smart.Ingest.Infrastructure
{    
    public static class TracingExtensions
    {
        public static ISpan SpanAsChildOf(this ITracer tracer, ISpan rootSpan, string operationName)
        {
            if (string.IsNullOrEmpty(operationName))
                throw new ArgumentNullException(nameof(operationName));

            if (rootSpan == null)
                throw new ArgumentNullException(nameof(rootSpan));

            return tracer.BuildSpan(operationName).AsChildOf(rootSpan).Start();
        }

        public static ISpan SpanAsChildOf(this ITracer tracer, ISpan rootSpan, string operationName, IEnumerable<KeyValuePair<string, string>> tags)
        {
            if (string.IsNullOrEmpty(operationName))
                throw new ArgumentNullException(nameof(operationName));

            if (rootSpan == null)
                throw new ArgumentNullException(nameof(rootSpan));

            if (tags != null)
            {
                var span = tracer.BuildSpan(operationName).AsChildOf(rootSpan).Start();
                foreach (var tag in tags)
                {
                    span.SetTag(tag.Key, tag.Value);
                }
                return span;
            }
            else
                return tracer.BuildSpan(operationName).AsChildOf(rootSpan).Start();
        }

        public static void SpanInlineAsChildOf(this ITracer tracer, ISpan rootSpan, string operationName)
        {
            if (string.IsNullOrEmpty(operationName))
                throw new ArgumentNullException(nameof(operationName));

            if (rootSpan == null)
                throw new ArgumentNullException(nameof(rootSpan));

            tracer.BuildSpan(operationName).AsChildOf(rootSpan).Start().Finish();
        }

        public static void SpanInlineAsChildOf(this ITracer tracer, ISpan rootSpan, string operationName, IEnumerable<KeyValuePair<string,string>> tags)
        {
            if (string.IsNullOrEmpty(operationName))
                throw new ArgumentNullException(nameof(operationName));

            if (rootSpan == null)
                throw new ArgumentNullException(nameof(rootSpan));

            if (tags!=null)
            {
                var span = tracer.BuildSpan(operationName).AsChildOf(rootSpan).Start();
                foreach (var tag in tags)
                {
                    span.SetTag(tag.Key, tag.Value);
                }
                span.Finish();
            }
            else
                tracer.BuildSpan(operationName).AsChildOf(rootSpan).Start().Finish();
        }

        public static void SpanInline(this ITracer tracer, string operationName)
        {
            if (string.IsNullOrEmpty(operationName))
                throw new ArgumentNullException(nameof(operationName));

            tracer.BuildSpan(operationName).Start().Finish();
        }

        public static void LogFinish(this ISpan span, string @event)
        {
            span.Log(@event).Finish();
        }
    }
}
