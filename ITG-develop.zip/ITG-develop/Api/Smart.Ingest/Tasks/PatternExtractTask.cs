﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Smart.Ingest.Model;
using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Application.Services.Configuration;
using IBM.NetCore.Coravel;
using Application.Services;
using Application.Services.Helpers;

namespace Smart.Ingest.Tasks
{
    internal sealed class PatternExtractTask : InvocableBase<PatternExtractTask>
    {
        private readonly PatternExtractRpcQueueSender _rpcQueueSender;
        private readonly IOptions<PatternExtractTaskConfiguration> _patternExtractServiceConfiguration;
        private const string WarningFromExporter = "warning";

        public PatternExtractTask(ILogger<PatternExtractTask> logger, PatternExtractRpcQueueSender rpcQueueSender, IOptions<PatternExtractTaskConfiguration> patternExtractServiceConfiguration) : base(logger)
        {
            _rpcQueueSender = rpcQueueSender;
            _patternExtractServiceConfiguration = patternExtractServiceConfiguration;
            _logger.LogDebugDetail("Ctor");
        }

        protected override async Task ExecuteAsync()
        {
            await ExtractPatterns();
        }

        public async Task ExtractPatterns()
        {
            _logger.LogInformation("ExtractPatterns - Started");

            foreach (DirectoryInfo directory in new DirectoryInfo(_patternExtractServiceConfiguration.Value.ContractsGroupPath).GetDirectories().Take(_patternExtractServiceConfiguration.Value.ImportBatchSize).OrderBy(x=>x.Name))
            {
                string rootDirectory = directory.FullName;

                var cutdirectoryInfo = directory.GetDirectories("Cut").FirstOrDefault();

                if (cutdirectoryInfo != null)
                    foreach (FileInfo file in cutdirectoryInfo.GetFiles())
                    {
                        string destinationDirectory = Path.Combine(rootDirectory, "Patterns");
                        if (!CheckIfDestinationFilesExist(file, rootDirectory))
                        {
                            string base64Content = Convert.ToBase64String(File.ReadAllBytes(file.FullName));

                            var patternExtractRequest = new PatternExtractRequest
                            {
                                FileName = file.Name,
                                Content = base64Content,
                            };

                            _logger.LogInformation($"Sending {file.Name} to Smart.Server");
                            
                            var patternExtractResponse = _rpcQueueSender.SendAndReceive<PatternExtractRequest, PatternExtractResponse>(patternExtractRequest);                            

                            _logger.LogInformation($"Getting Response {file.Name} from Smart.Server");
                            
                            byte[] byteFileContent = Convert.FromBase64String(patternExtractResponse.Message.Result.Content);
                            
                            string destinationFileName = Path.Combine(destinationDirectory, file.Name);

                            string responseFileName = patternExtractResponse.Message.Result.FileName;

                            if (responseFileName == WarningFromExporter)
                            {
                                _logger.LogInformation("Warning in Response changing file name");

                                string warningFileName = Path.GetFileNameWithoutExtension(file.Name) + $"_{WarningFromExporter.ToUpper()}_.PNG";

                                destinationFileName = Path.Combine(destinationDirectory, warningFileName);

                                _logger.LogInformation($"New destination file name {destinationFileName}");
                            }
                            
                            await File.WriteAllBytesAsync(destinationFileName, byteFileContent, CancellationToken.None);                            
                            _logger.LogInformation($"Saving {destinationFileName}");
                        }
                    }
            }
            _logger.LogInformation("ExtractPatterns - Ended");
        }

        private bool IsAddendum(string fullFileName)
        {
            string addendumfileName = Path.ChangeExtension(fullFileName, "pdf");
            if(!File.Exists(addendumfileName))
                addendumfileName = Path.ChangeExtension(fullFileName, "PDF");

            var pdfMetadata = PdfHelper.Instance.ReadMetadaFromFile(addendumfileName);

            return pdfMetadata.IsSuccess ? pdfMetadata.Value.PagesCount < 4 : false;
        }

        private bool CheckIfDestinationFilesExist(FileInfo file, string rootDirectory)
        {
            string destinationDirectory = Path.Combine(rootDirectory, "Patterns");

            if (!Directory.Exists(destinationDirectory))
                Directory.CreateDirectory(destinationDirectory);

            string destinationFileName = Path.Combine(destinationDirectory, file.Name);

            string warningFileName = Path.GetFileNameWithoutExtension(file.Name) + $"_{WarningFromExporter.ToUpper()}_.PNG";

            string possibleWarningDestinationFileName = Path.Combine(destinationDirectory, warningFileName);

            return File.Exists(destinationFileName) || File.Exists(possibleWarningDestinationFileName);
        }

        internal class DestinationFileResult
        {
            public string DestinationFileName { get; set; }
            public bool Exist { get; set; }
        }
    }
}
