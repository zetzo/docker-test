﻿using Application.Services;
using Application.Services.Configuration;
using Application.Services.Extensions;
using Application.Services.Interfaces;
using Application.Services.Services;
using Application.Services.ViewModels;
using CSharpFunctionalExtensions;
using IBM.NetCore.Coravel;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MoreLinq;
using OpenTracing;
using Smart.Ingest.Infrastructure;
using Smart.Ingest.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Models;
using Application.Services.Exceptions;
using System.Runtime.CompilerServices;
using Smart.Matching;
using Smart.Matching.DocumentProvider.Chains;

namespace Smart.Ingest.Tasks
{
    internal class NewPatternImportTask : InvocableBase<NewPatternImportTask>
    {
        private readonly PatternMatchingRpcQueueSender _rpcQueueSender;
        private readonly IOptions<NewPatternImportTaskConfiguration> _newPatternImportTaskConfiguration;
        private readonly IPatternService _patternService;
        private readonly SmartIngestService _smartIngestService;
        private readonly PatternMatchingService _patternMatchingService;
        private readonly MatchingHandler _matchingHandler;

        private readonly ITracer _tracer;

        const string addUnconfirmed = "add-unconfirmed";
        const string addConfirmed = "add-confirmed";
        const string setUconfirmed = "set-unconfirmed";
        const string deleteDirectory = "delete-directory";

        public NewPatternImportTask(ILogger<NewPatternImportTask> logger, ITracer tracer,
            IOptions<NewPatternImportTaskConfiguration> newPatternImportTaskConfiguration,
            IPatternService patternService, SmartIngestService smartIngestService, PatternMatchingService patternMatchingService,
            IMatchingServiceClient matchingServiceClient
           ) : base(logger)
        {
            _tracer = tracer;
            //_rpcQueueSender = rpcQueueSender;
            _newPatternImportTaskConfiguration = newPatternImportTaskConfiguration;
            _patternService = patternService;
            _smartIngestService = smartIngestService;
            _patternMatchingService = patternMatchingService;

            _matchingHandler = new RawMatchingHandler(matchingServiceClient);
            _matchingHandler.AddNext(new RightAutoGammaMatchingHandler(matchingServiceClient));
            _matchingHandler.AddNext(new BothAutoGammaMatchingHandler(matchingServiceClient));
        }

        public NewPatternImportTask(ILogger<NewPatternImportTask> logger,
            IOptions<NewPatternImportTaskConfiguration> newPatternImportTaskConfiguration,
            IPatternService patternService, SmartIngestService smartIngestService, PatternMatchingService patternMatchingService,
             IMatchingServiceClient matchingServiceClient

            ) : base(logger)
        {
            //_rpcQueueSender = rpcQueueSender;
            _newPatternImportTaskConfiguration = newPatternImportTaskConfiguration;
            _patternService = patternService;
            _smartIngestService = smartIngestService;
            _patternMatchingService = patternMatchingService;

            _matchingHandler = new RawMatchingHandler(matchingServiceClient);
            _matchingHandler.AddNext(new RightAutoGammaMatchingHandler(matchingServiceClient));
            _matchingHandler.AddNext(new BothAutoGammaMatchingHandler(matchingServiceClient));
        }       

        protected override async Task ExecuteAsync()
        {
            _logger.LogInformation("NewPatternImportTask - Started");

            var rootSpan = _tracer?.BuildSpan("Execute").Start();

            await ImportConfirmedPatternsTask(rootSpan);
            await ImportNewPatternsTask(rootSpan);            

            rootSpan?.Finish();

            _logger.LogInformation("NewPatternImportTask - Ended");
        }


        #region validation
        private async Task<(PatternFileResult Result, Result<string> ContractIdResult, bool Correct)> ValidateImportTask(ISpan parentSpan, FileInfo[] contractFilesInfo, string patternDirectory)
        {            
            var validateImportSpan = _tracer?.SpanAsChildOf(parentSpan, "validate-import");
            var patternImage = await PatternImageCheck(validateImportSpan, contractFilesInfo, patternDirectory);

            if (!patternImage.IsCorrect)
            {
                validateImportSpan?.Finish();
                return (Result: null, ContractIdResult: Result.Fail<string>("skip"), Correct: false);
            }

            var patternFileResult = patternImage.Result;

            var contractId = await CheckContractId(validateImportSpan, patternFileResult.PatternFile, contractFilesInfo, patternDirectory);

            if (!contractId.IsCorrect)
            {
                validateImportSpan?.Finish();
                return (Result: null, ContractIdResult: Result.Fail<string>("skip"), Correct: false);
            }

            validateImportSpan?.Finish();
            return (Result: patternFileResult, ContractIdResult: contractId.Result, true);
        }

        private async Task<(PatternFileResult Result, bool IsCorrect)> PatternImageCheck(ISpan parentSpan, FileInfo[] contractFilesInfo, string patternDirectory)
        {            
            var patternImageCheckSpan = _tracer?.SpanAsChildOf(parentSpan, "pattern-image-check");

            var patternFileResult = _patternService.FindPatternFile(contractFilesInfo, patternDirectory);

            if (!patternFileResult.Error && patternFileResult.NoPatternExportedYet)
            {
                _logger.LogInformation($"[{patternDirectory}] No pattern exported yet wait for next execute skiping");
                patternImageCheckSpan?.LogFinish("No pattern exported yet wait for next execute skiping");
                return (patternFileResult, false);
            }

            if (patternFileResult.Error)
            {
                patternImageCheckSpan?.LogFinish("Contract File Error on FindPatternFile");
                _logger.LogInformation("Contract File Error on FindPatternFile");

                await MoveContractFilesToErrorFolder(contractFilesInfo, patternDirectory, deleteOrginalDirectory: true);
                _tracer?.SpanInlineAsChildOf(patternImageCheckSpan, nameof(MoveContractFilesToErrorFolder), new Dictionary<string, string>()
                {
                    ["directory"] = _newPatternImportTaskConfiguration.Value.ErrorsFolderPath,
                    ["file(s)"] = contractFilesInfo.Select(x => x.Name).Aggregate((current, next) => current + ", " + next)
                });
                return (patternFileResult, false);
            }

            patternImageCheckSpan?.Finish();
            return (patternFileResult, true);
        }

        private async Task<(Result<string> Result, bool IsCorrect)> CheckContractId(ISpan parentSpan, string patternFile, FileInfo[] contractFilesInfo, string patternDirectory)
        {            
            var checkContractIdSpan = _tracer?.SpanAsChildOf(parentSpan, "check-contract-id");

            Result<string> contractResult = await _patternService.GetContractIdFromFile(patternFile);

            //if (contractResult.IsSuccess && contractResult.Value.Contains("59134"))
            //    contractResult = Result.Fail<string>("LS-59134 fake error");

            if (contractResult.IsFailure)
            {
                checkContractIdSpan.LogFinish($"No ContractId found {contractResult.Error}");

                await MoveContractFilesToErrorFolder(contractFilesInfo, patternDirectory, deleteOrginalDirectory: true);

                _tracer?.SpanInlineAsChildOf(checkContractIdSpan, nameof(MoveContractFilesToErrorFolder), new Dictionary<string, string>()
                {
                    ["directory"] = _newPatternImportTaskConfiguration.Value.ErrorsFolderPath,
                    ["file(s)"] = contractFilesInfo.Select(x => x.Name).Aggregate((current, next) => current + ", " + next)
                });
                return (contractResult, false);
            }

            checkContractIdSpan?.Finish();

            return (contractResult, true);
        }

        #endregion

        #region match
        public async Task MatchPattern(ISpan rootSpan, string contractId, string patternDirectory, byte[] newPatternContent, byte[] currentPatternContent)
        {
            var matchTrace = _tracer?.SpanAsChildOf(rootSpan, "match-pattern");
            int score = await Match(newPatternContent, currentPatternContent, contractId);

            _logger.LogInformation($"Matching scoring : {score}");
            matchTrace?.SetTag("score", score);

            if (score < _newPatternImportTaskConfiguration.Value.MinScoringOnConfirmed)
            {
                _tracer?.SpanInlineAsChildOf(matchTrace, setUconfirmed);
                await _patternService.UpdatePatternToUnconfirmedBy(contractId);
            }
            else
            {
                _tracer?.SpanInlineAsChildOf(matchTrace, deleteDirectory);
                DirectoryExt.DeleteIfExists(patternDirectory);
            }
            matchTrace?.Finish();
        }
        public async Task MatchPatternOnExistingMapping(ISpan parentSpan, PatternFileResult patternFileResult, string contractId, string patternDirectory, byte[] newPatternContent, byte[] currentPatternContent)
        {            
            var matchPatternOnExistingMappingSpan = _tracer?.SpanAsChildOf(parentSpan, "match-pattern-on-mapping");
            int score = await Match(newPatternContent, currentPatternContent, contractId);

            matchPatternOnExistingMappingSpan?.SetTag("score", score);

            if (score > _newPatternImportTaskConfiguration.Value.MinScoringOnConfirmed)
            {
                string successMessage = $"Scoring {score} from contractId {contractId} - adding confirmed";

                _logger.LogInformation(successMessage);

                _tracer?.SpanInlineAsChildOf(matchPatternOnExistingMappingSpan, addConfirmed);
                await _patternService.AddNewConfirmedPatternFromFile(patternFileResult.PatternFile, patternFileResult.PdfFile.Value.CreationDate, newPatternContent);

                _tracer?.SpanInlineAsChildOf(matchPatternOnExistingMappingSpan, deleteDirectory);
                DirectoryExt.DeleteIfExists(patternDirectory);
            }
            else
            {
                string errorMessage = $"Scoring {score} from contractId {contractId} - adding unconfirmed";
                _logger.LogInformation(errorMessage);

                _tracer?.SpanInlineAsChildOf(matchPatternOnExistingMappingSpan, addUnconfirmed);
                await _patternService.AddNewUnConfirmedPatternFromFile(patternFileResult.PatternFile, patternFileResult.PdfFile.Value.CreationDate, newPatternContent);
            }

            matchPatternOnExistingMappingSpan?.Finish();
        }
        #endregion

        #region import
        private async Task ImportNewPatternTask(ISpan parentSpan, FileInfo[] contractFilesInfo, string patternDirectory, string patternFullDirectory)
        {            
            var importNewPatternTaskSpan = _tracer?.SpanAsChildOf(parentSpan, "import");
            importNewPatternTaskSpan?.SetTag("contract", patternDirectory);

            try
            {                               
                var (patternFileResult, contractIdResult, correct) = await ValidateImportTask(importNewPatternTaskSpan, contractFilesInfo, patternFullDirectory);

                if (correct)
                {
                    if (patternFileResult.IsWarningFile)
                    {
                        await ImportWarningFileTask(importNewPatternTaskSpan, contractIdResult.Value, patternFileResult);
                    }
                    else
                    {
                        await ImportCorrectPatternTask(importNewPatternTaskSpan, patternFileResult, contractIdResult.Value, patternFullDirectory);
                    }
                }                
            }
            catch (Exception e)
            {
                _logger.LogError(e.Dump());
            }
            finally
            {
                importNewPatternTaskSpan?.Finish();
            }

        }
        private async Task ImportCorrectPatternTask(ISpan parentSpan, PatternFileResult patternFileResult, string contracId, string patternDirectory)
        {
            var importCorrectPatternTaskSpan = _tracer?.SpanAsChildOf(parentSpan, "import-correct");

            Maybe<Pattern> pattern = await _patternService.GetPatternByContractId(contracId);

            byte[] newPatternContent = await File.ReadAllBytesAsync(patternFileResult.PatternFileFullName);

            importCorrectPatternTaskSpan?.SetTag("pattern.exists", pattern.HasValue);
            importCorrectPatternTaskSpan?.SetTag("pattern.confirmed", pattern.HasValue ? pattern.Value.IsConfirmed : false);

            if (pattern.HasValue && pattern.Value.IsConfirmed)
            {
                _logger.LogInformation($"Confirmed pattern exists");

                Result<PatternContentResult> patternContentResult = await _patternService.GetPatternContent(pattern.Value.EntityId);
                await MatchPattern(importCorrectPatternTaskSpan, pattern.Value.ContractId, patternDirectory, newPatternContent, patternContentResult.Value.Content);
            }
            else if (pattern.HasNoValue)
            {
                _logger.LogInformation($"Pattern doesn't exist searching for another contracts");

                Result<(string ContractId, byte[] Content)> latestContractResult = await _patternService.GetLatestContractBy(contracId);

                importCorrectPatternTaskSpan?.SetTag("mapping.exists", latestContractResult.IsSuccess);

                if (latestContractResult.IsFailure)
                {
                    string errorMessage = $"pattern doesn't exists";
                    _logger.LogInformation(errorMessage);

                    _tracer?.SpanInlineAsChildOf(importCorrectPatternTaskSpan, addUnconfirmed);

                    var result = await _patternService.AddNewUnConfirmedPatternFromFile(patternFileResult.PatternFile, DateTime.Now, newPatternContent);

                    if (result.IsFailure)
                        _logger.LogError(errorMessage);
                }

                if (latestContractResult.IsSuccess)
                {
                    _logger.LogInformation($"LatestContractResult has value {latestContractResult.Value}");
                    await MatchPatternOnExistingMapping(importCorrectPatternTaskSpan, patternFileResult, latestContractResult.Value.ContractId, patternDirectory, newPatternContent, latestContractResult.Value.Content);
                }
            }

            importCorrectPatternTaskSpan?.Finish();
        }
        private async Task ImportNewPatternsTask(ISpan rootSpan)
        {
            //ISpan rootSpan = _tracer.ActiveSpan;
            _logger.LogInformation("ImportNewPatternsTask");

            try
            {
                var importNewPatternsTaskSpan = _tracer?.SpanAsChildOf(rootSpan, "import-patterns");
                var contractDirectories = new DirectoryInfo(_newPatternImportTaskConfiguration.Value.ContractsGroupPath).GetDirectories().Take(_newPatternImportTaskConfiguration.Value.ImportBatchSize);

                if (!contractDirectories.Any())
                    importNewPatternsTaskSpan?.SetTag("contract.directories", 0);

                foreach (DirectoryInfo directory in contractDirectories)
                {
                    string patternFullDirectory = directory.FullName;
                    string patternDirectory = directory.Name;

                    FileInfo[] contractFilesInfo = directory.GetFiles(_newPatternImportTaskConfiguration.Value.ContractFileSearchPattern);

                    bool processShouldContinue = await _patternService.CheckIfPatternNotExistOrIsConfirmed(patternDirectory);

                    if (processShouldContinue)
                        _logger.LogInformation($"{patternDirectory}");

                    if (contractFilesInfo.Length > 0 && processShouldContinue)
                    {                        
                        await ImportNewPatternTask(importNewPatternsTaskSpan, contractFilesInfo, patternDirectory, patternFullDirectory);                     
                    }
                }
                importNewPatternsTaskSpan?.Finish();
            }
            catch (Exception e)
            {
                _logger.LogError(e.Dump().ToString());                
            }

            await Task.CompletedTask;
        }

        private async Task ImportWarningFileTask(ISpan parentSpan, string contractId, PatternFileResult patternFileResult)
        {
            var impportWarningTaskSpan = _tracer?.SpanAsChildOf(parentSpan, "import-warning");

            Maybe<Pattern> pattern = await _patternService.GetPatternByContractId(contractId);

            if (pattern.HasValue)
            {
                impportWarningTaskSpan?.SetTag("pattern.exists", true);
                impportWarningTaskSpan?.SetTag("pattern.confirmed", pattern.Value.IsConfirmed);

                _tracer?.SpanInlineAsChildOf(impportWarningTaskSpan, "set-unconfirmed");
                await _patternService.UpdatePatternToUnconfirmed(pattern.Value);
            }
            if (pattern.HasNoValue)
            {
                impportWarningTaskSpan?.SetTag("pattern.exists", false);
                byte[] newPatternContent = await File.ReadAllBytesAsync(patternFileResult.PatternFileFullName);

                _tracer?.SpanInlineAsChildOf(impportWarningTaskSpan, "add-pattern");
                await _patternService.AddNewPatternFromFile(patternFileResult.PatternFile, patternFileResult.PdfFile.Value.CreationDate, newPatternContent, patternFileResult.IsWarningFile);
            }

            impportWarningTaskSpan?.Finish();

            await Task.CompletedTask;
        }
        #endregion

        #region confirm_patterns
        private async Task ImportConfirmedPatternsTask(ISpan rootSpan)
        {
            //ISpan rootSpan = _tracer.ActiveSpan;
            _logger.LogInformation("ImportConfirmedPatternsTask");
            var confirmPatternSpan = _tracer?.SpanAsChildOf(rootSpan, "confirm-patterns");

            IList<PatternImport> patternsToImport = await _smartIngestService.GetAllPatternsToImport();

            confirmPatternSpan?.SetTag("patterns.to.confirm", patternsToImport.Count);

            foreach (var patternImport in patternsToImport)
            {
                if (patternImport.ConfirmOld)
                {
                    await ConfirmExisting(confirmPatternSpan, patternImport);
                }
                else
                {
                    await ConfirmNewWithImport(confirmPatternSpan, patternImport);
                }

                await _smartIngestService.RemovePatternToImport(patternImport.ContractId);
            }

            confirmPatternSpan?.Finish();
        }

        private async Task ConfirmNewWithImport(ISpan parentSpan, PatternImport patternImport)
        {
            var confirmNewWithImportSpan = _tracer?.SpanAsChildOf(parentSpan, "confirm-new-with-import");

            string rootContractsDirectory = _newPatternImportTaskConfiguration.Value.ContractsGroupPath;
            string currentContractDirectory = Path.Combine(rootContractsDirectory, patternImport.ContractId);

            string patternFileFullName = Path.Combine(rootContractsDirectory, patternImport.ContractId, "Patterns", patternImport.ImportFileName);

            if (File.Exists(patternFileFullName))
            {
                confirmNewWithImportSpan?.SetTag("file", patternImport.ImportFileName);

                byte[] fileContent = await File.ReadAllBytesAsync(patternFileFullName);
                string contractFileFullName = Path.Combine(rootContractsDirectory, patternImport.ContractId, Path.ChangeExtension(patternImport.ImportFileName, "PDF"));

                var updateResult = await _patternService.UpdatePatternByContractIdSetImport48HoursOld(patternImport.ContractId, patternImport.ImportFileName, DateTime.Now, fileContent);
                var updateResultSpan = _tracer?.SpanAsChildOf(confirmNewWithImportSpan, "update-pattern-48h");

                if (updateResult.IsSuccess)
                {
                    string successMessage = $"Updateing existing pattern from {patternImport.ImportFileName} Success";
                    updateResultSpan?.LogFinish($"Updateing existing pattern from {patternImport.ImportFileName} Success");

                    _logger.LogInformation(successMessage);
                }
                else
                {
                    string errorMessage = $"Updateing existing pattern from {patternImport.ImportFileName} Failed -> {updateResult.Error}";
                    updateResultSpan?.LogFinish($"Updateing existing pattern from {patternImport.ImportFileName} Failed -> {updateResult.Error}");

                    _logger.LogInformation(errorMessage);
                    await MoveContractFilesToErrorFolder(contractFileFullName);

                    _tracer?.SpanInlineAsChildOf(confirmNewWithImportSpan, "move-to-error");
                }

                DirectoryExt.DeleteIfExists(currentContractDirectory);
                _tracer?.SpanInlineAsChildOf(confirmNewWithImportSpan, "delete-directory");
            }

            confirmNewWithImportSpan?.Finish();
            await Task.CompletedTask;
        }

        private async Task ConfirmExisting(ISpan parentSpan, PatternImport patternImport)
        {
            var confirmExistingSpan = _tracer?.SpanAsChildOf(parentSpan, "confirm-existing");
            confirmExistingSpan?.SetTag("contract", patternImport.ContractId);
            confirmExistingSpan?.SetTag("confirm.exsting", true);

            _logger.LogInformation($"Pattern Import {patternImport.ContractId}");
            string rootContractsDirectory = _newPatternImportTaskConfiguration.Value.ContractsGroupPath;
            string currentContractDirectory = Path.Combine(rootContractsDirectory, patternImport.ContractId);

            _logger.LogInformation($"No Import file deleting pattern directory");
            DirectoryExt.DeleteIfExists(currentContractDirectory);
            _tracer?.SpanInlineAsChildOf(confirmExistingSpan, "delete-directory");


            confirmExistingSpan?.Finish();
            await Task.CompletedTask;
        }

        #endregion

        #region helpers

        private async Task MoveContractFilesToErrorFolder(string contractFileFullName)
        {
            string fileName = Path.GetFileName(contractFileFullName);
            string destinationFileName = Path.Combine(_newPatternImportTaskConfiguration.Value.ErrorsFolderPath, fileName);

            if (!File.Exists(destinationFileName))
                await FileExt.MoveFileAsync(contractFileFullName, destinationFileName, CancellationToken.None);
        }

        private async Task MoveContractFilesToErrorFolder(FileInfo[] contractFilesInfos, string patternDirectory = null, bool deleteOrginalDirectory = false)
        {
            foreach (var contractFileInfo in contractFilesInfos)
            {
                string destinationFileName = Path.Combine(_newPatternImportTaskConfiguration.Value.ErrorsFolderPath, contractFileInfo.Name);

                if (!File.Exists(destinationFileName))
                    await FileExt.MoveFileAsync(contractFileInfo.FullName, Path.Combine(_newPatternImportTaskConfiguration.Value.ErrorsFolderPath, contractFileInfo.Name), CancellationToken.None);
                else
                    File.Delete(contractFileInfo.FullName);
            }

            if (!string.IsNullOrEmpty(patternDirectory) && deleteOrginalDirectory)
                DirectoryExt.DeleteIfExists(patternDirectory);
        }

        private async Task<int> Match(byte[] newPatternContent, byte[] currentPatternContent, string contractId, string fileName = "")
        {
            int score = _matchingHandler.Handle(-1, MatchingPayload.Create(currentPatternContent, newPatternContent, contractId, fileName));

            //var patterMatchingRequest = new NewPatternMatchingRequest
            //{
            //    NewPatternContent = Convert.ToBase64String(newPatternContent),
            //    PatternContent = Convert.ToBase64String(currentPatternContent),
            //    ContractId = contractId
            //};

            //var responseMessage = _rpcQueueSender.SendAndReceive<NewPatternMatchingRequest, NewPatternMatchingResponse>(patterMatchingRequest);

            //int score = responseMessage.Message.Result.Score;
            return await Task.FromResult(score);
        }
        #endregion
    }   
}
