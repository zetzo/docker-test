﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using IBM.NetCore.Coravel;

namespace Smart.Ingest.Tasks
{
    internal class KeepAliveTask : InvocableBase<KeepAliveTask>
    {        
        public KeepAliveTask(ILogger<KeepAliveTask> logger) : base(logger)
        {
            
        }

        protected override async Task ExecuteAsync()
        {
            _logger.LogError($"Creating Error Started");

            var obj = new Temp();
            if (string.IsNullOrEmpty(obj.Test))
            {
                var childException = new NotSupportedException("Not Supportted");
                var rootException = new KeyNotFoundException("KeyNotFound", childException);

                _logger.LogError($"Throwing AggregateException");
                throw new AggregateException("aggregate", rootException);
            }

            await Task.FromResult(0);
        }      

        internal class Temp
        {
            public string Test { get; set; }
        }
    }
}
