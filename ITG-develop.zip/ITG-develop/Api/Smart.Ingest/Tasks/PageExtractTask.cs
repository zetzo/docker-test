﻿using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Application.Services;
using Application.Services.Configuration;
using Application.Services.Helpers;
using Coravel.Invocable;
using CSharpFunctionalExtensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Web.Api.Domain.Models;
using Capturify.Api;
using IBM.NetCore.Coravel;
using Application.Services.Extensions;
using System.Collections.Generic;
using Remotion.Linq.Parsing.ExpressionVisitors.MemberBindings;

namespace Smart.Ingest.Tasks
{
    internal sealed class PageExtractTask : InvocableBase<PageExtractTask>
    {
        private const string ImageExtension = "PNG";
        private readonly SmartIngestService _smartIngestService;
        private readonly IOptions<PageExtractTaskConfiguration> _pageExtractServiceConfiguration;        
        private readonly SyncClient _syncClient;
        private readonly ContractFinder _contractFinder;

        public PageExtractTask(ILogger<PageExtractTask> logger, SmartIngestService smartIngestService,
            IOptions<PageExtractTaskConfiguration> pageExtractServiceConfiguration,  SyncClient syncClient, ContractFinder contractFinder) : base(logger)
        {
            _smartIngestService = smartIngestService;
            _pageExtractServiceConfiguration = pageExtractServiceConfiguration;            
            _syncClient = syncClient;
            _contractFinder = contractFinder;
            _logger.LogDebugDetail("Ctor");
        }
        protected override async Task ExecuteAsync()
        {
            _logger.LogInformation("DispatchDocumentsToCapturify - Started");
            await DispatchDocumentsToCapturify();
            _logger.LogInformation("DispatchDocumentsToCapturify - Ended");
        }

        public async Task DispatchDocumentsToCapturify(CancellationToken cancellationToken = default(CancellationToken))
        {            
            IList<PageExtract> allPagesExtract = await _smartIngestService.GetAllPagesForExtract();
            Queue<string> filesWithErrors = new Queue<string>();

            int iterateOnly = 60;
            int iterate = 0;

            foreach (DirectoryInfo directory in new DirectoryInfo(_pageExtractServiceConfiguration.Value.ContractsGroupPath).GetDirectories().Take(_pageExtractServiceConfiguration.Value.ImportBatchSize).OrderBy(x=>x.Name))
            {
                foreach (FileInfo file in directory.GetFiles(_pageExtractServiceConfiguration.Value.ContractFileSearchPattern, true))
                {
                    string destinationFileName = Path.Combine(directory.FullName, Path.ChangeExtension(file.Name, ImageExtension));
                    
                    if (_pageExtractServiceConfiguration.Value.OverrideExistingFile)
                        File.Delete(destinationFileName);

                    int pageToTake = 0;
                    Maybe<PageExtract> pageExtract = pageExtract = allPagesExtract.Where(x=>x.ImportFileName == file.Name).FirstOrDefault();
                    if (pageExtract.HasValue)
                    {
                        _logger.LogInformation($"PagExtract Override for {file.Name}");
                        FileExt.DeleteIfExists(destinationFileName);
                        DeleteRelatedFiles(directory.FullName, file.Name);
                        await ProcessFile(file, pageExtract.Value.PageNumber, destinationFileName, filesWithErrors, cancellationToken);
                    }
                    else
                    {
                        if (!File.Exists(destinationFileName))
                        {
                            iterate++;                            

                            Result<PdfHelper.PdfMetadata> pdfMetadataResult = PdfHelper.Instance.ReadMetadaFromFile(file.FullName);

                            if (pdfMetadataResult.IsSuccess)
                            {
                                pageToTake = _contractFinder.GetSpecificPageFromContract(pdfMetadataResult.Value.PagesCount);
                            }


                            await ProcessFile(file, pageToTake, destinationFileName, filesWithErrors, cancellationToken);

                            if (iterate >= iterateOnly)
                                return;                            
                        }
                    }
                }                
            }                      
        }

        private void DeleteRelatedFiles(string directoryFullName, string fileName)
        {
            string cutFilePath = Path.Combine(directoryFullName,"Cut", Path.ChangeExtension(fileName,"PNG"));
            string patternsFilePath = Path.Combine(directoryFullName, "Patterns", Path.ChangeExtension(fileName, "PNG"));
            FileExt.DeleteIfExists(cutFilePath);
            FileExt.DeleteIfExists(patternsFilePath);
        }

        private async Task ProcessFile(FileInfo fileInfo, int pageToTake, string destinationFileName, Queue<string> filesWithErros, CancellationToken cancellationToken = default(CancellationToken))
        {
            byte[] fileContent = await File.ReadAllBytesAsync(fileInfo.FullName);

            _logger.LogInformation($"Sending {fileInfo.Name} to Capturify");
            _syncClient.CutPdf(null, fileContent, pageToTake);

            if (_syncClient.Result.Status != "Error")
            {
                byte[] imageResulInBytes = _syncClient.Result.Result.Pages.First().Content;

                _logger.LogInformation($"Saving {destinationFileName}");
                await File.WriteAllBytesAsync(destinationFileName, imageResulInBytes, cancellationToken);
                await _smartIngestService.RemovePageExtract(fileInfo.Name);
            }
            //else
            //{
                
            //    filesWithErros.Enqueue(fileInfo.FullName);                                
            //    _logger.LogError($"Capturify error: {fileInfo.Name}");
            //}
        }
    }
}
