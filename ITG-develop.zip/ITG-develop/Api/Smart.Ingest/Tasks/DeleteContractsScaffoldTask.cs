﻿using Application.Services;
using Application.Services.Configuration;
using Application.Services.Extensions;
using IBM.NetCore.Coravel;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;

namespace Smart.Ingest.Tasks
{
    internal class DeleteContractsScaffoldTask : InvocableBase<DeleteContractsScaffoldTask>
    {
        private readonly IOptions<DeleteContractsScaffoldTaskConfiguration> _deleteContractsScaffoldTaskConfiguration;
        private readonly IPatternRepository _patternRepository;

        public DeleteContractsScaffoldTask(ILogger<DeleteContractsScaffoldTask> logger,
            IOptions<DeleteContractsScaffoldTaskConfiguration> deleteContractsScaffoldTaskConfiguration, IPatternRepository patternRepository) : base(logger)
        {
            _deleteContractsScaffoldTaskConfiguration = deleteContractsScaffoldTaskConfiguration;
            _patternRepository = patternRepository;
            _logger.LogDebugDetail("Ctor");
        }

        protected override async Task ExecuteAsync()
        {
            _logger.LogInformation("DeleteContractsScaffoldTask Started");
            //await DeleteContractScaffoldFolders();
            await DeleteConfirmedPatternsScaffoldFolders();
            _logger.LogInformation("DeleteContractsScaffoldTask Ended");
        }

        private async Task DeleteContractScaffoldFolders()
        {
            var contractFolderDictonary = new DirectoryInfo(_deleteContractsScaffoldTaskConfiguration.Value.ContractsGroupPath).GetDirectories()
                .Take(_deleteContractsScaffoldTaskConfiguration.Value.ImportBatchSize).OrderBy(x => x.Name).ToDictionary(x => x.Name, y => y.FullName);

            if (contractFolderDictonary.Count > 0)
            {
                _logger.LogInformation($"Contract Scaffold folder found: {contractFolderDictonary.Count}");

                var contractScaffoldAgeList = await _patternRepository.GetPatternsAge(contractFolderDictonary.First().Key, contractFolderDictonary.Last().Key);

                foreach (var contractFolder in contractFolderDictonary)
                {
                    var contractScaffoldAge = contractScaffoldAgeList.Where(x => x.ContractId == contractFolder.Key).FirstOrDefault();
                    if (contractScaffoldAge != null)
                    {
                        if (contractScaffoldAge.Hours > _deleteContractsScaffoldTaskConfiguration.Value.DeleteAfterHours)
                        {
                            _logger.LogInformation($"Contract {contractScaffoldAge.ContractId} has {contractScaffoldAge.Hours} hours -> deleting");

                            DirectoryExt.DeleteIfExists(contractFolderDictonary[contractScaffoldAge.ContractId], recursive: true);
                        }
                    }
                }
            }
        }

        private async Task DeleteConfirmedPatternsScaffoldFolders()
        {
            var contractFolderDictonary = new DirectoryInfo(_deleteContractsScaffoldTaskConfiguration.Value.ContractsGroupPath).GetDirectories()
              .Take(_deleteContractsScaffoldTaskConfiguration.Value.ImportBatchSize).OrderBy(x => x.Name).ToDictionary(x => x.Name, y => y.FullName);
            
            if (contractFolderDictonary.Count > 0)
            {
                foreach(var contractFolder in contractFolderDictonary)
                {
                    var pattern = await _patternRepository.GetByContractId(contractFolder.Key);
                    if(pattern!=null && (pattern.Status == PatternStatusEnum.Confirmed.ToString() || pattern.Status == PatternStatusEnum.VendorHasNoStamp.ToString()))
                    {
                        _logger.LogInformation($"{pattern.ContractId} : {pattern.Status}");
                        DirectoryExt.DeleteIfExists(contractFolder.Value, recursive: true);
                    }
                }              
            }
        }
    }
}
