﻿using Application.Services.Extensions;
using Application.Services.Interfaces;
using CSharpFunctionalExtensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Data.Common;
using Web.Api.Domain.Models;
using Application.Services.Configuration;
using static Application.Services.ContractFinder;
using IBM.NetCore.Coravel;
using Application.Services;
using Application.Services.Helpers;

namespace Smart.Ingest.Tasks
{
    internal sealed class DispatchDocumentTask : InvocableBase<DispatchDocumentTask>
    {                      
        private readonly IPatternService _patternService;
        private readonly CryptoHelper _cryptoHelper;
        private readonly IOptions<DispatchTaskConfiguration> _dispatchServiceConfiguration;
        public DispatchDocumentTask(ILogger<DispatchDocumentTask> logger, CryptoHelper cryptoHelper, IPatternService patternService, IOptions<DispatchTaskConfiguration> dispatchServiceConfiguration) : base(logger)
        {                        
            _cryptoHelper = cryptoHelper;
            _patternService = patternService;

            _dispatchServiceConfiguration = dispatchServiceConfiguration;            

            _logger.LogDebugDetail("Ctor");
        }

        protected override async Task ExecuteAsync()
        {            
            await DispatchDocuments();
        }

        public async Task DispatchDocuments(CancellationToken cancellationToken = default(CancellationToken))
        {
            _logger.LogInformation("DispatchDocuments - Started");

            Queue<DispatchServiceItem> documentsQueue = new Queue<DispatchServiceItem>();                      

            Dictionary<string, DispatchDocumentsLog> dispatchDocumentLogs = new Dictionary<string, DispatchDocumentsLog>();

            foreach (FileInfo file in new DirectoryInfo(_dispatchServiceConfiguration.Value.DocumentsToImportPath)
                .GetFiles(_dispatchServiceConfiguration.Value.ContractFileSearchPattern, true).Take(_dispatchServiceConfiguration.Value.ImportBatchSize))
            {
                _logger.LogInformation($"Processing {file.Name}");
                
                Result<ContractFinderResult> contractFinderResult = _patternService.GetContractResultFromDocumentFile(file.FullName);                                
                DispatchServiceItem dispatchItem = DispatchServiceItem.CreateNew(file.FullName);

                if (contractFinderResult.IsSuccess)
                {                    
                    string destinationPath = Path.Combine(_dispatchServiceConfiguration.Value.ContractsGroupPath, contractFinderResult.Value.ContractId);

                    if (!Directory.Exists(destinationPath))
                        Directory.CreateDirectory(destinationPath);

                    string destinationFileName = Path.Combine(destinationPath, file.Name);

                    dispatchItem.SetDestinationPath(destinationFileName);                                  
                }
                else
                {
                    dispatchItem.SetErrorReadingContractId();
                    string destinationPath = Path.Combine(_dispatchServiceConfiguration.Value.ErrorsPath, file.Name);
                    dispatchItem.SetDestinationPath(destinationPath);                    
                }

                documentsQueue.Enqueue(dispatchItem);                          
            }          

            while (documentsQueue.Count > 0)
            {
                DispatchServiceItem dispatchItem = documentsQueue.Dequeue();
                
                _logger.LogInformation($"Moving {dispatchItem.SourceFilePath} to {dispatchItem.DestinationFilePath}");                
                await FileExt.MoveFileAsync(dispatchItem.SourceFilePath, dispatchItem.DestinationFilePath, true, cancellationToken);                                
            }

            _logger.LogInformation("DispatchDocuments - Done");

            await Task.CompletedTask;
        } 
        
        sealed class DispatchServiceItem
        {
            public string SourceFilePath { get; private set; }
            public string DestinationFilePath { get; private set; }
            public bool ErrorReadingContractId { get; private set; }                        

            private DispatchServiceItem(string sourceFilePath)
            {
                SourceFilePath = sourceFilePath;                
            }

            public static DispatchServiceItem CreateNew(string sourceFilePath) => new DispatchServiceItem(sourceFilePath);

            public void SetDestinationPath(string destinationFilePath)
            {
                DestinationFilePath = destinationFilePath;
            }      
            
            public void SetErrorReadingContractId()
            {
                ErrorReadingContractId = true;
            }
        }           
    }           
}
 