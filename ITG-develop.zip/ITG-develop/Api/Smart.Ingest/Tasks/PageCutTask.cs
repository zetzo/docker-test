﻿using Application.Services;
using CSharpFunctionalExtensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Processing;
using SixLabors.Primitives;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Models;
using Application.Services.Configuration;
using IBM.NetCore.Coravel;
using Application.Services.Extensions;
using IBM.NetCore.RabbitMQ.Interfaces;
using Smart.Ingest.Model;
using System;
using Application.Services.Helpers;
using System.Collections.Generic;

namespace Smart.Ingest.Tasks
{
    internal sealed class PageCutTask : InvocableBase<PageCutTask>
    {
        private readonly SmartIngestService _smartIngestService;
        private readonly IOptions<PageCutTaskConfiguration> _pageCutServiceConfiguration;

        public PageCutTask(ILogger<PageCutTask> logger, SmartIngestService smartIngestService,
            IOptions<PageCutTaskConfiguration> pageCutServiceConfiguration) : base(logger)
        {
            _smartIngestService = smartIngestService;
            _pageCutServiceConfiguration = pageCutServiceConfiguration;
            _logger.LogDebugDetail("Ctor");
        }

        protected override async Task ExecuteAsync()
        {
            await CutPageFromBottomLeftWithEntropy();
        }

        public async Task CutPageFromBottomLeftWithEntropy(CancellationToken cancellationToken = default(CancellationToken))
        {
            IReadOnlyList<PageCut> allPageCuts = _smartIngestService.GetAllOverridePageCut();

            _logger.LogInformation("CutPageFromBottomLeftWithEntropy - Started");

            foreach (DirectoryInfo directory in new DirectoryInfo(_pageCutServiceConfiguration.Value.ContractsGroupPath).GetDirectories().Take(_pageCutServiceConfiguration.Value.ImportBatchSize).OrderBy(x=>x.Name))
            {                
                foreach (FileInfo file in directory.GetFiles(_pageCutServiceConfiguration.Value.FileSearchPattern, true))
                {                    
                    string fileName = Path.GetFileName(file.FullName);
                    string cuttedImagesDirectory = Path.Combine(directory.FullName, "Cut");
                    
                    if (!Directory.Exists(cuttedImagesDirectory))
                    {
                        Directory.CreateDirectory(cuttedImagesDirectory);
                    }

                    string newFileName = Path.Combine(cuttedImagesDirectory, $"{fileName}");
                    
                    int leftMargin = _pageCutServiceConfiguration.Value.Left;
                    int partHeight = _pageCutServiceConfiguration.Value.Bottom;

                    string orginalDocumentName = Path.Combine(directory.FullName, Path.ChangeExtension(file.Name, "PDF"));
                    
                    PageCut pageCut = allPageCuts.Where(x => x.ImportFileName == file.Name).FirstOrDefault();

                    if (pageCut == null)
                    {
                        if (!File.Exists(newFileName))
                        {                            
                            Result<PdfHelper.PdfMetadata> pdfMetadataResult = PdfHelper.Instance.ReadMetadaFromFile(orginalDocumentName);
                            Action<FileInfo, string, int> cutAction = ProcessContractFile;

                            if (pdfMetadataResult.IsSuccess)
                            {
                                if (pdfMetadataResult.Value.PagesCount > 1 && pdfMetadataResult.Value.PagesCount < 4)
                                {
                                    cutAction = ProcessAddendumFile;
                                    partHeight += 100;
                                }
                            }
                            else
                            {
                                _logger.LogInformation($"[CutPageFromBottomLeftWithEntropy] -> {pdfMetadataResult.Error}");
                            }

                            _logger.LogInformation($"[CutPageFromBottomLeftWithEntropy] -> cutting {file.Name}");
                            cutAction(file, newFileName, partHeight);
                        }
                    }
                    else
                    {
                        leftMargin += pageCut.CutLeft;
                        partHeight += pageCut.CutBottom;

                        DeleteRelatedFiles(directory.FullName, file.Name);
                        ProcessFile(file, newFileName, leftMargin, partHeight);
                        await _smartIngestService.RemoveOverridePageCut(file.Name);
                    }
                }
            }

            _logger.LogInformation("CutPageFromBottomLeftWithEntropy - Done");
            await Task.CompletedTask;
        }

        private void DeleteRelatedFiles(string directoryFullName, string fileName)
        {
            string patternsFilePath = Path.Combine(directoryFullName, "Patterns", Path.ChangeExtension(fileName, "PNG"));
            FileExt.DeleteIfExists(patternsFilePath);
        }

        private void ProcessAddendumFile(FileInfo fileInfo, string newFileName, int partHeight)
        {
            using (var imgStream = new FileStream(fileInfo.FullName, FileMode.Open, FileAccess.Read))
            {
                BinaryReader streamreader = new BinaryReader(imgStream);
                byte[] data = streamreader.ReadBytes((int)imgStream.Length);
                using (Image<Rgba32> image = Image.Load(data))
                {
                    var croppedImage = image.Clone();
                    //croppedImage.Mutate(img => img.EntropyCrop());
                    croppedImage.Mutate(img => CutOutLogo(image, img));
                    croppedImage.Mutate(img => CutLeftSide(image, img));
                    _logger.LogInformation($"Saving {newFileName}");

                    croppedImage.Save(newFileName);
                }
            }
        }

        private void ProcessContractFile(FileInfo fileInfo, string newFileName, int partHeight)
        {
            using (var imgStream = new FileStream(fileInfo.FullName, FileMode.Open, FileAccess.Read))
            {
                BinaryReader streamreader = new BinaryReader(imgStream);
                byte[] data = streamreader.ReadBytes((int)imgStream.Length);
                using (Image<Rgba32> image = Image.Load(data))
                {
                    var croppedImage = image.Clone();
                    croppedImage.Mutate(img => CutOutLogo(image, img));
                    croppedImage.Mutate(img => CutTopLeftSide(image, partHeight, img));
                    _logger.LogInformation($"Saving {newFileName}");

                    croppedImage.Save(newFileName);
                }
            }
        }



        private IImageProcessingContext CutOutLogo(Image<Rgba32> image, IImageProcessingContext context)
        {
            int startX = 2051;
            int startY = 3060;

            var startingPoint = new PointF { X = startX, Y = startY };
            var topRightPoint = new PointF { X = image.Width - 1, Y = startY };
            var bottomLeftPoint = new PointF { X = startX, Y = image.Height - 1 };
            var bottomRightPoint = new PointF { X = image.Width - 1, Y = image.Height - 1 };

            return context.FillPolygon(Color.White, new PointF[] { startingPoint, topRightPoint, bottomRightPoint, bottomLeftPoint });
        }

        private IImageProcessingContext CutLeftSide(Image<Rgba32> image, IImageProcessingContext context)
        {
            int leftMargin = _pageCutServiceConfiguration.Value.Left;

            var cropRectangle = new Rectangle(leftMargin, 0, image.Width - leftMargin, image.Height);

            return context.Crop(cropRectangle);
        }

        private IImageProcessingContext CutTopLeftSide(Image<Rgba32> image, int partHeight, IImageProcessingContext context)
        {
            int leftMargin = _pageCutServiceConfiguration.Value.Left;

            int cutParts = image.Height / partHeight;
            int patternHeight = (image.Height / cutParts);

            int y = image.Height - patternHeight;

            var cropRectangle = new Rectangle(leftMargin, y, image.Width - leftMargin, patternHeight);

            return context.Crop(cropRectangle);
        }

        private void CutOutLogo(FileInfo fileInfo, string newFileName)
        {
            using (var imgStream = new FileStream(fileInfo.FullName, FileMode.Open, FileAccess.Read))
            {
                BinaryReader streamreader = new BinaryReader(imgStream);
                byte[] data = streamreader.ReadBytes((int)imgStream.Length);
                using (Image<Rgba32> image = Image.Load(data))
                {
                    var croppedImage = image.Clone();
                    croppedImage.Mutate(x => CutOutLogo(image, x));
                    croppedImage.Save(newFileName);
                }
            }
        }

        private void ProcessFile(FileInfo fileInfo, string newFileName, int leftMargin, int partHeight, bool reverse = false)
        {
            using (var imgStream = new FileStream(fileInfo.FullName, FileMode.Open, FileAccess.Read))
            {
                BinaryReader streamreader = new BinaryReader(imgStream);
                byte[] data = streamreader.ReadBytes((int)imgStream.Length);
                using (Image<Rgba32> image = Image.Load(data))
                {
                    var croppedImage = image.Clone();
                    croppedImage.Mutate(img => img.EntropyCrop());

                    int cutParts = croppedImage.Height / partHeight;
                    int patternHeight = (croppedImage.Height / cutParts);
                    int y = croppedImage.Height - patternHeight;

                    if (reverse)
                        y = 0;

                    var cropRectangle = new Rectangle(leftMargin, y, croppedImage.Width - leftMargin, patternHeight);
                    croppedImage.Mutate(x => x.Crop(cropRectangle));
                    _logger.LogInformation($"Saving {newFileName}");

                    croppedImage.Save(newFileName);
                }
            }
        }
    }
}
