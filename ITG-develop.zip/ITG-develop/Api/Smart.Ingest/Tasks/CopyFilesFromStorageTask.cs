﻿using Application.Services.Configuration;
using Application.Services.Extensions;
using FluentValidation.Validators;
using IBM.NetCore.Coravel;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Smart.Ingest.Tasks
{
    public class CopyFilesFromStorageTask : InvocableBase<CopyFilesFromStorageTask>
    {
        private readonly IOptions<CopyFilesFromStorageConfiguration> _copyContractsFromStorageConfiguration;
        public CopyFilesFromStorageTask(ILogger<CopyFilesFromStorageTask> logger, IOptions<CopyFilesFromStorageConfiguration> copyContractsFromStorageConfiguration) : base(logger)
        {
            _copyContractsFromStorageConfiguration = copyContractsFromStorageConfiguration;
        }

        protected override async Task ExecuteAsync()
        {
            _logger.LogInformation("CopyContractsFromStorageTask - Started");
            await GetContractFiles();
            //await GetClosingDocuments();
            _logger.LogInformation("CopyContractsFromStorageTask - Ended");            
        }

        private async Task GetContractFiles()
        {
            int skippedCount = 0;
            foreach (var file in new DirectoryInfo(_copyContractsFromStorageConfiguration.Value.ContractsSourcePath).GetFiles())
            {
                string destinationFile = Path.Combine(_copyContractsFromStorageConfiguration.Value.ContractsDestinationPath, file.Name);
                string backupDestinationFile = Path.Combine(_copyContractsFromStorageConfiguration.Value.ITGContractsBackupPath, file.Name);

                if (File.Exists(destinationFile))
                    skippedCount++;

                if (!File.Exists(backupDestinationFile))
                {
                    _logger.LogInformation($"Copying {file.FullName} -> {backupDestinationFile}");
                    await FileExt.CopyFileAsync(file.FullName, backupDestinationFile, CancellationToken.None);
                }
                if (!File.Exists(destinationFile))
                {
                    _logger.LogInformation($"Copying {file.FullName} -> {destinationFile}");
                    await FileExt.CopyFileAsync(file.FullName, destinationFile, CancellationToken.None);
                }
                    
                if (File.Exists(backupDestinationFile) && File.Exists(destinationFile))
                {
                    _logger.LogInformation($"Deleting {file.FullName}");
                    File.Delete(file.FullName);
                }
            }

            _logger.LogInformation($"{skippedCount} exists skipping");
        }

        private async Task GetClosingDocuments()
        {
            int skippedCount = 0;
            foreach (var file in new DirectoryInfo(_copyContractsFromStorageConfiguration.Value.ClosingDocumentSourcePath).GetFiles())
            {
                string destinationFile = Path.Combine(_copyContractsFromStorageConfiguration.Value.ClosingDocumentDestinationPath, file.Name);

                if (File.Exists(destinationFile))
                    skippedCount++;

                if (!File.Exists(destinationFile))
                {
                    _logger.LogInformation($"Copying {file.FullName} -> {destinationFile}");
                    await FileExt.CopyFileAsync(file.FullName, destinationFile, CancellationToken.None);
                }
            }

            _logger.LogInformation($"{skippedCount} exists skipping");
        }
    }
}
