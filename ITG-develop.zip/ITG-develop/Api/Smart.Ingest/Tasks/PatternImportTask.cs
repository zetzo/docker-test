﻿using Application.Services;
using Application.Services.Helpers;
using Application.Services.Interfaces;
using CSharpFunctionalExtensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Data.Common;
using Web.Api.Domain.Models;
using Application.Services.Configuration;
using IBM.NetCore.Coravel;
using Application.Services.Extensions;
using System.Collections.Generic;
using System;

namespace Smart.Ingest.Tasks
{
    internal sealed class PatternImportTask : InvocableBase<PatternImportTask>
    {
        private readonly IPatternService _patternService;
        private readonly SmartIngestService _smartIngestService;
        private readonly CryptoHelper _cryptoHelper;
        private readonly IOptions<PatternImportTaskConfiguration> _patternImportServiceConfiguration;

        public PatternImportTask(ILogger<PatternImportTask> logger, IPatternService patternService, SmartIngestService smartIngestService, CryptoHelper cryptoHelper,
            IOptions<PatternImportTaskConfiguration> patternImportServiceConfiguration) : base(logger)
        {
            _patternService = patternService;
            _smartIngestService = smartIngestService;
            _cryptoHelper = cryptoHelper;
            _patternImportServiceConfiguration = patternImportServiceConfiguration;
        }

        protected override async Task ExecuteAsync()
        {
            _logger.LogInformation("PatternImportTask - Started");
            await AddPatterns();
            _logger.LogInformation("PatternImportTask - Ended");
        }

        private async Task AddPatterns(CancellationToken cancellationToken = default(CancellationToken))
        {
            IList<PatternImport> patternsToImports = await _smartIngestService.GetAllPatternsToImport();

            _logger.LogInformation($"ImportBatchSize -> {_patternImportServiceConfiguration.Value.ImportBatchSize}");

            foreach (DirectoryInfo directory in new DirectoryInfo(_patternImportServiceConfiguration.Value.ContractsGroupPath).GetDirectories().Take(_patternImportServiceConfiguration.Value.ImportBatchSize).OrderBy(x=>x.Name))
            {                
                string rootDirectory = directory.FullName;
                string contractId = directory.Name;

                Maybe<PatternImport> patternImport = patternsToImports.Where(x => x.ContractId == contractId).FirstOrDefault();

                if (patternImport.HasValue)
                {
                    string patternFileFullName = Path.Combine(rootDirectory, "Patterns", patternImport.Value.ImportFileName);

                    if (File.Exists(patternFileFullName))
                    {
                        Result<string> contractIdResult = await _patternService.GetContractIdFromFile(patternImport.Value.ImportFileName);
                        if (contractIdResult.IsSuccess)
                        {
                            byte[] fileContent = await File.ReadAllBytesAsync(patternFileFullName);

                            string contractFileFullName = Path.Combine(directory.FullName, Path.ChangeExtension(patternImport.Value.ImportFileName, "PDF"));

                            var creationTime = File.GetCreationTime(contractFileFullName);                          

                            var updateResult = await _patternService.UpdatePatternByContractIdSetImport48HoursOld(contractIdResult.Value, patternImport.Value.ImportFileName, creationTime, fileContent);
                            if (updateResult.IsSuccess)
                            {
                                _logger.LogInformation($"Updateing existing pattern from {patternImport.Value.ImportFileName} Success");
                                await _smartIngestService.RemovePatternToImport(contractId);
                                DirectoryExt.DeleteIfExists(directory.FullName, recursive: true);
                            }
                            else
                            {
                                _logger.LogInformation($"Updateing existing pattern from {patternImport.Value.ImportFileName} Failed -> {updateResult.Error}");

                            }
                        }
                    }
                    else
                    {
                        _logger.LogWarning("Pattern File not found");
                    }
                }
                else
                {

                    FileInfo[] contractFilesInfo = directory.GetFiles().Where(x => x.Name.EndsWith("pdf", StringComparison.OrdinalIgnoreCase)).ToArray();

                    if (contractFilesInfo.Length > 0)
                    {                        
                        PatternFileResult patternFileResult = _patternService.FindCorrectPatternFile(contractFilesInfo, rootDirectory);

                        if (!File.Exists(patternFileResult.PatternFileFullName))
                            patternFileResult = _patternService.FindPatternWarningFile(contractFilesInfo, rootDirectory);
                        
                        if (File.Exists(patternFileResult.PatternFileFullName))
                        {
                            byte[] fileContent = await File.ReadAllBytesAsync(patternFileResult.PatternFileFullName);                         
                            Result<string> sha2Result = _cryptoHelper.GenSha256FromBytes(fileContent);
                            if (sha2Result.IsSuccess)
                            {                                
                                try
                                {
                                    Result<string> contractIdResult = await _patternService.GetContractIdFromFile(patternFileResult.PatternFileFullName);                                    

                                    if (contractIdResult.IsSuccess)
                                    {                                        
                                        Maybe<Pattern> pattern = await _patternService.GetPatternByContractId(contractIdResult.Value);
                                        
                                        var creationTime = File.GetCreationTime(patternFileResult.PatternFileFullName);
                                        if (patternFileResult.PdfFile.IsSuccess && patternFileResult.PdfFile.Value.CreationDate != DateTime.MinValue)
                                            creationTime = patternFileResult.PdfFile.Value.CreationDate;
                                        
                                        if (pattern.HasNoValue)
                                        {                                            
                                            var result = await _patternService.AddNewPatternFromFile(patternFileResult.PatternFile, creationTime, fileContent, patternFileResult.IsWarningFile);

                                            if (result.IsFailure)
                                                _logger.LogError($"Error adding to database {result.Error}");
                                        }
                                        //else if (pattern.HasValue && pattern.Value.CreationDate < creationTime)
                                        //{
                                        //    _logger.LogInformation($"Updateing existing pattern {patternFileResult.PatternFileFullName} in database");
                                        //    var result = await _patternService.UpdatePatternByContractId(contractIdResult.Value, patternFileResult.PatternFile, creationTime, fileContent, patternFileResult.IsWarningFile);

                                        //    if (result.IsFailure)
                                        //        _logger.LogError($"Error adding to database {result.Error}");
                                        //}
                                    }
                                    else
                                    {
                                        _logger.LogError($"Contract not found in file {contractIdResult.Error}");
                                    }
                                }
                                catch
                                {
                                    _logger.LogError(patternFileResult.PatternFileFullName);
                                }
                            }
                            else
                            {
                                _logger.LogError(sha2Result.Error);
                            }
                        }
                        else
                        {
                            _logger.LogWarning("Pattern File not found");
                        }
                    }
                    else
                    {
                        _logger.LogInformation($"no contract file found");
                    }
                }
            }
        }        
    }
}
