﻿using Application.Services;
using Application.Services.Configuration;
using Application.Services.Extensions;
using CSharpFunctionalExtensions;
using IBM.NetCore.Coravel;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Smart.Ingest.Tasks
{
    internal class ArchiveContractGroupTask : InvocableBase<ArchiveContractGroupTask>
    {
        private readonly ContractFinder _contractFinder;
        private readonly IOptions<ArchiveContractGroupTaskConfiguration> _archiveGroupTaskConfiguration;
        public ArchiveContractGroupTask(ILogger<ArchiveContractGroupTask> logger, ContractFinder contractFinder, IOptions<ArchiveContractGroupTaskConfiguration> archiveGroupTaskConfiguration) : base(logger)
        {
            _contractFinder = contractFinder;
            _archiveGroupTaskConfiguration = archiveGroupTaskConfiguration;
        }

        protected override async Task ExecuteAsync()
        {
            _logger.LogInformation("ArchiveContractGroupTask - Started");
            await GroupArchive();
            _logger.LogInformation("ArchiveContractGroupTask - Ended");
        }

        protected async Task GroupArchive(CancellationToken cancellationToken = default(CancellationToken))
        {
            var contractFilesList = new DirectoryInfo(_archiveGroupTaskConfiguration.Value.DocumentsSourcePath)
              .GetFiles().ToList();

            foreach (FileInfo fileInfo in contractFilesList)
            {
                _logger.LogInformation($"Processing {fileInfo.Name}");

                Result<string> contractGroupResult = _contractFinder.GenContractGroup(fileInfo.Name);
                if (contractGroupResult.IsSuccess)
                {
                    string destinationFileName = Path.Combine(_archiveGroupTaskConfiguration.Value.DocumentsSourcePath, contractGroupResult.Value, fileInfo.Name);
                    if (!Directory.Exists(Path.GetDirectoryName(destinationFileName)))
                        Directory.CreateDirectory(Path.GetDirectoryName(destinationFileName));

                    _logger.LogInformation($"Moving file {fileInfo.Name} to {Path.GetDirectoryName(destinationFileName)}");
                    await FileExt.MoveFileAsync(fileInfo.FullName, destinationFileName, cancellationToken);
                }                
            }           
        }
    }
}
