﻿using Coravel.Scheduling.Schedule.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Smart.Ingest
{
    public static class CoravelExtensions
    {
        public static IScheduledEventConfiguration BuildWithTime(this IScheduleInterval scheduleInterval, string time = "* * * * *")
        {
            IScheduledEventConfiguration scheduledEventConfiguration;
           
            if (time.StartsWith("E", StringComparison.OrdinalIgnoreCase))
            {
                switch (time.ToUpper())
                {
                    case "EVERYTENSECONDS":
                        scheduledEventConfiguration = scheduleInterval.EveryTenSeconds();
                        break;
                    case "EVERYFIFTEENSECONDS":
                        scheduledEventConfiguration = scheduleInterval.EveryFifteenSeconds();
                        break;
                    case "EVERYTHIRTYSECONDS":
                        scheduledEventConfiguration = scheduleInterval.EveryThirtySeconds();
                        break;
                    default:
                        scheduledEventConfiguration = scheduleInterval.EveryFiveSeconds();
                        break;
                }
            }
            else
            {
                scheduledEventConfiguration = scheduleInterval.Cron(time);
            }
            return scheduledEventConfiguration;
        }
    }
}
