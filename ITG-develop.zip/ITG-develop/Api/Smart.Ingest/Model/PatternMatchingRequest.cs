﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smart.Ingest.Model
{
    public class NewPatternMatchingRequest
    {
        public string PatternContent { get; set; }
        public string NewPatternContent { get; set; }
        public string ContractId { get; set; }
    }

    public class NewPatternMatchingResponse
    {
        public NewPatternMatchingResult Result { get; set; }
    }

    public class NewPatternMatchingResult
    {
        public string ContractId { get; set; }
        public int Score { get; set; }
        public string Error { get; set; }
    }
}
