﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smart.Ingest.Model
{
    internal class PatternExtractRequest
    {
        public string FileName { get; set; }
        public string Content { get; set; }
        public string DocumentType { get; set; } = "CONTRACT";

        public static PatternExtractRequest Default(string fileName,string content)
        {
            return new PatternExtractRequest { FileName = fileName, Content = content };
        }
    }
    internal class PatternExtractResponse 
    {
        public PatternExtractRequest Result { get; set; }
    }
}
