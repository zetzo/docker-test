﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Smart.Ingest
{
    public static class DirectoryInfoExtensions
    {
        public static IEnumerable<FileInfo> GetFiles(this DirectoryInfo directoryInfo, string searchPattern, bool caseInsensitive)
        {
            return directoryInfo.EnumerateFiles(searchPattern, new EnumerationOptions { MatchCasing = MatchCasing.CaseInsensitive });
        }
    }
}
