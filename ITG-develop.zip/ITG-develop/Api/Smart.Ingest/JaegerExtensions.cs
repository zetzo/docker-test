﻿using Jaeger;
using Jaeger.Reporters;
using Jaeger.Samplers;
using Jaeger.Senders;
using Jaeger.Senders.Thrift;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using OpenTracing;
using OpenTracing.Util;
using System;
using System.Collections.Generic;
using System.Text;

namespace Smart.Ingest
{
    public static class JaegerExtensions
    {
        public static void AddJaeger(this IServiceCollection services, JaegerConfiguration jaegerConfiguration)
        {
            if (!jaegerConfiguration.Enabled) return;

            services.AddSingleton<ITracer>(serviceProvider =>
            {
                string serviceName = jaegerConfiguration.ServiceName;
                ILoggerFactory loggerFactory = serviceProvider.GetRequiredService<ILoggerFactory>();

                ISampler sampler = new ConstSampler(sample: true);

                ThriftSender sender = new HttpSender(jaegerConfiguration.Endpoint);

                if(!jaegerConfiguration.Endpoint.Contains("http"))   
                    sender = new UdpSender(jaegerConfiguration.Endpoint.Split(':')[0], int.Parse(jaegerConfiguration.Endpoint.Split(':')[1]), 0);

                var remoteReporter = new RemoteReporter.Builder()
                   .WithLoggerFactory(loggerFactory)
                   .WithMaxQueueSize(100)
                   .WithFlushInterval(TimeSpan.FromSeconds(1))                   
                   .WithSender(sender)
                   .Build();

                ITracer tracer = new Tracer.Builder(serviceName)
                    .WithLoggerFactory(loggerFactory)
                    .WithSampler(sampler)
                    .WithReporter(remoteReporter)
                    .Build();

                GlobalTracer.Register(tracer);

                return tracer;
            });

            services.AddOpenTracing();
        }
    }

    public class JaegerConfiguration
    {
        public string ServiceName { get; set; }
        public string Endpoint { get; set; }
        public bool Enabled { get; set; }
    }
}
