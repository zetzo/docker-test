﻿using Application.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smart.App
{
    public partial class Form1 : Form
    {
        private ContractFinder _finder;

        public Form1()
        {
            _finder = new ContractFinder();
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Text = _finder.GetLatinFromCyrylic(textBox1.Text.Trim()); 
        }
    }
}
