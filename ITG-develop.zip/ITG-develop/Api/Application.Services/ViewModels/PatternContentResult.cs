﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Services.ViewModels
{
    public class PatternContentResult
    {      
        public byte[ ] Content { get; protected set; }
        public string ContentType { get; protected set; }
        
        protected PatternContentResult() { }
        
        public PatternContentResult(byte[] content, string contentType) 
        {
            Content = content;
            ContentType = contentType;
        }

        public static PatternContentResult Create(byte[] content, string contentType) => new PatternContentResult(content, contentType);

        public static PatternContentResult Empty => new PatternContentResult();
    }
}
