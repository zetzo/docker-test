﻿using Application.Services.Helpers;
using CSharpFunctionalExtensions;
using System;

namespace Application.Services
{
    public class PatternFileResult
    {
        public Result<PdfHelper.PdfMetadata> PdfFile { get; set; }
        public string PatternFile { get; set; }
        public string PatternFileFullName { get; set; }
        public bool IsWarningFile { get; set; }
        public bool Confirmed { get; protected set; }
        public bool NoPatternExportedYet { get; set; }
        public bool Error { get; set; }
    }
}
