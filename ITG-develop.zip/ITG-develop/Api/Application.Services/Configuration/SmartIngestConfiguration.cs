﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Services.Configuration
{
    public class SmartIngestConfiguration
    {
        public DispatchTaskConfiguration DispatchService { get; set; }

        public PageExtractTaskConfiguration PageExtractService { get; set; }

        public PageCutTaskConfiguration PageCutService { get; set; }

        public PatternExtractTaskConfiguration PatternExtractService { get; set; }

        public PatternImportTaskConfiguration PatternImportService { get; set; }        
    }

    public abstract class TaskConfigurationBase
    {
        public bool Enabled { get; set; }
        public string Time { get; set; } = "* * * * *";
    }

    public class ArchiveContractGroupTaskConfiguration : TaskConfigurationBase
    {
        public string DocumentsSourcePath { get; set; }        
        public string ErrorsPath { get; set; }                
    }

    public class MatchingReceiverTaskConfiguration : TaskConfigurationBase
    {
        public string ClosingDocumentsInProgressPath { get; set; }
        public string ClosingDocumentsMatchedPath { get; set; }
        public string ClosingDocumentsAmbiguousPath { get; set; }
        public string ClosingDocumentsUnMatchedPath { get; set; }
    }

    public class DeleteContractsScaffoldTaskConfiguration : TaskConfigurationBase
    {
        public string ContractsGroupPath { get; set; }
        public int ImportBatchSize { get; set; }
        
        //It is 48 hours but task will be scheduled by 15 min by 20000 
        public int DeleteAfterHours { get; set; } = 46;

        //This is used also from batch PatternImportTask
        public const int DeleteAfter48Hours = -48;
    }

    public class SendToMatchingTaskConfiguration : TaskConfigurationBase
    {
        public string ClosingDocumentsMatchedPath { get; set; }
        public string ClosingDocumentsAmbiguousPath { get; set; }
        public string ClosingDocumentsNoStampPath { get; set; }
        public string ClosingDocumentsUnMatchedPath { get; set; }
        public string ClosingDocumentsSourcePath { get; set; }        
        public string ClosingDocumentsErrorPath { get; set; }        
        public int ImportBatchSize { get; set; }
    }

    public class ContractMatchingTaskConfiguration : TaskConfigurationBase
    {
        public string ContractsMatchedPath { get; set; }
        public string ContractsAmbiguousPath { get; set; }
        public string ContractsUnMatchedPath { get; set; }
        public string ContractsSourcePath { get; set; }
        public string ContractsErrorPath { get; set; }
        public int ImportBatchSize { get; set; }
    }


    public class KeepAliveTaskConfiguration : TaskConfigurationBase
    {
        public KeepAliveTaskConfiguration()
        {
            Enabled = false;
        }    
    }

    public class PageExtractTaskConfiguration : TaskConfigurationBase
    {
        public string ContractsGroupPath { get; set; }                
        public bool OverrideExistingFile { get; set; }
        public string ContractFileSearchPattern { get; set; }
        public int ImportBatchSize { get; set; }
    }
    public class PageCutTaskConfiguration : TaskConfigurationBase
    {
        public string ContractsGroupPath { get; set; }            
        public int ImportBatchSize { get; set; }
        public int Left { get; set; } = 700;
        public int Bottom { get; set; } = 750;
        public string FileSearchPattern { get; set; } = "*.PNG";
        public bool OverrideExistingFile { get; set; }
    }

    public class PatternExtractTaskConfiguration : TaskConfigurationBase
    {
        public string ContractsGroupPath { get; set; }       
        public bool OverrideExistingFile { get; set; }
        public int ImportBatchSize { get; set; }      
    }

    public class DispatchTaskConfiguration : TaskConfigurationBase
    {
        public string ContractFileSearchPattern { get; set; }        
        public string DocumentsToImportPath { get; set; }
        public string ContractsGroupPath { get; set; }                
        public string ErrorsPath { get; set; }        
        public int ImportBatchSize { get; set; }
    }

    public class PatternImportTaskConfiguration : TaskConfigurationBase
    {
        public string ContractsGroupPath { get; set; }
        public string ContractFileSearchPattern { get; set; }        
        public int ImportBatchSize { get; set; }
        public int MinScoringOnConfirmed { get; set; } = 300;
    }

    public class NewPatternImportTaskConfiguration : PatternImportTaskConfiguration
    {
        public string ErrorsFolderPath { get; set; }
    }

    public class ConfirmPatternTaskConfiguration : PatternImportTaskConfiguration
    {

    }

    public class LoadInn2ContractMapTaskConfiguration : TaskConfigurationBase
    {
        public string BucketName { get; set; }
        public string MappingFileName { get; set; }
    }

    public class SftpDownloaderTaskConfiguration : TaskConfigurationBase
    {
        public string InboundFolderPath { get; set; }
        public string EndsWith { get; set; } = "PDF";
        public string DocumentsToImportPath { get; set; }
        public int ImportBatchSize { get; set; }

        public string HostName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string PrivateKey { get; set; }
    }

    public class CopyFilesFromStorageConfiguration : TaskConfigurationBase
    {
        public string ContractsSourcePath { get; set; }
        public string ContractsDestinationPath { get; set; }
        public string ClosingDocumentSourcePath { get; set; }
        public string ClosingDocumentDestinationPath { get; set; }
        public string ITGContractsBackupPath { get; set; }        
    }
}
