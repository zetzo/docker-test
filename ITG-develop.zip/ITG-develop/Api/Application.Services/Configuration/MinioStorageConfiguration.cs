﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Services.Configuration
{
    public class MinioStorageConfiguration
     {
        public string PatternBucket { get; set; }

    }
}
