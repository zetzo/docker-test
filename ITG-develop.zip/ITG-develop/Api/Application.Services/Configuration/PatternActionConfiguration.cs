﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Services.Configuration
{
    public class PatternActionConfiguration
    {
        public string MainPath { get; set; }
        public string PatternActionPath { get; set; }
    }
}
