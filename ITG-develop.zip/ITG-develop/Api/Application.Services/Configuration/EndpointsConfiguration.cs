﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services.Configuration
{
    public class EndpointsConfiguration
    {
        public class ContractOperations
        {
            public static string SplitContractApiPath() => "/api/v1/Pdf/capture/cut";
        }
        public string CapturifyAPI { get; set; }
        public string SmartWeb { get; set; }
        public string SmartApi { get; set; }
    }
}
