﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Services.Configuration
{
    public class LoadInn2ContractMapConfiguration
    {
        public string MapFilePath { get; set; }
    }
}
