﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Services
{
    public class KibanaConfiguration
    {
        public string Uri { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
        public string MinimumLevel { get; set; }
        public bool AutoRegisterTemplate { get; set; }
        public string AutoRegisterTemplateVersion { get; set; }
        public int BatchPostingLimit { get; set; }
        public int QueueSizeLimit { get; set; }
        public string IndexFormat { get; set; }
    }
}
