﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Common;

namespace Application.Services.Helpers
{
    public class LogEntryMessageExtension
    {
        public static string OnObjectUpdateFindDifferencies(AggregateRoot updatedObject, AggregateRoot previousObject)
        {
            var type = previousObject.GetType();
            var stringBuilder = new StringBuilder();

            foreach (var property in type.GetProperties())
            {
                var oldValue = property.GetValue(previousObject, null);
                var newValue = property.GetValue(updatedObject, null);

                if (!object.Equals(oldValue, newValue))
                {
                    string oldValueString;
                    string newValueString;

                    if (typeof(IEnumerable).IsAssignableFrom(property.PropertyType) && property.PropertyType != typeof(string))
                    {
                        if (typeof(IEnumerable<Entity>).IsAssignableFrom(property.PropertyType))
                        {
                            oldValueString = string.Join(", ", (oldValue as IEnumerable<Entity>).Select(x => x.Id).ToArray());
                            newValueString = string.Join(", ", (newValue as IEnumerable<Entity>).Select(x => x.Id).ToArray());
                        }
                        else
                        {
                            oldValueString = "";
                            newValueString = "";
                        }
                    }
                    else
                    {
                        oldValueString = oldValue == null ? "null" : oldValue.ToString();
                        newValueString = newValue == null ? "null" : newValue.ToString();
                    }

                    stringBuilder.AppendLine($"Property {property.Name} was: {oldValueString}; is: {newValueString}");
                }
            }

            return stringBuilder.ToString();
        }
    }
}
