﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Application.Services.Helpers
{
    public sealed class PdfHelper
    {
        const string DateFormat = "yyyyMMddHHmmss";
        static Regex CreationDateRegex = new Regex(@"/CreationDate(\s*)(?<createddate>\(([\w]+):([\d]+)\+[0-9]{2}'[0-9]{2}'\))");
        static Regex AlternativeDateRegex = new Regex(@"<</CreationDate(\s*)(?<createddate>\(.*\))");
        static Regex ProducerRegex = new Regex(@"/Producer(\s*)(?<producer>\(.*\))");
        static Regex PagesCount = new Regex(@"/Type\s*/Page[^s]");

        public class PdfMetadata
        {
            public DateTime CreationDate { get; set; }
            public int PagesCount { get; internal set; }
            public string FileName { get; internal set; }
            public string Producer { get; internal set; }
        }

        private PdfHelper() { }

        public static PdfHelper Instance { get { return Nested.instance; } }

        private class Nested
        {
            // Explicit static constructor to tell C# compiler
            // not to mark type as beforefieldinit
            static Nested()
            {
            }

            internal static readonly PdfHelper instance = new PdfHelper();
        }

        //private DateTime CreateDateTime(string date) //use the pdfDate as parameter to the date argument
        //{
        //    string dateStr = date.Remove(0, 2).Remove(14, 6); //Remove D: & OHH'mm
        //    string tmpDateStr = dateStr.Substring(0, 4) //Get year i.e yyyy
        //        + "-" + dateStr.Substring(4, 2) // Get month i.e mm & prepend - (hyphen)
        //        + "-" + dateStr.Substring(6, 2) // Get day i.e dd & prepend -
        //        + "T" + dateStr.Substring(8, 2) // Get hour and prepend T
        //        + ":" + dateStr.Substring(10, 2) // Get minutes and prepend :
        //        + ":" + dateStr.Substring(12, 2); //Get seconds and prepend :

        //    return DateTime.Parse(tmpDateStr);
        //}

        public Result<PdfMetadata> ReadMetadaFromFile(string fileName)
        {
            PdfMetadata pdfMetadata = new PdfMetadata();
            pdfMetadata.FileName = Path.GetFileName(fileName);

            try
            {
                using (StreamReader sr = new StreamReader(File.OpenRead(fileName)))
                {
                    string fileContent = sr.ReadToEnd();

                    DateTime parsedDate = ParseDate(fileContent);
                    if(parsedDate == DateTime.MinValue)
                    {
                        parsedDate = ParseDateXeroxFix(fileContent);
                    }
                   
                    Match producerMatch = ProducerRegex.Match(fileContent);
                    if (producerMatch.Success)
                    {
                        string result = producerMatch.Groups["producer"].Value;
                        pdfMetadata.Producer = result;
                    }

                    MatchCollection matches = PagesCount.Matches(fileContent);
                    pdfMetadata.PagesCount = matches.Count;
                    pdfMetadata.CreationDate = parsedDate;

                    return Result.Ok(pdfMetadata);
                }
            }
            catch (Exception e)
            {
                return Result.Fail<PdfMetadata>("Error in PDF file");
            }
        }

        private DateTime ParseDate(string fileContent)
        {
            Match creationDateMatch = CreationDateRegex.Match(fileContent);
            if (creationDateMatch.Success)
            {
                string result = creationDateMatch.Groups["createddate"].Value;

                string datePart = result.Substring(3, DateFormat.Length);

                bool isParsed = DateTime.TryParseExact(datePart, DateFormat, null, System.Globalization.DateTimeStyles.None, out DateTime createdDate);

                if (isParsed)
                    return createdDate;
            }

            return DateTime.MinValue;
        }

        private DateTime ParseDateXeroxFix(string fileContent)
        {
            Match alternativeDateMatch = AlternativeDateRegex.Match(fileContent);
            if (alternativeDateMatch.Success)
            {
                string result = alternativeDateMatch.Groups["createddate"].Value;

                string datePart = result.Substring(1, DateFormat.Length);

                bool isParsed = DateTime.TryParseExact(datePart, DateFormat, null, System.Globalization.DateTimeStyles.None, out DateTime createdDate);

                if (isParsed)
                    return createdDate;
            }

            return DateTime.MinValue;
        }
    }
}

