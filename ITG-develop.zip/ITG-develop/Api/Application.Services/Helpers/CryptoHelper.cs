﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.Data.Common
{
    public sealed class CryptoHelper
    {
        public Result<string> GenSha256FromBytes(byte[] fileContent)
        {
            StringBuilder sha256Builder = new StringBuilder();

            if (fileContent.Length == 0)
                return Result.Fail<string>("Byte Array is Empty");

            using (Stream fileContentStream = new MemoryStream(fileContent))
            {
                byte[] hashBytes = SHA256.Create().ComputeHash(fileContentStream);
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sha256Builder.AppendFormat("{0:X2}", hashBytes[i]);
                }
            }

            return Result.Ok<string>(sha256Builder.ToString());
        }

        public Result<string> GenSha256FromFile(string fileName)
        {
            Result<string> result = Result.Try<string>(() =>
            {

                using (FileStream fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read))
                {
                    byte[] fileContent = new byte[fileStream.Length];

                    fileStream.Read(fileContent, 0, fileContent.Length);

                    Result<string> internalResult = GenSha256FromBytes(fileContent);

                    return internalResult.IsSuccess ? internalResult.Value : internalResult.Error;
                }

            }, e => e.ToString());

            return result;
        }

        public void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");

            using (var hmac = new System.Security.Cryptography.HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

        public bool VerifyPasswordHash(string password, byte[] storedHash, byte[] storedSalt)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");
            if (storedHash.Length != 64) throw new ArgumentException("Invalid length of password hash (64 bytes expected).", "passwordHash");
            if (storedSalt.Length != 128) throw new ArgumentException("Invalid length of password salt (128 bytes expected).", "passwordHash");

            using (var hmac = new System.Security.Cryptography.HMACSHA512(storedSalt))
            {
                var computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                for (int i = 0; i < computedHash.Length; i++)
                {
                    if (computedHash[i] != storedHash[i]) return false;
                }
            };

            return true;
        }
    }
}
