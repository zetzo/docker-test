﻿using Application.Services.Configuration;
using Application.Services.Interfaces;
using CSharpFunctionalExtensions;
using Microsoft.Extensions.Options;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Processing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Exceptions;
using Web.Api.Domain.Models.PatternActions;
using File = Web.Api.Domain.Models.PatternActions.File;

namespace Application.Services.Services
{
    public class PatternActionService : IPatternActionService
    {
        private readonly PatternActionConfiguration Configuration;
        private const string DirectoryNotFoundErrorMessage = "Path does not exist:";

        public PatternActionService(IOptions<PatternActionConfiguration> config)
        {
            Configuration = config.Value;
        }
        public async Task<byte[]> GetFileContent(string path, bool withCompression)
        {
            string filename = Path.Combine(Configuration.PatternActionPath, path);
            byte[] result;

            if (!System.IO.File.Exists(filename))
            {            
                throw new FileNotExistException($"File: {path} does not exist");
            }

            using (FileStream SourceStream = System.IO.File.Open(filename, FileMode.Open))
            {
                result = new byte[SourceStream.Length];
                await SourceStream.ReadAsync(result, 0, (int)SourceStream.Length);
            }

            if (filename.EndsWith("pdf", StringComparison.OrdinalIgnoreCase) || !withCompression)
                return result;

            return OptimizeImageSizeImageSharp(result);
        }

        public Result<PatternSourceFolderStructure> GetFolderStructure(string contractId)
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(Path.Combine(Configuration.PatternActionPath, contractId));

            if (!directoryInfo.Exists)
                throw new DirectoryNotExistException($"{ DirectoryNotFoundErrorMessage } \\{Configuration?.PatternActionPath}\\{ contractId}");

            PatternSourceFolderStructure structure = new PatternSourceFolderStructure()
            {
                ContractId = contractId,
                Path = $"{contractId}",
                Files = GetFiles(directoryInfo, contractId),
                Folders = new List<Folder>()
            };

            foreach (var subdirectoryInfo in directoryInfo.GetDirectories())
            {
                structure.Folders.Add(GetFolderContent(subdirectoryInfo, structure.Path));
            }

            return Result.Ok<PatternSourceFolderStructure>(structure);
        }

        public Result<IEnumerable<FileElement>> GetEntireFolderStructure()
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(Configuration.MainPath);

            if (!directoryInfo.Exists)
                throw new DirectoryNotExistException($"{ DirectoryNotFoundErrorMessage}");

            var elementsList = new List<FileElement>();

            foreach (var subdirectoryInfo in directoryInfo.GetDirectories())
            {
                var folderId = Guid.NewGuid();

                elementsList.Add(new FileElement()
                {
                    Uuid = folderId,
                    IsFolder = true,
                    Extension = "",
                    Name = subdirectoryInfo.Name,
                    Parent = null,
                    CreationDate = subdirectoryInfo.CreationTime
                });

                elementsList = GetFileElements(elementsList, subdirectoryInfo, folderId);
            }

            return Result.Ok<IEnumerable<FileElement>>(elementsList);
        }


        private Folder GetFolderContent(DirectoryInfo directoryInfo, string path)
        {
            Folder folder = new Folder()
            {
                Name = directoryInfo.Name,
                Path = Path.Combine(path, directoryInfo.Name),
                Files = GetFiles(directoryInfo, Path.Combine(path, directoryInfo.Name)),
                ChildFolders = new List<Folder>()
            };

            foreach (var info in directoryInfo.GetDirectories())
            {
                folder.ChildFolders.Add(GetFolderContent(info, folder.Path));
            }

            return folder;
        }

        private byte[] OptimizeImageSizeImageSharp(byte[] imageContent, int quality = 60)
        {
            using (Stream contentStream = new MemoryStream(imageContent))
            {
                using (MemoryStream outStream = new MemoryStream())
                {
                    using (Image image = Image.Load(contentStream))
                    {
                        //var _width = width;
                        //var _height = height == 0 ? (image.Height * width / image.Width) : height;

                        //image.Mutate(x => x.Resize(_width, _height));
                        image.Mutate(x => x.Resize((int)(image.Width * 0.5), (int)(image.Height * 0.5)));

                        var imageEncoder = new JpegEncoder();
                        imageEncoder.Quality = quality;

                        image.Save(outStream, imageEncoder);
                    }

                    return outStream.ToArray();
                }

            }
        }

        private List<File> GetFiles(DirectoryInfo directoryInfo, string path)
        {
            List<File> files = new List<File>();

            foreach (var fileInfo in directoryInfo.GetFiles())
            {
                files.Add(new File() { FileName = fileInfo.Name, FileExtension = fileInfo.Extension, FullName = Path.Combine(path, fileInfo.Name), ActionDisabled = false });
            }

            return files;
        }

        private List<FileElement> GetFileElements(List<FileElement> elementsList, DirectoryInfo directoryInfo, Guid? parentId)
        {
            foreach (var fileInfo in directoryInfo.GetFiles())
            {
                elementsList.Add(new FileElement()
                {
                    Uuid = Guid.NewGuid(),
                    IsFolder = false,
                    Extension = fileInfo.Extension.ToLower(),
                    Name = fileInfo.Name,
                    Parent = parentId,
                    CreationDate = fileInfo.CreationTime
                });
            }

            foreach (var subdirectoryInfo in directoryInfo.GetDirectories())
            {
                var elementId = Guid.NewGuid();

                elementsList.Add(new FileElement()
                {
                    Uuid = elementId,
                    IsFolder = true,
                    Extension = "",
                    Name = subdirectoryInfo.Name,
                    Parent = parentId,
                    CreationDate = subdirectoryInfo.CreationTime
                });

                elementsList = GetFileElements(elementsList, subdirectoryInfo, elementId);
            }

            return elementsList;
        }
    }
}
