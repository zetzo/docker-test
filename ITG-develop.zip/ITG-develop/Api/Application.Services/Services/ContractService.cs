﻿using Application.Services.Configuration;
using Application.Services.ViewModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Text;
using Microsoft.Extensions.Options;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Application.Services.Exceptions;
using Application.Services.Interfaces;
using CSharpFunctionalExtensions;
using System.IO;

namespace Application.Services.Services
{
    public class ContractService : IContractService
    {
        private readonly IRequestProvider _requestProvider;
        private readonly EndpointsConfiguration _config;

        public ContractService(IRequestProvider requestProvider, IOptions<EndpointsConfiguration> config)
        {
            _requestProvider = requestProvider;
            _config = config.Value;
        }

        public async Task<Result<ContractImagesResponse>> SplitPdfIntoImages(ContractPdfRequest contract)
        {
            var contractContent = new StringContent(JsonConvert.SerializeObject(contract), System.Text.Encoding.UTF8, "application/json");

            return await Result.Try(async () =>
                    await _requestProvider.PostAsync<ContractImagesResponse>
                                (_config.CapturifyAPI + EndpointsConfiguration.ContractOperations.SplitContractApiPath(), contractContent));
        }

        public string CutOutContractCodeFromFileName(string fileName)
        {
            int startIndex = fileName.LastIndexOf('_');
            int lenght = fileName.LastIndexOf('.') - startIndex;
            int _contractCode;

            var contractCode = fileName.Substring(startIndex + 1, lenght - 1);

            if (!Int32.TryParse(contractCode, out _contractCode))
                return "";

            return contractCode;
        }
    }
}
