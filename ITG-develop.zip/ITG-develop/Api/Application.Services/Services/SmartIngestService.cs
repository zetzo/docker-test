﻿using Application.Services.Configuration;
using Application.Services.Extensions;
using CSharpFunctionalExtensions;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Web.Api.Data.Repository;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;

namespace Application.Services
{
    public class SmartIngestService
    {
        private readonly IPageExtractRepository _pageExtractRepository;
        private readonly IPageCutRepository _pageCutRepository;
        private readonly IPatternImportRepository _patternImportRepository;
        private readonly IPatternImportLogRespository _patternImportLogRespository;
        private readonly IOptions<PatternExtractTaskConfiguration> _patternExtractTaskConfiguration;
        private readonly ContractFinder _contractFinder;

        public SmartIngestService(IPageExtractRepository pageExtractRepository, IPageCutRepository pageCutRepository, IPatternImportRepository patternImportRepository,
           IPatternImportLogRespository patternImportLogRespository, IOptions<PatternExtractTaskConfiguration> patternExtractTaskConfiguration,
            ContractFinder contractFinder)
        {
            _pageExtractRepository = pageExtractRepository;
            _pageCutRepository = pageCutRepository;
            _patternImportRepository = patternImportRepository;
            _patternImportLogRespository = patternImportLogRespository;
            _patternExtractTaskConfiguration = patternExtractTaskConfiguration;
            _contractFinder = contractFinder;
        }

        //pdf specific file with page number
        public async Task AddPageForExtractBy(string importFileName, int pageNumber)
        {          
            await _pageExtractRepository.AddPageExtract(importFileName, pageNumber);            
        }

        public Maybe<PageExtract> GetPageForExtractBy(string importFileName)
        {            
            return _pageExtractRepository.GetBy(importFileName);
        }

        public async Task<IList<PageExtract>> GetAllPagesForExtract()
        {
            return await _pageExtractRepository.GetAll();
        }

        public async Task RemovePageExtract(string importFileName)
        {            
            await _pageExtractRepository.RemoveBy(importFileName);
        }

        //cut specific page file adding additional height and margin left;
        public async Task AddOverridePageCut(string cyrylicFileName, int cutLeft, int cutBottom)
        {
            //Result<string> contractResult = _contractFinder.GetFromFile(cyrylicFileName);
            //string fileToDeleteFullPath = Path.Combine(_patternExtractTaskConfiguration.Value.ContractsGroupPath, contractResult.Value, "Patterns", cyrylicFileName);
            //FileExt.DeleteIfExists(fileToDeleteFullPath);

            await _pageCutRepository.AddPageCut(cyrylicFileName, cutLeft, cutBottom);
        }

        public Maybe<PageCut> GetOverridePageCut(string importFileName)
        {            
            return _pageCutRepository.GetBy(importFileName);
        }

        public IReadOnlyList<PageCut> GetAllOverridePageCut()
        {
            return _pageCutRepository.GetAll();
        }

        public async Task RemoveOverridePageCut(string importFileName)
        {            
            await _pageCutRepository.RemoveBy(importFileName);
        }

        public async Task SetPatternToImport(string cyrylicFileName)
        {
            Result<string> contractResult =_contractFinder.GetFromFile(cyrylicFileName);
            
            await _patternImportRepository.AddPatternImport(contractResult.Value, cyrylicFileName);            
        }

        public Maybe<PatternImport> GetPatternToImportBy(string contractId)
        {            
            return _patternImportRepository.GetBy(contractId);
        }
     
        public async Task<IList<PatternImport>> GetAllPatternsToImport(bool filled = true)
        {            
            return await _patternImportRepository.GetAll();
        }

        public async Task RemovePatternToImport(string contractId)
        {            
            await _patternImportRepository.RemoveBy(contractId);
        }

        public async Task SetPatternToImportByContractId(string contractId, string cyrylicFileName, PatternStatusEnum status)
        {
            if(status == PatternStatusEnum.Confirmed)
                await _patternImportRepository.AddPatternImportWithConfirmOld(contractId, cyrylicFileName);
        }
       
        public async Task UpdatePatternImportLog(PatternImportLog patternImportLog)
        {
            await _patternImportLogRespository.Update(patternImportLog);
        }

        public async Task AddPatternImportLog(PatternImportLog patternImportLog)
        {
            await _patternImportLogRespository.Add(patternImportLog);
        }
    }
}
