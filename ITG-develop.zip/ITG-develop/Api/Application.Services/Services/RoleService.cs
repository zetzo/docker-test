﻿using Application.Services.Extensions;
using Application.Services.Helpers;
using Application.Services.Interfaces;
using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models.DomainEvent;
using Web.Api.Domain.Models.Roles;

namespace Application.Services.Services
{
    public class RoleService : IRoleService
    {
        private readonly IRoleRepository _roleRepository;
        private readonly IDomainEventsPublisher _publisher;
        public RoleService(IRoleRepository roleRepository, IDomainEventsPublisher publisher)
        {
            _roleRepository = roleRepository;
            _publisher = publisher;
        }
        public async Task<Result> Create(Role role, int userId)
        {
            role.CreateLogEntry(builder =>
                builder.In(DomainModelTypeEnum.Role)
                       .At(ActionTypeEnum.Create)
                       .WithResult(ActionResultEnum.Published)
                       .WithMessage((_) => $"Role has been created", role)
                       .AsUser(userId));

            var result = Result.Try(async () => await _roleRepository.Create(role), e => e.Message);

            await result.OnSuccessTry(async (_) => await _publisher.DispatchDomainEventsAsync(role), e => e.Message)
                .OnFailure(async (_) => {
                    role.ChangeDomainEventActionResult(ActionResultEnum.PublishedFailed);
                    await _publisher.DispatchDomainEventsAsync(role);
                });

            return await Task.Run(() =>
                        Result.Try(async () => await _roleRepository.Create(role), e => e.Message)
                              .MapResultOnCreation(role)
                              .Tap(async () => await _publisher.DispatchDomainEventsAsync(role))
                        );
        }

        public async Task<Result<Role>> Get(int id)
        {
            return await Task.Run(() => Result.Try(() => _roleRepository.Get(id)));
        }

        public async Task<Result<IEnumerable<Role>>> GetAll()
        {
            //return await _roleRepository.GetAll();
            return await Task.Run(() => Result.Try(() => _roleRepository.GetAll()));
        }

        public async Task<Result> Update(Role role, string name, string desc, IEnumerable<Permissions> permissions, bool isActive, int userId)
        {
            Role roleBefore = (Role)role.ShallowCopy();
            Role roleAfter = role.Update(name, desc, permissions, isActive);

            role.CreateLogEntry(builder =>
                builder.In(DomainModelTypeEnum.Role)
                       .At(ActionTypeEnum.Update)
                       .WithResult(ActionResultEnum.Published)
                       .WithMessage(LogEntryMessageExtension.OnObjectUpdateFindDifferencies, roleAfter, roleBefore)
                       .RelatedTo((int)roleAfter.Id)
                       .AsUser(userId));

            return await Task.Run(() =>
                    Result.Try(async () => await _roleRepository.Update(roleAfter), e => e.Message)
                          .MapResultOnUpdate(roleAfter)
                          .Tap(async () => await _publisher.DispatchDomainEventsAsync(role))
            );
        }
    }
}
