﻿using Application.Services.Interfaces;
using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;

namespace Application.Services.Services
{
    public class InfoService : IInfoService
    {
        private readonly IInfoRepository _infoRepository;
        public InfoService(IInfoRepository infoRepository)
        {
            _infoRepository = infoRepository;
        }

        public async Task<Result<IEnumerable<VersionInfo>>> GetLatestVersionInfo(int number)
        {
            return await Result.Try(async () =>
                await _infoRepository.GetLatestVersionInfo(number));
        }

        public async Task<Result<IEnumerable<MessageForUsers>>> GetLatestUserMessages(int number)
        {
            return await Result.Try(async () =>
                await _infoRepository.GetLatestUserMessages(number));
        }

        public async Task CreateUserMessage(MessageForUsers message)
        {
            await _infoRepository.CreateUserMessages(message);
            //return Result.Try(async () => await _infoRepository.CreateUserMessages(message), (e) => e.ToString());
        }
    }
}
