﻿using Application.Services.Configuration;
using Application.Services.Interfaces;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Data.Common;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;
using System.Linq;
using Web.Api.Domain.Models.Roles;
using CSharpFunctionalExtensions;
using Web.Api.Domain.Models.DomainEvent;
using Application.Services.Helpers;
using Application.Services.Extensions;

namespace Application.Services
{
    public class UserService : IUserService
    {
        private readonly TokenManagementConfiguration _config;
        private readonly IUserRepository _userRepository;
        private readonly CryptoHelper _cryptoHelper;
        private readonly IDomainEventsPublisher _publisher;

        public UserService(IUserRepository userRepository, IOptions<TokenManagementConfiguration> config, 
            CryptoHelper cryptoHelper, IDomainEventsPublisher publisher)
        {
            _userRepository = userRepository;
            _config = config.Value;
            _cryptoHelper = cryptoHelper;
            _publisher = publisher;
        }
        public async Task<User> Authenticate(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                return null;

            var user = await _userRepository.GetByUsername(username);

            if (user == null)
                return null;

            if (!_cryptoHelper.VerifyPasswordHash(password, user.PasswordHash, user.PasswordSalt))
                return null;

            return user;
        }

        public async Task<User> Create(User user, string password)
        {
            if (string.IsNullOrWhiteSpace(password))
                throw new Exception("Password is required");

            if (await _userRepository.Exist(user.Username))
                throw new Exception("Username \"" + user.Username + "\" is already taken");

            byte[] passwordHash, passwordSalt;
            _cryptoHelper.CreatePasswordHash(password, out passwordHash, out passwordSalt);

            user.PasswordHash = passwordHash;
            user.PasswordSalt = passwordSalt;

            await _userRepository.Create(user);

            return user;
        }

        public async Task<User> CreateIbmIdUser(string username, string firstname, string lastname)
        {
            var user = User.CreateUserFromIbmId(username, firstname, lastname);
            await _userRepository.Create(user);
            return user;
        }

        public string GenerateUserToken(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_config.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(PackClaims(user)),
                Expires = DateTime.UtcNow.AddHours(3),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        public async Task<Result<IEnumerable<User>>> GetAll()
        {
            return await Task.Run(() => Result.Try(async () => await _userRepository.GetAll()));
        }

        public async Task<Result<User>> GetByUsername(string username)
        {
            return await Task.Run(() => Result.Try(async () => await _userRepository.GetByUsername(username)));
        }
        public async Task<Result<User>> GetById(int id)
        {
            return await Task.Run(() => Result.Try(async () => await _userRepository.GetById(id)));
        }

        public async Task<Result> Update(User user, string username, string firstname, string lastname, IEnumerable<Role> roles, bool isAdmin, bool isConfirmed, string settings, int userId)
        {
            User userBefore = (User)user.ShallowCopy();
            User userAfter = user.Update(username, firstname, lastname, roles, isAdmin, isConfirmed);
            userAfter.UpdateUserSettings(settings);

            user.CreateLogEntry(builder =>
                builder.In(DomainModelTypeEnum.User)
                       .At(ActionTypeEnum.Update)
                       .WithResult(ActionResultEnum.Published)
                       .WithMessage(LogEntryMessageExtension.OnObjectUpdateFindDifferencies, userAfter, userBefore)
                       .RelatedTo((int)user.Id)
                       .AsUser(userId));

            return await Task.Run(() =>
                Result.Try(async () => await _userRepository.Update(user))
                      .MapResultOnUpdate(user)
                      .Tap(async () => await _publisher.DispatchDomainEventsAsync(user))
            );
        }

        private Claim[] PackClaims(User user)
        {
            List<Claim> claims = new List<Claim>();

            claims.Add(new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()));

            foreach (var role in user.Roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role.AggregatedPermissionList));
            }

            return claims.ToArray();
        }

        public User DebugMode()
        {
            var roles = new List<Role>()
            {
                Role.Create("admin", "admin", (IEnumerable<Permissions>)Enum.GetValues(typeof(Permissions)), true)
            };
            return User.CreateForDebugMode(roles);
        }
    }
}
