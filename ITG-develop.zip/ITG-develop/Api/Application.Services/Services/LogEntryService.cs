﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Application.Services.Interfaces;
using CSharpFunctionalExtensions;
using MediatR;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models.DomainEvent;
using Web.Api.Domain.Models.Paging;

namespace Application.Services.Services
{
    public class LogEntryService : ILogEntryService
    {
        private readonly ILogEntryRepository _logEntryRepository;
        public LogEntryService(ILogEntryRepository logEntryRepository)
        {
            _logEntryRepository = logEntryRepository;
        }
        public async Task<Result<PagedResult<LogEntry>>> GetPagedAsync(int pageIndex, int pageSize)
        {
            return await Result.Try(async () =>
                await _logEntryRepository.GetPagedAsync(pageIndex, pageSize));
        }
    }
}
