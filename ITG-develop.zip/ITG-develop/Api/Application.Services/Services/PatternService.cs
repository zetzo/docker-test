﻿using Application.Services.Configuration;
using Application.Services.Extensions;
using Application.Services.Helpers;
using Application.Services.Interfaces;
using Application.Services.ViewModels;
using CSharpFunctionalExtensions;
using Microsoft.Extensions.Options;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Web.Api.Data.Common;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.DomainEvent;
using Web.Api.Domain.Models.Paging;
using Web.Api.Domain.Models.PatternActions;
using static Application.Services.ContractFinder;
using SixLabors.ImageSharp.Formats.Jpeg;
using System.Collections.ObjectModel;
using ExcelDataReader;
using NHibernate.Mapping;
using System.Diagnostics;

namespace Application.Services
{
    public class PatternService : IPatternService
    {
        public const string PatternNotFoundErrorMessage = "Pattern not found";
        public const string PatternContentNotFoundErrorMessage = "Pattern file not found";
        private const string WarningFromExporter = "warning";
        private static readonly IList<PatternStatusEnum> statusesToRemoveScaffolding = new ReadOnlyCollection<PatternStatusEnum>(
                new List<PatternStatusEnum> { PatternStatusEnum.Confirmed, PatternStatusEnum.VendorHasNoStamp, PatternStatusEnum.NotInUse }
            );

        private readonly IPatternRepository _patternRepository;
        private readonly IStorageRepository _patternStorageRepository;
        private readonly ContractFinder _contractFinder;
        private readonly CryptoHelper _cryptoHelper;
        private readonly IDomainEventsPublisher _publisher;
        private readonly IOptions<MinioStorageConfiguration> _minioStorageConfiguration;
        protected readonly IInnContractRepository _innContractRepository;
        public PatternService(
            IPatternRepository patternRepository,
            IStorageRepository patternStorageRepository,
          ContractFinder contractFinder, CryptoHelper cryptoHelper, IOptions<MinioStorageConfiguration> minioStorageConfiguration, IInnContractRepository innContractRepository)
        {
            _patternRepository = patternRepository;
            _patternStorageRepository = patternStorageRepository;
            _contractFinder = contractFinder;
            _cryptoHelper = cryptoHelper;
            _minioStorageConfiguration = minioStorageConfiguration;
            _innContractRepository = innContractRepository;
        }

        public PatternService(IPatternRepository patternRepository, IStorageRepository patternStorageRepository,
            ContractFinder contractFinder, CryptoHelper cryptoHelper, IDomainEventsPublisher publisher, IOptions<MinioStorageConfiguration> minioStorageConfiguration, IInnContractRepository innContractRepository) :
            this(patternRepository, patternStorageRepository, contractFinder, cryptoHelper, minioStorageConfiguration, innContractRepository)
        {
            _publisher = publisher;
        }

        public async Task<Result> AddNewPatternFromFile(string fileName, DateTime createdDate, byte[] content)
        {
            Result<string> contractResult = _contractFinder.GetFromFile(fileName);
            Result<string> sha256Result = _cryptoHelper.GenSha256FromBytes(content);

            Result fileContractResult = Result.Combine(contractResult, sha256Result);

            //On Success
            Result result = await fileContractResult.Tap(async () =>
            {
                string contractId = contractResult.Value;
                string sha256Value = sha256Result.Value;
                string latinFileName = GetLatinFromCyrylic(fileName);

                Pattern pattern = Pattern.CreateNew(contractId, createdDate, fileName, latinFileName, sha256Value);

                await Result
                .Try(async () => await _patternStorageRepository.Add(_minioStorageConfiguration.Value.PatternBucket, sha256Value, content), (e) => e.ToString())
                .Tap(async () => { await _patternRepository.Create(pattern); });
            });

            return result;
        }

        public async Task<Result> AddNewPattern(string fileName, string description, byte[] content, string contractId, int userId, string inn = "")
        {
            Result<string> sha256Result = _cryptoHelper.GenSha256FromBytes(content);

            Result result = await sha256Result.Tap(async () =>
            {
                string sha256Value = sha256Result.Value;

                Pattern pattern = Pattern.CreateNew(contractId, fileName, description, sha256Value, inn);

                pattern.CreateLogEntry(builder =>
                        builder.In(DomainModelTypeEnum.Pattern)
                                .At(ActionTypeEnum.Create)
                                .WithResult(ActionResultEnum.Published)
                                .WithMessage((_) => $"Pattern with Id: {pattern.Id}", pattern)
                                .AsUser(userId));

                await Result.Try<Task<bool>>(async () => await _patternStorageRepository.Add(_minioStorageConfiguration.Value.PatternBucket, sha256Value, content), (e) => e.ToString())
                        .OnSuccessTry(async (_) => await _patternRepository.CreateNew(pattern), e => e.Message)
                        .MapResultOnCreation(pattern)
                        .Tap(async () => await _publisher.DispatchDomainEventsAsync(pattern));
            });

            return result;
        }

        public async Task<Result> AddNewPattern(Pattern pattern, string patternContent, int userId)
        {
            var content = Convert.FromBase64String(patternContent);

            return await AddNewPattern(pattern.ImportFileName, pattern.Description, content, pattern.ContractId, userId, pattern.INN);
        }

        public async Task<Result> AddNewPatternContent(string key, string content)
        {
            byte[] patternContent = Convert.FromBase64String(content);
            Result<string> sha256Result = _cryptoHelper.GenSha256FromBytes(patternContent);

            if (sha256Result.IsFailure || sha256Result.Value != key)
                return Result.CreateFailure(true, "Failed to generate hash for pattern");

            return await Result.Try(async () => await _patternStorageRepository.Add(_minioStorageConfiguration.Value.PatternBucket, sha256Result.Value, patternContent), (e) => e.ToString());
        }

        public async Task<Result> DeletePattern(string entityId, int userId)
        {
            var pattern = await _patternRepository.GetByEntityId(entityId);

            if (pattern == null)
                return Result.Fail($"Pattern not found for entity ID: {entityId}");

            pattern.CreateLogEntry(builder =>
                                builder.In(DomainModelTypeEnum.Pattern)
                                       .At(ActionTypeEnum.Delete)
                                       .WithResult(ActionResultEnum.Published)
                                       .WithMessage((_) => $"Pattern with Id: {pattern.Id} has been deleted", pattern)
                                       .RelatedTo((int)pattern.Id)
                                       .AsUser(userId));
            return await Task.Run(() =>
                Result.Try(async () => await _patternRepository.Delete(pattern), (e) => e.ToString())
                      .MapResultOnDelete(pattern)
                      .Tap(async () => await _publisher.DispatchDomainEventsAsync(pattern))
            );
        }

        public async Task<Result> DeletePatternContent(string entityId)
        {
            return await Result.Try(async () => await _patternStorageRepository.Delete(_minioStorageConfiguration.Value.PatternBucket, entityId), (e) => e.ToString());
        }

        public async Task<IEnumerable<Pattern>> GetAll()
        {
            return await _patternRepository.GetAll();
        }

        public async Task<IEnumerable<Pattern>> GetAll(Expression<Func<Pattern, bool>> predicate)
        {
            return await _patternRepository.GetAll(predicate);
        }

        public async Task<PagedResult<Pattern>> GetPagedAsync(int pageIndex, int pageSize)
        {
            return await _patternRepository.GetPagedAsync(pageIndex, pageSize);
        }

        public async Task<PagedResult<Pattern>> GetPagedAsync(int pageIndex, int pageSize, List<FilterModel> filters)
        {
            return await _patternRepository.GetPagedAsync(pageIndex, pageSize, filters);
        }

        public async Task<Result<PatternContentResult>> GetPatternContent(string sha256)
        {
            Pattern pattern = await _patternRepository.GetByEntityId(sha256);

            if (pattern == null)
                return Result.Fail<PatternContentResult>(PatternNotFoundErrorMessage);

            Result<byte[]> patternContent =
                    await Result.Try(async () => await _patternStorageRepository.GetById(_minioStorageConfiguration.Value.PatternBucket, pattern.EntityId), (e) => e.ToString());

            if (patternContent.IsFailure)
                return Result.Fail<PatternContentResult>(PatternContentNotFoundErrorMessage);

            return Result.Ok(PatternContentResult.Create(patternContent.Value, pattern.ContentType));
        }

        [Obsolete("This method should be removed", true)]
        public async Task<IEnumerable<PatternContent>> GetMultiplePatternContent(string[] sha256Keys)
        {
            return await _patternStorageRepository.GetMany(new List<string>(sha256Keys));
        }

        public async Task<Result<Pattern>> GetPatternById(long id)
        {
            var pattern = await _patternRepository.GetById(id);

            if (pattern == null)
                return Result.Fail<Pattern>(PatternNotFoundErrorMessage);

            return Result.Ok(pattern);
        }

        public async Task<Result> UpdatePattern(Pattern pattern, string contractId, string inn, string description, string entityId,
            string importFileName, string imageData, string status, int userId)
        {
            var imageHashResult = _cryptoHelper.GenSha256FromBytes(Convert.FromBase64String(imageData));
            var imageHash = imageHashResult.IsSuccess ? imageHashResult.Value : "";
            var iconData = pattern.Icon;

            if (!string.IsNullOrEmpty(imageHash) && !pattern.HasPatternSameContentHash(imageHash))
            {
                var result = await AddNewPatternContent(imageHash, imageData).Tap(() =>
                {
                    entityId = imageHash;
                });

                byte[] imageContent = Convert.FromBase64String(imageData);
                iconData = OptimizeImageSizeImageSharp(imageContent, 200);
            }

            //This is for deleting scaffolding from task 
            if(statusesToRemoveScaffolding.Any(x => x.ToString().Equals(status, StringComparison.OrdinalIgnoreCase)))
                pattern.SetImportDate(DateTime.Now.AddHours(DeleteContractsScaffoldTaskConfiguration.DeleteAfter48Hours));
           
            Pattern patternBeforeUpdate = (Pattern)pattern.ShallowCopy();
            var patternAfterUpdate = pattern.Update(inn, description, entityId, importFileName);
            patternAfterUpdate.SetIconContent(iconData);

            if (!string.IsNullOrEmpty(status))
                patternAfterUpdate.SetStatus(status);

            patternAfterUpdate.CreateLogEntry(builder =>
                                    builder.In(DomainModelTypeEnum.Pattern)
                                            .At(ActionTypeEnum.Update)
                                            .WithResult(ActionResultEnum.Published)
                                            .WithMessage(LogEntryMessageExtension.OnObjectUpdateFindDifferencies, patternAfterUpdate, patternBeforeUpdate)
                                            .RelatedTo((int)patternAfterUpdate.Id)
                                            .AsUser(userId));
            return await Task.Run(() =>
                    Result.Try(async () => await _patternRepository.Update(patternAfterUpdate), e => e.Message)
                          .MapResultOnUpdate(patternAfterUpdate)
                          .Tap(async () => await _publisher.DispatchDomainEventsAsync(patternAfterUpdate))
            );
        }

        public async Task<Result> UpdatePattern(Pattern pattern, int userId)
        {
            return await Task.Run(() =>
                    Result.Try(async () => await _patternRepository.Update(pattern), e => e.Message));
        }

        public async Task<Result> UpdatePatternByContractId(string contractId, byte[] content)
        {
            var imageHashResult = _cryptoHelper.GenSha256FromBytes(content);
            Pattern pattern = await _patternRepository.GetByContractId(contractId);
            try
            {
                await _patternStorageRepository.Delete(_minioStorageConfiguration.Value.PatternBucket, pattern.EntityId);

                pattern.ChangeEntityId(imageHashResult.Value);
                pattern.SetImportDate(DateTime.Now);
                await _patternRepository.Update(pattern);

                await _patternStorageRepository.Add(_minioStorageConfiguration.Value.PatternBucket, imageHashResult.Value, content);
            }
            catch (Exception e)
            {
                return Result.Fail(e.Message);
            }

            return Result.Ok();

        }

        public async Task<Result<string>> GetContractIdFromFile(string fileName)
        {
            return await Task.FromResult(_contractFinder.GetFromFile(fileName));
        }

        public string GetLatinFromCyrylic(string value)
        {
            return _contractFinder.GetLatinFromCyrylic(value);
        }

        public Result<ContractFinderResult> GetContractResultFromDocumentFile(string fullfileName, int wherePageCountBiggerThen = 4)
        {
            Result<string> contractIdResult = _contractFinder.GetFromFile(fullfileName);
            if (contractIdResult.IsFailure)
                return Result.Fail<ContractFinderResult>(contractIdResult.Error);

            return Result.Ok(new ContractFinderResult { ContractId = contractIdResult.Value });
        }

        [Obsolete("This method should be removed", true)]
        //return same content for now, add external service connection once available
        public async Task<Result<IEnumerable<PatternImageRefitted>>> CropImage(IEnumerable<long> patternIds)
        {
            Result<IEnumerable<Pattern>> patternResult = await Result
                .Try<IEnumerable<Pattern>>(async () => await _patternRepository.GetAll(x => patternIds.Contains(x.Id)), (e) => e.ToString());

            Result<IEnumerable<PatternContent>> patternContentResult = await patternResult
                .Map(async patterns => await _patternStorageRepository.GetMany(patterns.Select(x => x.EntityId).ToList()));

            Result<IEnumerable<PatternImageRefitted>> result = patternContentResult
                .Map(content =>
                    content.Join<PatternContent, Pattern, string, PatternImageRefitted>
                        (patternResult.Value, x => x.Key, y => y.EntityId,
                            (x, y) => new PatternImageRefitted() { Id = y.Id, ImageData = Convert.ToBase64String(x.Value) }));

            return result;
        }

        //return same content for now, add external service connection once available
        [Obsolete("This method should be removed", true)]
        public async Task<Result<IEnumerable<PatternImageRefitted>>> AdjustContrast(IEnumerable<long> patternIds)
        {
            Result<IEnumerable<Pattern>> patternResult = await Result
                .Try<IEnumerable<Pattern>>(async () => await _patternRepository.GetAll(x => patternIds.Contains(x.Id)), (e) => e.ToString());

            Result<IEnumerable<PatternContent>> patternContentResult = await patternResult
                .Map(async patterns => await _patternStorageRepository.GetMany(patterns.Select(x => x.EntityId).ToList()));

            Result<IEnumerable<PatternImageRefitted>> result = patternContentResult
                .Map(content =>
                    content.Join<PatternContent, Pattern, string, PatternImageRefitted>
                        (patternResult.Value, x => x.Key, y => y.EntityId,
                            (x, y) => new PatternImageRefitted() { Id = y.Id, ImageData = Convert.ToBase64String(x.Value) }));

            return result;
        }

        public async Task<bool> CheckIfPatternExistsInDb(string sha2)
        {
            Pattern patternExistsInDb = await _patternRepository.GetByEntityId(sha2);
            return await Task.FromResult(patternExistsInDb != null);
        }
        public Task<Result> UpdatePatternContent(string entityId, byte[] content)
        {
            throw new NotImplementedException();
        }

        public async Task<Result> UpdatePatternByContractId(string contractId, string importFileName, DateTime creationDate, byte[] content)
        {
            var imageHashResult = _cryptoHelper.GenSha256FromBytes(content);
            Pattern pattern = await _patternRepository.GetByContractId(contractId);
            try
            {
                await _patternStorageRepository.Delete(_minioStorageConfiguration.Value.PatternBucket, pattern.EntityId);
                pattern.SetImportFileName(importFileName);
                pattern.SetLatinImportFileName(_contractFinder.GetLatinFromCyrylic(importFileName));
                pattern.ChangeEntityId(imageHashResult.Value);
                pattern.SetImportDate(DateTime.Now);
                pattern.SetCreationDate(creationDate);
                await _patternRepository.Update(pattern);

                await _patternStorageRepository.Add(_minioStorageConfiguration.Value.PatternBucket, imageHashResult.Value, content);
            }
            catch (Exception e)
            {
                return Result.Fail(e.Message);
            }

            return Result.Ok();
        }

        public async Task<Result> UpdatePatternByContractIdSetImport48HoursOld(string contractId, string importFileName, DateTime creationDate, byte[] content)
        {
            var imageHashResult = _cryptoHelper.GenSha256FromBytes(content);
            Pattern pattern = await _patternRepository.GetByContractId(contractId);
            try
            {
                await _patternStorageRepository.Delete(_minioStorageConfiguration.Value.PatternBucket, pattern.EntityId);
                pattern.SetImportFileName(importFileName);
                pattern.SetLatinImportFileName(_contractFinder.GetLatinFromCyrylic(importFileName));
                pattern.ChangeEntityId(imageHashResult.Value);
                pattern.SetImportDate(DateTime.Now.AddHours(DeleteContractsScaffoldTaskConfiguration.DeleteAfter48Hours));
                pattern.SetCreationDate(creationDate);
                pattern.SetStatus(PatternStatusEnum.Confirmed.ToString());
                pattern.SetIconContent(OptimizeImageSizeImageSharp(content, 200));

                await _patternRepository.Update(pattern);

                await _patternStorageRepository.Add(_minioStorageConfiguration.Value.PatternBucket, imageHashResult.Value, content);
            }
            catch (Exception e)
            {
                return Result.Fail(e.Message);
            }

            return Result.Ok();
        }


        public async Task<Maybe<Pattern>> GetPatternByContractId(string contractId)
        {
            return await _patternRepository.GetByContractId(contractId);
        }

        public async Task<Result> AddNewPatternFromFile(string fileName, DateTime creationDate, byte[] content, bool isWarningFile)
        {
            Result<string> contractResult = _contractFinder.GetFromFile(fileName);
            Result<string> sha256Result = _cryptoHelper.GenSha256FromBytes(content);

            Result fileContractResult = Result.Combine(contractResult, sha256Result);

            //On Success
            Result result = await fileContractResult.Tap(async () =>
            {
                string contractId = contractResult.Value;
                string sha256Value = sha256Result.Value;
                string latinFileName = GetLatinFromCyrylic(fileName);

                Pattern pattern = Pattern.CreateNew(contractId, creationDate, fileName, latinFileName, sha256Value);
                pattern.SetIconContent(OptimizeImageSizeImageSharp(content, 200));

                if (isWarningFile)
                    pattern.SetStatus(PatternStatusEnum.Warning.ToString());
                else
                    pattern.SetStatus(PatternStatusEnum.Unconfirmed.ToString());

                await Result.Try(async () => await _patternStorageRepository.Add(_minioStorageConfiguration.Value.PatternBucket, sha256Value, content), (e) => e.ToString())
                            .Tap(async () => { await _patternRepository.Create(pattern); });
            });

            return result;
        }

        public async Task<Result> UpdatePatternByContractId(string contractId, string importFileName, DateTime creationDate, byte[] content, bool isWarningFile)
        {
            var imageHashResult = _cryptoHelper.GenSha256FromBytes(content);
            Pattern pattern = await _patternRepository.GetByContractId(contractId);
            try
            {
                await _patternStorageRepository.Delete(_minioStorageConfiguration.Value.PatternBucket, pattern.EntityId);
                pattern.SetImportFileName(importFileName);
                pattern.SetLatinImportFileName(_contractFinder.GetLatinFromCyrylic(importFileName));
                pattern.ChangeEntityId(imageHashResult.Value);
                pattern.SetImportDate(DateTime.Now);
                pattern.SetCreationDate(creationDate);

                if (isWarningFile)
                    pattern.SetStatus(PatternStatusEnum.Warning.ToString());
                else
                    pattern.SetStatus(PatternStatusEnum.Unconfirmed.ToString());

                pattern.SetIconContent(OptimizeImageSizeImageSharp(content, 200));

                await _patternRepository.Update(pattern);

                await _patternStorageRepository.Add(_minioStorageConfiguration.Value.PatternBucket, imageHashResult.Value, content);
            }
            catch (Exception e)
            {
                return Result.Fail(e.Message);
            }

            return Result.Ok();
        }

        public PatternFileResult FindCorrectPatternFile(FileInfo[] contractFilesInfo, string rootDirectory)
        {
            Result<PdfHelper.PdfMetadata> pdfFile = contractFilesInfo.Select(x => PdfHelper.Instance.ReadMetadaFromFile(x.FullName)).Where(y => y.IsSuccess).OrderByDescending(y => y.Value.CreationDate).FirstOrDefault();

            if (pdfFile.IsFailure)
                return new PatternFileResult {  Error = true};

            string patternFile = Path.ChangeExtension(pdfFile.Value.FileName, "PNG");

            string patternFileFullName = Path.Combine(rootDirectory, "Patterns", patternFile);

            return new PatternFileResult { PatternFile = patternFile, PatternFileFullName = patternFileFullName, PdfFile = pdfFile };
        }

        public PatternFileResult FindPatternWarningFile(FileInfo[] contractFilesInfo, string rootDirectory)
        {
            Result<PdfHelper.PdfMetadata> pdfFile = contractFilesInfo.Select(x => PdfHelper.Instance.ReadMetadaFromFile(x.FullName)).Where(y => y.IsSuccess).OrderByDescending(y => y.Value.CreationDate).FirstOrDefault();

            string patternFile = Path.GetFileNameWithoutExtension(pdfFile.Value.FileName) + $"_{WarningFromExporter.ToUpper()}_.PNG";

            string patternFileFullName = Path.Combine(rootDirectory, "Patterns", patternFile);

            return new PatternFileResult { PatternFile = patternFile, PatternFileFullName = patternFileFullName, PdfFile = pdfFile, IsWarningFile = true };
        }

        public PatternFileResult FindPatternFile(FileInfo[] contractFilesInfo, string rootDirectory)
        {
            try
            {
                PatternFileResult patternFileResult = FindCorrectPatternFile(contractFilesInfo, rootDirectory);

                if (!System.IO.File.Exists(patternFileResult.PatternFileFullName))
                    patternFileResult = FindPatternWarningFile(contractFilesInfo, rootDirectory);

                if (!System.IO.File.Exists(patternFileResult.PatternFileFullName))
                    patternFileResult.NoPatternExportedYet = true;

                return patternFileResult;
            }
            catch
            {
                return new PatternFileResult { Error = true };
            }
        }

        public async Task<Result<Pattern>> AddIcon(Pattern pattern)
        {
            var contentResult = await GetPatternContent(pattern.EntityId);

            if (contentResult.IsFailure)
                return Result.Fail<Pattern, string>(PatternContentNotFoundErrorMessage);

            return Result.Try(() => pattern.SetIconContent(OptimizeImageSizeImageSharp(contentResult.Value.Content, 200)), e => e.Message)
                          .Bind(() => Result.Ok(pattern))
                          .OnFailure(x => Result.Fail(x));
        }

        private byte[] OptimizeImageSizeImageSharp(byte[] imageContent, int width, int height = 0, int quality = 70)
        {
            using (Stream contentStream = new MemoryStream(imageContent))
            {
                using (MemoryStream outStream = new MemoryStream())
                {
                    using (Image image = Image.Load(contentStream))
                    {
                        var _width = width;
                        var _height = height == 0 ? (image.Height * width / image.Width) : height;

                        image.Mutate(x => x.Resize(_width, _height));

                        var imageEncoder = new JpegEncoder();
                        imageEncoder.Quality = quality;

                        image.Save(outStream, imageEncoder);
                    }

                    return outStream.ToArray();
                }

            }
        }

        public async Task<Result<(string,byte[])>> GetLatestContractBy(string contractId)
        {
            Maybe<string> previousContractId = _innContractRepository.GetLatestContractIdBy(contractId);

            if (previousContractId.HasNoValue)
                return Result.Fail<(string,byte[])>("No previous contract found or no mapping");

            Maybe<Pattern> latestPattern =  await _patternRepository.GetByContractId(previousContractId.Value);

            if(latestPattern.HasNoValue)
                return Result.Fail<(string, byte[])>("no latest pattern in patterns");

            Maybe<byte[]> patternContent = await _patternStorageRepository.GetByIdRetMaybe("patterns", latestPattern.Value.EntityId);

            if(patternContent.HasNoValue)
                return Result.Fail<(string, byte[])>("no latest pattern content");

            return Result.Ok((previousContractId.Value, patternContent.Value));
        }

        public async Task<Result> AddNewPatternFromFile(string fileName, DateTime creationDate, byte[] content, string status)
        {
            Result<string> contractResult = _contractFinder.GetFromFile(fileName);
            Result<string> sha256Result = _cryptoHelper.GenSha256FromBytes(content);

            Result fileContractResult = Result.Combine(contractResult, sha256Result);

            //On Success
            Result result = await fileContractResult.Tap(async () =>
            {
                string contractId = contractResult.Value;
                string sha256Value = sha256Result.Value;
                string latinFileName = GetLatinFromCyrylic(fileName);

                Pattern pattern = Pattern.CreateNew(contractId, creationDate, fileName, latinFileName, sha256Value);
                pattern.SetIconContent(OptimizeImageSizeImageSharp(content, 200));
                pattern.SetStatus(status);

                await Result.Try(async () => await _patternStorageRepository.Add(_minioStorageConfiguration.Value.PatternBucket, sha256Value, content), (e) => e.Demystify().ToString())
                            .Tap(async () => { await _patternRepository.Create(pattern); });
            });

            return result;
        }

        public async Task<Result> AddMappingFile(byte[] mappingFileContent, string bucketName = "global", string key = "CONTRACTS_LS_INN.XLS")
        {            
            if(!IsValidExcelFile(mappingFileContent))
                return Result.Fail("Not Valid Excel File");

            bool isAdded = await _patternStorageRepository.Add(bucketName, key, mappingFileContent);
            if (!isAdded)
                return Result.Fail("Mappning can't ne added");

            return Result.Ok();
        }

        private bool IsValidExcelFile(byte[] mappingFileContent)
        {
            try
            {   using(var stream = new MemoryStream(mappingFileContent))
                using (var reader = ExcelReaderFactory.CreateReader(stream)) { };                
            }
            catch
            {
                return false;
            }
            return true;
        }

        public async Task<Result> AddNewConfirmedPatternFromFile(string fileName, DateTime creationDate, byte[] content) => await AddNewPatternFromFile(fileName, creationDate, content, PatternStatusEnum.Confirmed.ToString());

        public async Task<Result> AddNewUnConfirmedPatternFromFile(string fileName, DateTime creationDate, byte[] content) => await AddNewPatternFromFile(fileName, creationDate, content, PatternStatusEnum.Unconfirmed.ToString());

        public async Task UpdatePatternToUnconfirmed(Pattern pattern)
        {
            pattern.SetImportDate(DateTime.Now);
            pattern.SetStatus(PatternStatusEnum.Unconfirmed.ToString());
            await _patternRepository.Update(pattern);
        }

        public async Task UpdatePatternToUnconfirmedBy(string contractId)
        {
            Pattern pattern = await _patternRepository.GetByContractId(contractId);
            await UpdatePatternToUnconfirmed(pattern);
        }

        public async Task<bool> CheckIfPatternNotExistOrIsConfirmed(string contractId)
        {
            Maybe<Pattern> pattern = await _patternRepository.GetByContractId(contractId);
            if (pattern.HasNoValue)
                return true;

            return pattern.Value.IsConfirmed;
        }

        public async Task UpdatePatternStatus(string contractId, string status)
        {
            Maybe<Pattern> pattern = await _patternRepository.GetByContractId(contractId);
            if(pattern.HasValue)
            {
                pattern.Value.SetStatus(status);
                await _patternRepository.Update(pattern.Value);
            }
        }
    }
}
