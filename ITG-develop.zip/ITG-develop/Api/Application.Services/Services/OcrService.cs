﻿using CSharpFunctionalExtensions;
using System.Collections.Generic;
using System.Linq;
using Web.Api.Data.Repository;
using Web.Api.Domain.Dtos;


namespace Application.Services
{
    public class OcrService
    {
        public const string NipCyrylicValue = "ИНН";

        private readonly OcrRespository _ocrRespository;

        public OcrService(OcrRespository ocrRespository)
        {
            _ocrRespository = ocrRespository;
        }

        public Maybe<string> GetNip(string filePath)
        {
            List<TsvOcrRow> tsvOcrRows = _ocrRespository.GetFromFile(filePath);
            int nipIndex = tsvOcrRows.FindLastIndex(x => x.Text.Contains(NipCyrylicValue));

            if (nipIndex > 0)
            {
                TsvOcrRow firstNipResult = tsvOcrRows.ElementAt(nipIndex + 1);
                string text = firstNipResult.Text;
                if (!string.IsNullOrEmpty(text))
                {
                    return Maybe<string>.From(text);
                }                    
            }

            return Maybe<string>.None;
        }
    }
}
