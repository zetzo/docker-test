﻿using Application.Services.Configuration;
using CSharpFunctionalExtensions;
using Microsoft.Extensions.Options;
using NHibernate.Linq.ReWriters;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Dtos;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;

namespace Application.Services.Services
{
    public class PatternMatchingService
    {
        private const string PatternNotFoundErrorMessage = "Pattern Not Found";        
        private readonly IPatternRepository _patternRepository;
        private readonly IStorageRepository _patternStorageRepository;
        private readonly IOptions<MinioStorageConfiguration> _minioStorageConfiguration;
        private readonly IInnContractRepository _innContractRepository;
        private readonly IMatchingRulesRepository _matchingRulesRepository;

        public PatternMatchingService(
            IPatternRepository patternRepository,
            IStorageRepository patternStorageRepository,
            IOptions<MinioStorageConfiguration> minioStorageConfiguration,
            IInnContractRepository innContractRepository,
            IMatchingRulesRepository matchingRulesRepository
            )
        {
            _patternRepository = patternRepository;
            _patternStorageRepository = patternStorageRepository;
            _minioStorageConfiguration = minioStorageConfiguration;
            _innContractRepository = innContractRepository;
            _matchingRulesRepository = matchingRulesRepository;
        }

        public async Task<Result<byte[]>> GetPatternByContractId(string contractId)
        {
            Pattern pattern = await _patternRepository.GetByContractId(contractId);

            if (pattern != null && pattern.IsConfirmed)
            {
                return await GetPattern(pattern.EntityId);
            }
            else
            {
                Maybe<string> latestContractId = _innContractRepository.GetLatestContractIdBy(contractId);
                if (latestContractId.HasValue)
                {
                    pattern = await _patternRepository.GetByContractId(latestContractId.Value);
                    if (pattern != null && pattern.IsConfirmed)
                        return await GetPattern(pattern.EntityId);
                }
            }

            return Result.Fail<byte[]>(PatternNotFoundErrorMessage);
        }

        public async Task<Result<PatternDto>> GetPatternByContractIdNew(string contractId)
        {
            Pattern pattern = await _patternRepository.GetByContractId(contractId);
           
            if (pattern != null && pattern.IsConfirmed)
            {
                var patternContent = await GetPattern(pattern.EntityId);

                return Result.Create(patternContent.IsSuccess, PatternDto.Confirmed(patternContent.Value), PatternNotFoundErrorMessage);
            }
            else if(pattern != null && pattern.VendorHasNoStamp)
            {
                return Result.Create(true, PatternDto.VendorHasNoStamp(), PatternNotFoundErrorMessage);
            }
            else
            {
                Maybe<string> latestContractId = _innContractRepository.GetLatestContractIdBy(contractId);
                if(latestContractId.HasValue)
                {
                    pattern = await _patternRepository.GetByContractId(latestContractId.Value);
                    if (pattern != null && pattern.IsConfirmed)
                    {
                        var patternContent = await GetPattern(pattern.EntityId);
                        return Result.Create(patternContent.IsSuccess, PatternDto.Confirmed(patternContent.Value), PatternNotFoundErrorMessage);
                    }
                }
            }

            return Result.Fail<PatternDto>(PatternNotFoundErrorMessage);
        }

        private async Task<Result<byte[]>> GetPattern(string entityId)
        {
            Result<byte[]> patternContentResult =
                   await Result.Try(async () =>
                       await _patternStorageRepository.GetById(_minioStorageConfiguration.Value.PatternBucket, entityId), (e) => e.ToString());

            if (patternContentResult.IsSuccess)
                return Result.Ok(patternContentResult.Value);

            return Result.Fail<byte[]>(patternContentResult.Error);
        }

        public async Task<MatchingRule> GetMatchingRule(string contractId)
        {
            Maybe<MatchingRule> matchingRule = await _matchingRulesRepository.GetByMatchingRule(contractId);
            if(matchingRule.HasNoValue)
            {
                matchingRule = await _matchingRulesRepository.GetGlobalMatchingRule();
                if (matchingRule.HasNoValue)
                    return MatchingRule.Default;

                return matchingRule.Value;
            }
            return matchingRule.Value;
        }
    }
}
