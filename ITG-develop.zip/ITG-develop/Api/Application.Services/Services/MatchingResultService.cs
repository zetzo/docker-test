﻿using Application.Services.Extensions;
using Application.Services.Interfaces;
using CSharpFunctionalExtensions;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Paging;

namespace Application.Services.Services
{
    public class MatchingResultService : IMatchingResultService
    {
        private readonly IMatchingResultRepository _repository;
        public MatchingResultService(IMatchingResultRepository repository)
        {
            _repository = repository;
        }

        public async Task<Result<PagedResult<MatchingResult>>> GetPagedAsync(int pageIndex, int pageSize, string filterType, string filterContent)
        {
            Expression<Func<MatchingResult, bool>> predicate = PredicateBuilderExtensions.True<MatchingResult>();

            if (!string.IsNullOrEmpty(filterType) && !string.IsNullOrEmpty(filterContent))
            {
                switch (filterType)
                {
                    case "contractId":
                        Expression<Func<MatchingResult, bool>> contractIdEx = x => x.ContractId.ToLower().Contains(filterContent.ToLower());
                        predicate = predicate.And(contractIdEx);
                        break;
                    case "fileName":
                        Expression<Func<MatchingResult, bool>> fileNameEx = x => x.FileName.ToLower().Contains(filterContent.ToLower());
                        predicate = predicate.And(fileNameEx);
                        break;
                    default:
                        break;
                }
            }

            return await Result.Try(async () =>
                await _repository.GetPagedAsync(predicate, pageIndex, pageSize));
        }

        public async Task<IEnumerable<MatchingResult>> GetMatchingResultAsync()
        {
            return await _repository.GetMatchingResults();                        
        }

        public async Task<IEnumerable<MatchingResult>> GetMatchingResultByAsync(DateTime dateTime)
        {
            return await _repository.GetMatchingResultsBy(dateTime);
;        }

        public async Task<IEnumerable<MatchingResult>> GetMatchingResultByAsync(DateTime matchingDate, int hourFrom, int hourTo)
        {
            return await _repository.GetMatchingResultsBy(matchingDate, hourFrom, hourTo);
        }
    }
}
