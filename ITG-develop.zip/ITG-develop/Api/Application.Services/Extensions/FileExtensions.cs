﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Services.Extensions
{
    class FileExtensions
    {

    }

    public class FileExt
    {
        public static async Task CopyFileAsync(string sourceFile, string destinationFile, CancellationToken cancellationToken)
        {
            var fileOptions = FileOptions.Asynchronous | FileOptions.SequentialScan;
            var bufferSize = 4096;

            using (var sourceStream =
                  new FileStream(sourceFile, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize, fileOptions))

            using (var destinationStream =
                  new FileStream(destinationFile, FileMode.CreateNew, FileAccess.Write, FileShare.None, bufferSize, fileOptions))

                await sourceStream.CopyToAsync(destinationStream, bufferSize, cancellationToken)                                
                                           .ConfigureAwait(continueOnCapturedContext: false);            
        }
        public static async Task MoveFileAsync(string sourceFile, string destinationFile, bool deleteExistingFile, CancellationToken cancellationToken)
        {
            if (deleteExistingFile && File.Exists(destinationFile))
                File.Delete(destinationFile);

            var fileOptions = FileOptions.Asynchronous | FileOptions.SequentialScan;
            var bufferSize = 4096;

            using (var sourceStream =
                  new FileStream(sourceFile, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize, fileOptions))

            using (var destinationStream =
                  new FileStream(destinationFile, FileMode.CreateNew, FileAccess.Write, FileShare.None, bufferSize, fileOptions))

                await sourceStream.CopyToAsync(destinationStream, bufferSize, cancellationToken)
                                           .ConfigureAwait(continueOnCapturedContext: false);

            File.Delete(sourceFile);
        }
        public static async Task MoveFileAsync(string sourceFile, string destinationFile, CancellationToken cancellationToken)
        {           
            var fileOptions = FileOptions.Asynchronous | FileOptions.SequentialScan;
            var bufferSize = 4096;

            using (var sourceStream =
                  new FileStream(sourceFile, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize, fileOptions))

            using (var destinationStream =
                  new FileStream(destinationFile, FileMode.CreateNew, FileAccess.Write, FileShare.None, bufferSize, fileOptions))

                await sourceStream.CopyToAsync(destinationStream, bufferSize, cancellationToken)                    
                                           .ConfigureAwait(continueOnCapturedContext: false);

            File.Delete(sourceFile);
        }

        public static void DeleteIfExists(string sourceFile)
        {
            if (File.Exists(sourceFile))
                File.Delete(sourceFile);
        }
    }
}
