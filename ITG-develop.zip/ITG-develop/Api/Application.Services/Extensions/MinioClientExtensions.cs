﻿using IBM.Minio.ClientWrapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Minio;

namespace Application.Services.Extensions
{
    public static class MinioClientExtensions
    {
        public static void AddMinioWrapper(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped(sp => new MinioClient(configuration.GetSection("Minio:Endpoint").Value,
                                   configuration.GetSection("Minio:AccessKey").Value,
                                   configuration.GetSection("Minio:SecretKey").Value));

            services.AddScoped<MinioWrapper>();
        }

    }
}
