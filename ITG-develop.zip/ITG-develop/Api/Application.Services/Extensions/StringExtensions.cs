﻿using Application.Services.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Services.Extensions
{
    public static class StringExtensions
    {
        public static bool IsPdf(this string fileExtension)
        {
            return fileExtension == null ? false : fileExtension.Trim().ToLower().EndsWith("pdf");
        }
    }
}
