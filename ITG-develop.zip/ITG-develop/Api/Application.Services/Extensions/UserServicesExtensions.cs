﻿using Application.Services.Interfaces;
using Application.Services.Services;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Data.Repository;
using Web.Api.Domain.Interfaces;

namespace Application.Services.Extensions
{
    public static class UserServicesExtensions
    {
        public static void AddUserService(this IServiceCollection services)
        {
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IRoleRepository, RoleRepository>();
            services.AddScoped<IRoleService, RoleService>();
        }
    }
}
