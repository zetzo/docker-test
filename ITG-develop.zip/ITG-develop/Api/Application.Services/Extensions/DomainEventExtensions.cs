﻿using Application.Services.Interfaces;
using Application.Services.Services;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Data.EventHandlers;
using Web.Api.Data.Extensions;
using Web.Api.Data.Repository;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models.DomainEvent;

namespace Application.Services.Extensions
{
    public static class DomainEventExtensions
    {
        public static void AddDomainEventsService(this IServiceCollection services)
        {
            services.AddScoped<ILogEntryRepository, LogEntryRepository>();
            services.AddScoped<ILogEntryService, LogEntryService>();
            services.AddScoped<IDomainEventsPublisher, DomainEventsPublisher>();
        }
    }
}
