﻿using Application.Services.Interfaces;
using Application.Services.Services;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services.Extensions
{
    public static class ContractServiceExtensions
    {
        public static void AddContractService(this IServiceCollection services)
        {
            services.AddScoped<IRequestProvider, RequestProvider>();
            services.AddScoped<IContractService, ContractService>();
        }
    }
}
