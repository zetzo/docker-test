﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Application.Services.Extensions
{
    public static class DirectoryExt
    {
        public static void DeleteIfExists(string path, bool recursive = true)
        {
            if (Directory.Exists(path))
            {
                Directory.Delete(path, recursive);
            }
        }
    }
}
