﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Common;
using Web.Api.Domain.Models.DomainEvent;

namespace Application.Services.Extensions
{
    public static class ResultExtensions
    {
        public static Result MapResultOnCreation(this Result<Task> result, AggregateRoot item)
        {
            return result.Map(x => x.IsFaulted ? Result.CreateFailure<Task>(true, x, x.Exception.Message) : Result.Create<Task>(true, x, ""))
                              .Value
                              .OnSuccessTry((_) => item.AddDomainEventRelatedObjectIdWhenCreated((int)item.Id))
                              .OnFailure((_) => item.ChangeDomainEventActionResult(ActionResultEnum.PublishedFailed));
        }

        public static Result MapResultOnUpdate(this Result<Task> result, AggregateRoot item)
        {
            return result.Map(x => x.IsFaulted ? Result.CreateFailure<Task>(true, x, x.Exception.Message) : Result.Create<Task>(true, x, ""))
                  .Value
                  .OnFailure((_) => item.ChangeDomainEventActionResult(ActionResultEnum.PublishedFailed));
        }

        public static Result MapResultOnDelete(this Result<Task> result, AggregateRoot item)
        {
            return result.Map(x => x.IsFaulted ? Result.CreateFailure<Task>(true, x, x.Exception.Message) : Result.Create<Task>(true, x, ""))
                  .Value
                  .OnFailure((_) => item.ChangeDomainEventActionResult(ActionResultEnum.PublishedFailed));
        }
    }
}
