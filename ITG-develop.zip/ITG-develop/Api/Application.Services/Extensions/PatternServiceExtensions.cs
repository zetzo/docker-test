﻿using Application.Services.Interfaces;
using Application.Services.Services;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Data.Common;
using Web.Api.Data.Repository;
using Web.Api.Domain.Interfaces;

namespace Application.Services.Extensions
{
    public static class PatternServiceExtensions
    {
        public static void AddPatternService(this IServiceCollection services)
        {
            services.AddSingleton<ContractFinder>();
            services.AddSingleton<CryptoHelper>();
            services.AddScoped<IPatternRepository, PatternRepository>();
            services.AddScoped<IStorageRepository, StorageRepository>();
            services.AddScoped<IPatternService, PatternService>();
        }
        public static void AddMatchingService(this IServiceCollection services)
        {
            services.AddScoped<IMatchingResultService, MatchingResultService>();
            services.AddScoped<IMatchingResultRepository, MatchingResultRepository>();

            services.AddScoped<IPatternActionService, PatternActionService>();
        }
    }
}
