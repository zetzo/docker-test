﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Services.Extensions
{
    public static class DictionaryExtensions
    {
        public static TValue GetByKeyOrUseDefaultKey<TKey, TValue>
            (this IDictionary<TKey, TValue> dictionary, TKey key, TKey defaultKey)
        {
            TValue value;
            return dictionary.TryGetValue(key, out value) ? value : dictionary[defaultKey];
        }
    }
}
