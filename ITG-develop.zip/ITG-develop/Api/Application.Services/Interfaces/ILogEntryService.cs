﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models.DomainEvent;
using Web.Api.Domain.Models.Paging;

namespace Application.Services.Interfaces
{
    public interface ILogEntryService
    {
        Task<Result<PagedResult<LogEntry>>> GetPagedAsync(int pageIndex, int pageSize);
    }
}
