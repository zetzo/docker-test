﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models.PatternActions;
using PatternSourceFolderStructure = Web.Api.Domain.Models.PatternActions.PatternSourceFolderStructure;

namespace Application.Services.Interfaces
{
    public interface IPatternActionService
    {
        Result<PatternSourceFolderStructure> GetFolderStructure(string contractId);
        Result<IEnumerable<FileElement>> GetEntireFolderStructure();
        Task<byte[]> GetFileContent(string path, bool withCompression);
    }
}
