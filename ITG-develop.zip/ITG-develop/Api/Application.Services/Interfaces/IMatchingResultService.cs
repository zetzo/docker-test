﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Paging;

namespace Application.Services.Interfaces
{
    public interface IMatchingResultService
    {
        Task<Result<PagedResult<MatchingResult>>> GetPagedAsync(int pageIndex, int pageSize, string filterType, string filterContent);
        Task<IEnumerable<MatchingResult>> GetMatchingResultAsync();
        Task<IEnumerable<MatchingResult>> GetMatchingResultByAsync(DateTime date);
        Task<IEnumerable<MatchingResult>> GetMatchingResultByAsync(DateTime date, int hourFrom, int hourTo);
    }
}
