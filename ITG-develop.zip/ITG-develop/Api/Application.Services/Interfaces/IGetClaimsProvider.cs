﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Models.Roles;

namespace Application.Services.Interfaces
{
    public interface IGetClaimsProvider
    {
        string UserId { get; }
        IEnumerable<Permissions> Permissions { get; }
    }
}