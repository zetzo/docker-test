﻿using Application.Services.ViewModels;
using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services.Interfaces
{
    public interface IContractService
    {
        Task<Result<ContractImagesResponse>> SplitPdfIntoImages(ContractPdfRequest contract);
        string CutOutContractCodeFromFileName(string fileName);
    }
}
