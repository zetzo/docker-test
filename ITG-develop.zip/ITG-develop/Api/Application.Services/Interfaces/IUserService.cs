﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Roles;

namespace Application.Services.Interfaces
{
    public interface IUserService
    {
        Task<User> Authenticate(string username, string password);
        Task<User> Create(User user, string password);
        Task<User> CreateIbmIdUser(string username, string firstname, string lastname);
        Task<Result<IEnumerable<User>>> GetAll();
        Task<Result<User>> GetByUsername(string username);
        Task<Result<User>> GetById(int id);
        Task<Result> Update(User user, string username, string firstname, string lastname, IEnumerable<Role> roles, bool isAdmin, bool isConfirmed, string settings, int userId);
        string GenerateUserToken(User user);
        User DebugMode();
    }
}
