﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Application.Services.Interfaces
{
    public interface IInfoService
    {
        Task<Result<IEnumerable<VersionInfo>>> GetLatestVersionInfo(int number);
        Task<Result<IEnumerable<MessageForUsers>>> GetLatestUserMessages(int number);
        Task CreateUserMessage(MessageForUsers message);
    }
}
