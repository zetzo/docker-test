﻿using Application.Services.ViewModels;
using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Paging;
using Web.Api.Domain.Models.PatternActions;
using static Application.Services.ContractFinder;

namespace Application.Services.Interfaces
{
    public interface IPatternService
    {
        Task<Result> AddNewPattern(Pattern pattern, string patternContent, int userId);
        Task<Result> AddNewPattern(string fileName, string description, byte[] content, string contractId, int userId, string inn = "");        
        Task<Result> AddNewPatternContent(string key, string content);
        Task<Result> AddNewPatternFromFile(string fileName, DateTime creationDate, byte[] content);
        Task<Result> AddNewPatternFromFile(string fileName, DateTime creationDate, byte[] content, string status);
        Task<Result> AddNewConfirmedPatternFromFile(string fileName, DateTime creationDate, byte[] content);
        Task<Result> AddNewUnConfirmedPatternFromFile(string fileName, DateTime creationDate, byte[] content);

        Task<Result> AddNewPatternFromFile(string fileName, DateTime creationDate, byte[] content, bool isWarningFile);
        Task<Result> DeletePattern(string entityId, int userId);
        Task<Result> DeletePatternContent(string entityId);        
        Task<IEnumerable<Pattern>> GetAll();
        Task<IEnumerable<PatternContent>> GetMultiplePatternContent(string[] sha256Keys);
        Task<PagedResult<Pattern>> GetPagedAsync(int pageIndex, int pageSize);
        Task<PagedResult<Pattern>> GetPagedAsync(int pageIndex, int pageSize, List<FilterModel> filters);

        Task<Result<Pattern>> AddIcon(Pattern pattern);
        Task<Result<Pattern>> GetPatternById(long id);       
        Task<Result<PatternContentResult>> GetPatternContent(string sha256);
        Task<Result> UpdatePattern(Pattern pattern, string contractId, string inn, string description, string entityId, string importFileName, 
            string imageData, string status, int userId);
        Task<Result> UpdatePattern(Pattern pattern, int userId);
        Task<Result> UpdatePatternContent(string entityId, byte[] content);
        Task<Result<string>> GetContractIdFromFile(string fileName); 
        
        string GetLatinFromCyrylic(string value);
        Result<ContractFinderResult> GetContractResultFromDocumentFile(string fileName, int wherePageCountBiggerThen = 4);
        Task UpdatePatternStatus(string contractId, string status);
        Task<Result<IEnumerable<PatternImageRefitted>>> CropImage(IEnumerable<long> patternIds);
        Task<Result<IEnumerable<PatternImageRefitted>>> AdjustContrast(IEnumerable<long> patternIds);
        Task<bool> CheckIfPatternExistsInDb(string sha2);
        Task<Result> UpdatePatternByContractId(string contractId, string importFileName, DateTime creationDate, byte[] content);
        Task<Result> UpdatePatternByContractIdSetImport48HoursOld(string contractId, string importFileName, DateTime creationDate, byte[] content);
        Task<Maybe<Pattern>> GetPatternByContractId(string contractId);
        Task<Result> UpdatePatternByContractId(string value, string patternFile, DateTime creationDate, byte[] fileContent, bool isWarningFile);
        Task<Result<(string, byte[])>> GetLatestContractBy(string contractId);
        PatternFileResult FindCorrectPatternFile(FileInfo[] contractFilesInfo, string rootDirectory);
        PatternFileResult FindPatternWarningFile(FileInfo[] contractFilesInfo, string rootDirectory);
        Task<Result> AddMappingFile(byte[] mappingFileContent, string bucketName, string key);
        PatternFileResult FindPatternFile(FileInfo[] contractFilesInfo, string rootDirectory);
        Task UpdatePatternToUnconfirmed(Pattern pattern);
        Task UpdatePatternToUnconfirmedBy(string contractId);

        Task<bool> CheckIfPatternNotExistOrIsConfirmed(string contractId);
    }
}
