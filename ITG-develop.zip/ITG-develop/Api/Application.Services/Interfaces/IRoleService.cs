﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models.Roles;

namespace Application.Services.Interfaces
{
    public interface IRoleService
    {
        Task<Result> Create(Role role, int userId);
        Task<Result> Update(Role role, string name, string desc, IEnumerable<Permissions> permissions, bool isActive, int userId);
        Task<Result<IEnumerable<Role>>> GetAll();
        Task<Result<Role>> Get(int id);
    }
}
