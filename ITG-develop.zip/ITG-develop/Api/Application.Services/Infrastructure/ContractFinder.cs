﻿using Application.Services.Extensions;
using CSharpFunctionalExtensions;
using NickBuhro.Translit;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace Application.Services
{
    public sealed class ContractFinder
    {
        public const string WrongNamingConventionErrorMessage = "error in file naming convention";
        public const string FilePartCannotBeParsedErrorMessage = "file part cannot be parsed";
        public const string ContractIdRegex = "^([a-zA-Z]{2})-([0-9]+)$";
        public const string Dogowor = "Договор";
        public const char ContractIdPrefix = '-';
        public const int BiggerThenAddendumCount = 4;

        public Result<string> GetFromFile(string fileName)
        {
            string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(fileName);

            fileNameWithoutExtension = fileNameWithoutExtension.Replace(")", string.Empty).Replace("(",string.Empty);

            if (fileNameWithoutExtension.Contains(ContractIdPrefix))
            {
                int contractStartIndex = FindCorrectIndex(fileNameWithoutExtension);

                if (contractStartIndex != -1)
                {
                    string contractIdWithRestOfFileName = fileNameWithoutExtension.Substring(contractStartIndex, fileNameWithoutExtension.Length - contractStartIndex);
                    string contractIdWithRestOfFileNameNoPrefix = contractIdWithRestOfFileName.Substring(3, contractIdWithRestOfFileName.Length - 3);
                    string twoLetterPrefix = contractIdWithRestOfFileName.Substring(0, 2);
                    string contractId = GetContractIdFromFilePart(contractIdWithRestOfFileNameNoPrefix);
                    string twoLetterPrefixInLatin = GetLatinFromCyrylic(twoLetterPrefix);
                    return Result.Ok<string>($"{twoLetterPrefixInLatin}-{contractId}");
                }
            }

            return Result.Fail<string>(WrongNamingConventionErrorMessage);
        }

        public Result<string> GetFromFileWithExceptionName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
                return Result.Fail<string>("Error in file name");

            string[] fileParts = fileName.Split('_');
            if (fileParts.Length == 2)
            {
                List<char> digits = new List<char>();
                foreach(char @char in fileParts[1])
                {
                    if (!char.IsDigit(@char))
                        break;

                    digits.Add(@char);
                }

                return Result.Ok(new string(digits.ToArray()));
            }

            return Result.Fail<string>("Error in file name");
        }

        public Result<string> GenContractGroup(string fileName)
        {
            Result<string> contractIdResult = GetFromFile(fileName);
            if (contractIdResult.IsSuccess)
            {
                string contractId = contractIdResult.Value;
                string[] contractIdParts = contractId.Split('-');
                if (contractIdParts.Length == 2)
                {
                    string iterator = contractIdParts[1];

                    bool isNumber = int.TryParse(iterator, out int serial);
                    if (isNumber)
                    {
                        decimal group = Math.Floor(((decimal)serial) / 1000) + 1;
                        string groupFolder = group.ToString();
                        return Result.Ok(groupFolder);
                    }
                    else
                    {
                        return Result.Fail<string>("Part after - is not a number");
                    }
                }
                else
                {
                    return Result.Fail<string>("ContractId doesn't contain 2 parts");
                }
            }

            return contractIdResult;
        }
        public int FindCorrectIndex(string fileNameWithoutExtension)
        {
            int contractStartIndex = fileNameWithoutExtension.IndexOf(ContractIdPrefix);

            for (int i = contractStartIndex; i < fileNameWithoutExtension.Length; i++)
            {
                char currentChar = fileNameWithoutExtension[i];
                if (currentChar == '_' || currentChar == ' ')
                {
                    //_LS nie moze wychodzi poza dlugosc nazwy pliku
                    if (i + 4 < fileNameWithoutExtension.Length)
                    {
                        char possibleHyphen = fileNameWithoutExtension[i + 3];
                        if (possibleHyphen == '-')
                        {
                            char possibleDigit = fileNameWithoutExtension[i + 4];
                            if (char.IsDigit(possibleDigit))
                            {
                                return i + 1;
                            }
                        }
                    }
                }
                else if (currentChar == '-')
                {
                    int minStartingIndexOfContractId = i - 3;
                    int minLengthOfContractId = 4;

                    if (minStartingIndexOfContractId >= 0)
                    {
                        char possibleUnderlineORWhiteSpace = fileNameWithoutExtension[minStartingIndexOfContractId];
                        if (possibleUnderlineORWhiteSpace == '_' || possibleUnderlineORWhiteSpace == ' ')
                        {
                            if (fileNameWithoutExtension.Length - ((minStartingIndexOfContractId + 1) + minLengthOfContractId) > 0)
                            {
                                string possibleContractId = fileNameWithoutExtension.Substring(minStartingIndexOfContractId + 1, minLengthOfContractId);

                                bool isValidContractId = Regex.IsMatch(GetLatinFromCyrylic(possibleContractId), ContractIdRegex);
                                if (isValidContractId)
                                    return i - 2;
                            }
                        }
                    }
                }
            }

            return -1;
        }

        public Result<string> GetFromClosingDocument(string fullFileName)
        {
            string latinFullName = GetLatinFromCyrylic(fullFileName);

            string latinFileName = Path.GetFileNameWithoutExtension(latinFullName);

            int indeoxOf_ = latinFileName.LastIndexOf('_');

            char[] parts = latinFileName.ToCharArray();
            List<char> chars = new List<char>();

            for (int i = indeoxOf_ - 1; i > 0; i--)
            {
                if (parts[i] == '_')
                    break;

                chars.Add(parts[i]);
            }

            chars.Reverse();

            return Result.Ok(new string(chars.ToArray()));
        }

        private string GetContractIdFromFilePart(string value)
        {
            List<char> numbers = new List<char>();

            foreach (char @char in value)
            {
                if (!char.IsDigit(@char))
                    break;

                numbers.Add(@char);
            }

            return new string(numbers.ToArray());
        }

        public string GetLatinFromCyrylic(string cyrylic)
        {
            return Transliteration.CyrillicToLatin(cyrylic, Language.Russian);
        }

        public int GetSpecificPageFromClosingDocument(int pageCount)
        {
            if (pageCount == 1)
                return 0;            
            else
                return 1;
        }

        public int GetSpecificPageFromContract(int pageCount)
        {
            if (pageCount >=8)
                return 4;
            if (pageCount >= 5 && pageCount <= 7)
                return 3;
            else
                return pageCount;
        }

        public class ContractFinderResult
        {
            public string ContractId { get; set; }
        }
    }
}
