﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Services.Exceptions
{
    public static class ExceptionExtensions
    {
        public static string Dump(this Exception e)
        {
            return DumpException(e);
        }

        private static string DumpException(Exception e)
        {
            string error = string.Empty;

            error += string.Format("Message {0} -> StackTrace {1} ", e.Message, e.StackTrace);
            error += Environment.NewLine;

            if (e.InnerException != null)
                error += DumpException(e.InnerException);

            return error;
        }
    }
}
