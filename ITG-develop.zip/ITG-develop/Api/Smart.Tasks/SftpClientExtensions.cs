﻿using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Smart.Tasks
{
    public static class SftpClientExtensions
    {
        public static void DownloadFile(this SftpClient sftpClient, string path, string outPath, bool releaseHandle, Action<ulong> downloadCallback = null)
        {
            if (releaseHandle)
            {
                using (FileStream fsdownload = new FileStream(outPath, FileMode.Create, FileAccess.Write))
                {
                    sftpClient.DownloadFile(path, fsdownload, downloadCallback);
                }
            }
        }

        public static void UploadFile(this SftpClient sftpClient, string path, string outPath, bool canOverride, Action<ulong> uploaddCallback = null)
        {
            using (FileStream fsupload = new FileStream(path, FileMode.Open, FileAccess.Read))
            {
                sftpClient.UploadFile(fsupload, outPath, canOverride, uploaddCallback);
            }
        }
    }
}
