﻿using IBM.NetCore.Coravel;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Linq;
using Smart.Tasks.Model;
using Web.Api.Domain.Interfaces;
using Application.Services;
using MoreLinq;
using ExcelDataReader;
using Microsoft.Extensions.Options;
using Application.Services.Configuration;
using Application.Services.Extensions;

namespace Smart.Tasks
{
    public class LoadInn2ContractMapTask : InvocableBase<LoadInn2ContractMapTask>
    {
        private IInnContractPairRepository _innContractPairRepository;
        private readonly IOptions<LoadInn2ContractMapConfiguration> _loadInn2ContractMapConfiguration;
        
        private readonly ContractFinder _contractFinder;        
        public LoadInn2ContractMapTask(ILogger<LoadInn2ContractMapTask> logger, IOptions<LoadInn2ContractMapConfiguration> loadInn2ContractMapConfiguration, IInnContractPairRepository innContractPairRepository,
            ContractFinder contractFinder) : base(logger)
        {
            _loadInn2ContractMapConfiguration = loadInn2ContractMapConfiguration;
            _innContractPairRepository = innContractPairRepository;           
            _contractFinder = contractFinder;
        }

        protected override async Task ExecuteAsync()
        {
            _logger.LogInformation("LoadInn2ContractMapTask - Started");
            await LoadInnContracts();
            _logger.LogInformation("LoadInn2ContractMapTask - Ended");
        }

        private async Task LoadInnContracts()
        {            
            List<InnContractIdPair> innContractPairs = new List<InnContractIdPair>();

            var mappingFileInfo =  new DirectoryInfo(_loadInn2ContractMapConfiguration.Value.MapFilePath).GetFiles().Where(x => x.Name.ToLower().EndsWith("xls") || x.Name.ToLower().EndsWith("xlsx")).FirstOrDefault();
            
            if (mappingFileInfo!=null)
            {
                _logger.LogInformation("Loading from EXCEL file");

                using (FileStream memoryStream = new FileStream(mappingFileInfo.FullName, FileMode.Open, FileAccess.Read))
                {
                    try
                    {
                        using (var reader = ExcelReaderFactory.CreateReader(memoryStream))
                        {
                            // Choose one of either 1 or 2:
                            var data = reader.AsDataSet(new ExcelDataSetConfiguration
                            {
                                ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                                {
                                    UseHeaderRow = false,
                                },
                            });

                            do
                            {                                
                                while (reader.Read())
                                {
                                    string contractId = reader[0]?.ToString().Trim();
                                    string inn = reader[1]?.ToString().Trim();                                    

                                    if (!string.IsNullOrEmpty(contractId) && !string.IsNullOrEmpty(inn))
                                    {                                        
                                        var innContractPair = new InnContractIdPair { ContractId = _contractFinder.GetLatinFromCyrylic(contractId), Inn = inn };
                                        innContractPairs.Add(innContractPair);
                                    }
                                }                                
                            } while (reader.NextResult());
                        }
                    }
                    catch (Exception e)
                    {
                        _logger.LogError(e, e.Message);
                    }
                }

                var filteredList = innContractPairs.DistinctBy(x => x.ContractId).Skip(1).ToList();
                _logger.LogInformation("Deleteing old mappings");

                _innContractPairRepository.DeleteAll();

                _logger.LogInformation("Inserting new mappings");
                await _innContractPairRepository.InsertAll(filteredList);
                _innContractPairRepository.ExecuteMerging();

                _logger.LogInformation("Deleting mapping file");
                FileExt.DeleteIfExists(mappingFileInfo.FullName);                
            }          
        }      
    }
}
