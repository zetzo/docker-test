﻿using IBM.NetCore.Coravel;
using Microsoft.Extensions.Logging;
using Renci.SshNet;
using System;
using System.Threading.Tasks;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using Application.Services;
using Application.Services.Configuration;
using Microsoft.Extensions.Options;
using Application.Services.Extensions;
using System.Threading;

namespace Smart.Tasks
{
    public class SftpDownloaderTask : InvocableBase<SftpDownloaderTask>
    {
        private readonly IOptions<SftpDownloaderTaskConfiguration> _sftpDownloaderTaskConfiguration;

        public SftpDownloaderTask(IOptions<SftpDownloaderTaskConfiguration> sftpDownloaderTaskConfiguration, ILogger<SftpDownloaderTask> logger) : base(logger)
        {
            _sftpDownloaderTaskConfiguration = sftpDownloaderTaskConfiguration;
            _logger.LogDebugDetail("Ctor");
        }

        protected override async Task ExecuteAsync()
        {
            _logger.LogInformation("SftpDownloaderTask - Started");

            try
            {
                var sshClient = new SftpClient(_sftpDownloaderTaskConfiguration.Value.HostName, _sftpDownloaderTaskConfiguration.Value.UserName,
                    new PrivateKeyFile(_sftpDownloaderTaskConfiguration.Value.PrivateKey, _sftpDownloaderTaskConfiguration.Value.Password));

                sshClient.Connect();

                var files = sshClient.ListDirectory(_sftpDownloaderTaskConfiguration.Value.InboundFolderPath).Where(x => x.IsRegularFile && x.Name.EndsWith(_sftpDownloaderTaskConfiguration.Value.EndsWith, StringComparison.OrdinalIgnoreCase));

                _logger.LogInformation($"SFTP files count: {files.Count()}");

                Queue<DownloadFileItem> downloadQueue = new Queue<DownloadFileItem>();

                foreach (var file in files)
                {
                    string destinationFileName = Path.ChangeExtension(file.Name.ToUpper(), "PART");

                    string destinationFullFileName = Path.Combine(_sftpDownloaderTaskConfiguration.Value.DocumentsToImportPath, destinationFileName);

                    sshClient.DownloadFile(file.FullName, destinationFullFileName, true);
                    _logger.LogInformation($"Downloading: { destinationFullFileName }");
                    downloadQueue.Enqueue(new DownloadFileItem { Source = file.FullName, Destination = destinationFullFileName });
                }

                while (downloadQueue.Count > 0)
                {
                    DownloadFileItem downloadFileItem = downloadQueue.Dequeue();
                    sshClient.Delete(downloadFileItem.Source);
                    _logger.LogInformation($"Deleting: {downloadFileItem.Source}");

                    string newFileName = Path.ChangeExtension(downloadFileItem.Destination, _sftpDownloaderTaskConfiguration.Value.EndsWith);

                    _logger.LogInformation($"Changing: {downloadFileItem.Destination} to {newFileName}");
                    await FileExt.MoveFileAsync(downloadFileItem.Destination, newFileName, true, CancellationToken.None);
                }

                sshClient.Disconnect();
            }
            catch (Exception e)
            {
                _logger.LogErrorDetail(e);
            }
            _logger.LogInformation("SftpDownloaderTask - Ended");

            await Task.CompletedTask;
        }

        private class DownloadFileItem
        {
            public string Source { get; set; }
            public string Destination { get; set; }
        }
    }
}