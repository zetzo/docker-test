﻿using MicroOrm.Dapper.Repositories.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Smart.Tasks.Model
{        
    [Table("smart.inn_contract_map_latest")]
    public class InnContractIdPair
    {   
        [Column("contract_Id")]
        public string ContractId { get; set; }

        public string Inn { get; set; }

        internal static InnContractIdPair CreateNew(InnContractIdPair item, int index)
        {
            return new InnContractIdPair
            {                
                ContractId = item.ContractId,
                Inn = item.Inn
            };
        }
    }
}
