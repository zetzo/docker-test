﻿using Smart.Tasks.Model;
using MicroOrm.Dapper.Repositories;
using System.Data;
using System.Collections.Generic;
using System.Threading.Tasks;
using CsvHelper;

namespace Smart.Tasks
{
    public class InnContractPairRepository : DapperRepository<InnContractIdPair>, IInnContractPairRepository
    {        
        public InnContractPairRepository(IDbConnection connection)
                   : base(connection)
        {

        }

        public async Task<bool> Contains(string contractId)
        {
            var value = await CountAsync(x => x.ContractId);

            return value > 0;
        }

        public void DeleteAll()
        {            
            if (Connection.State != ConnectionState.Open)
                Connection.Open();

            var command = Connection.CreateCommand();
            command.CommandText = "delete from smart.inn_contract_map_latest";
            command.ExecuteNonQuery();
        }
       
        public void ExecuteMerging()
        {
            if (Connection.State != ConnectionState.Open)
                Connection.Open();

            var command = Connection.CreateCommand();
            command.CommandText = "call update_mappings()";
            command.ExecuteNonQuery();
        }

        public async Task InsertAll(IEnumerable<InnContractIdPair> innContractIdPairs)
        {
            await BulkInsertAsync(innContractIdPairs);
        }

        public async Task Add(InnContractIdPair innContractIdPair)
        {
            await InsertAsync(innContractIdPair);
        }
    }

    public interface IInnContractPairRepository
    {
        Task InsertAll(IEnumerable<InnContractIdPair> innContractIdPairs);
        Task Add(InnContractIdPair innContractIdPair);
        void DeleteAll();
        void ExecuteMerging();
        Task<bool> Contains(string contractId);        
    }
}
