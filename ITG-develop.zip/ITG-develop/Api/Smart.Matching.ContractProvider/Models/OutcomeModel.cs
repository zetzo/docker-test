﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smart.Matching.ContractProvider.Models
{
    [Table("smart.matching_outcome")]
    public class OutcomeModel
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("date_created")]
        public DateTime DateCreated { get; set; }
        [Column("contract_id")]
        public string ContractId { get; set; }
        [Column("file_name")]
        public string FileName { get; set; }
        [Column("score")]
        public int Score { get; set; }
    }
}
