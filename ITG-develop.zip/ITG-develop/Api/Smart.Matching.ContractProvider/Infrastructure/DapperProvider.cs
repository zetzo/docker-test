﻿using Dapper;
using Npgsql;
using Smart.Matching.ContractProvider.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Smart.Matching.ContractProvider.Infrastructure
{
    public class DapperProvider
    {
        private readonly string _connectionString;

        public DapperProvider(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task Insert(OutcomeModel outcome)
        {
            var resolver = new TableNameResolver();
            SimpleCRUD.SetTableNameResolver(resolver);
            SimpleCRUD.SetDialect(SimpleCRUD.Dialect.PostgreSQL);

            using (var connection = new NpgsqlConnection(_connectionString))
            {
                await connection.InsertAsync<int, OutcomeModel>(outcome);
            };
        }
    }
}
