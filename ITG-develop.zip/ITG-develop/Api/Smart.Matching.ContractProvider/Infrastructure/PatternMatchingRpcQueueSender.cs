﻿using IBM.NetCore.RabbitMQ;
using IBM.NetCore.RabbitMQ.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace Smart.Matching.ContractProvider.Infrastructure
{
    public sealed class PatternMatchingRpcQueueSender : RpcQueueSender
    {
        public PatternMatchingRpcQueueSender(IRabbitMQPersistentConnection persistentConnection, ILogger<RpcQueueSender> logger, IOptions<RabbitSettings> rabbitSettings) : base(persistentConnection, logger, rabbitSettings)
        {

        }
    }

    public sealed class PatternMatchingRabbitMQPersistentConnection : DefaultRabbitMQPersistentConnection
    {
        public PatternMatchingRabbitMQPersistentConnection(IConnectionFactory connectionFactory, ILogger<DefaultRabbitMQPersistentConnection> logger) : base(connectionFactory, logger)
        {

        }
    }

    public sealed class PatternMatchingRabbitSettings : RabbitSettings
    {

    }
}
