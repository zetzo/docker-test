﻿using System;
using System.Collections.Generic;
using System.Text;
using static Dapper.SimpleCRUD;

namespace Smart.Matching.ContractProvider.Infrastructure
{
    public class TableNameResolver : ITableNameResolver
    {
        public string ResolveTableName(Type type)
        {
            return $"smart.matching_outcome";
        }
    }
}
