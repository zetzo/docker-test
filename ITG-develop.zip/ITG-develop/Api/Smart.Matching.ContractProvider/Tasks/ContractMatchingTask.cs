﻿using Application.Services;
using Application.Services.Configuration;
using Application.Services.Extensions;
using Application.Services.Helpers;
using Application.Services.Services;
using Capturify.Api;
using CSharpFunctionalExtensions;
using IBM.NetCore.Coravel;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Smart.Matching.ContractProvider.Infrastructure;
using Smart.Matching.ContractProvider.Models;
using Smart.Matching.DocumentProvider.Chains;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Smart.Matching.ContractProvider.Tasks
{
    internal class ContractMatchingTask : InvocableBase<ContractMatchingTask>
    {
        private readonly ContractFinder _contractFinder;
        private readonly IOptions<ContractMatchingTaskConfiguration> _contractMatchingTaskConfiguration;
        private readonly PatternMatchingService _patternMatchingService;
        private readonly IMatchingServiceClient _matchingServiceClient;
        private readonly DapperProvider _dapperProvider;
        private readonly MatchingHandler _matchingHandler;
        private readonly SyncClient _syncClient;

        public ContractMatchingTask(ILogger<ContractMatchingTask> logger, IMatchingServiceClient matchingServiceClient, ContractFinder contractFinder, IOptions<ContractMatchingTaskConfiguration> sendToMatchingTaskConfiguration,
            PatternMatchingService patternMatchingService, DapperProvider dapperProvider, SyncClient syncClient) : base(logger)
        {
            _contractFinder = contractFinder;
            _matchingServiceClient = matchingServiceClient;
            _contractMatchingTaskConfiguration = sendToMatchingTaskConfiguration;
            _patternMatchingService = patternMatchingService;
            _dapperProvider = dapperProvider;
            _syncClient = syncClient;

            _matchingHandler = new RawMatchingHandler(matchingServiceClient);
            _matchingHandler.AddNext(new RightAutoGammaMatchingHandler(matchingServiceClient));
            _matchingHandler.AddNext(new BothAutoGammaMatchingHandler(matchingServiceClient));
        }

        private byte[] GetBytesFromPDF(string fullFileName, int pageToTake)
        {
            var fileContent = File.ReadAllBytes(fullFileName);

            _syncClient.CutPdf(null, fileContent, pageToTake);

            if (_syncClient.Result.Status != "Error")
            {
                byte[] imageResulInBytes = _syncClient.Result.Result.Pages.First().Content;

                return imageResulInBytes;
            }

            return new byte[0];
        }

        protected async Task<ContractDocumentValidationResult> ValidateClosingDocument(FileInfo closingDocumentFile)
        {
            var pdfMetaData = PdfHelper.Instance.ReadMetadaFromFile(closingDocumentFile.FullName);

            if (pdfMetaData.IsFailure)
                return ContractDocumentValidationResult.NotPdf;

            Result<string> contractResult = _contractFinder.GetFromFile(closingDocumentFile.Name);

            if (contractResult.IsFailure)
                return ContractDocumentValidationResult.WrongFileName;

            _logger.LogInformation($"Contract found: {contractResult.Value}");

            Result<byte[]> patternContentResult = await _patternMatchingService.GetPatternByContractId(contractResult.Value);

            if (patternContentResult.IsFailure)
                return ContractDocumentValidationResult.ContractNotFound;

            return ContractDocumentValidationResult.Success(contractResult.Value, patternContentResult.Value, pdfMetaData.Value.PagesCount);
        }

        protected override async Task ExecuteAsync()
        {
            _logger.LogInformation("ContractMatchingTask - Started");

            foreach (var closingDocumentFile in new DirectoryInfo(_contractMatchingTaskConfiguration.Value.ContractsSourcePath).GetFiles().Take(_contractMatchingTaskConfiguration.Value.ImportBatchSize))
            {
                _logger.LogInformation($"Processing {closingDocumentFile.FullName}");

                ContractDocumentValidationResult closingDocumentValidationResult = await ValidateClosingDocument(closingDocumentFile);

                string destinationFilePath = Path.Combine(_contractMatchingTaskConfiguration.Value.ContractsUnMatchedPath, closingDocumentFile.Name);

                if (closingDocumentValidationResult.IsSuccess)
                {
                    var matchingRule = await _patternMatchingService.GetMatchingRule(closingDocumentValidationResult.ContractId);

                    int expectedPage = _contractFinder.GetSpecificPageFromContract(closingDocumentValidationResult.PageCount);

                    _logger.LogInformation($"taking {expectedPage} page");

                    byte[] closingDocumentContent = GetBytesFromPDF(closingDocumentFile.FullName, expectedPage);

                    int score = _matchingHandler.Handle(-1, MatchingPayload.Create(closingDocumentValidationResult.PatternContent, closingDocumentContent, closingDocumentValidationResult.ContractId, closingDocumentFile.Name));

                    _logger.LogInformation($"score is {score}");

                    if (score >= matchingRule.Matched)
                    {
                        destinationFilePath = Path.Combine(_contractMatchingTaskConfiguration.Value.ContractsMatchedPath, closingDocumentFile.Name);

                    }
                    else if (score > matchingRule.UnMatched && score < matchingRule.Matched)
                    {
                        destinationFilePath = Path.Combine(_contractMatchingTaskConfiguration.Value.ContractsAmbiguousPath, closingDocumentFile.Name);
                    }

                    await _dapperProvider.Insert(new OutcomeModel
                    {
                        ContractId = closingDocumentValidationResult.ContractId,
                        DateCreated = DateTime.Now,
                        FileName = closingDocumentFile.Name,
                        Score = score
                    });

                    await FileExt.MoveFileAsync(closingDocumentFile.FullName, destinationFilePath, true, CancellationToken.None);
                }
                else
                {
                    destinationFilePath = Path.Combine(_contractMatchingTaskConfiguration.Value.ContractsUnMatchedPath, closingDocumentFile.Name);

                    await FileExt.MoveFileAsync(closingDocumentFile.FullName, destinationFilePath, true, CancellationToken.None);

                    //if (closingDocumentValidationResult.ContractIdNotFound)
                    //{
                        
                    //}
                    //else if (closingDocumentValidationResult.ContractNameInFileNotFound)
                    //{
                    //    destinationFilePath = Path.Combine(_contractMatchingTaskConfiguration.Value.ContractsErrorPath, "WrongFileName", closingDocumentFile.Name);
                    //}
                    //else if (!closingDocumentValidationResult.IsPdf)
                    //{
                    //    destinationFilePath = Path.Combine(_contractMatchingTaskConfiguration.Value.ContractsErrorPath, "NotPdf", closingDocumentFile.Name);
                    //}
                }
            }
            _logger.LogInformation("ContractMatchingTask - Ended");
        }

        internal class ContractDocumentValidationResult
        {
            public string ContractId { get; set; }
            public byte[] PatternContent { get; set; }
            public int PageCount { get; set; }

            public bool IsPdf { get; set; }
            public bool ContractNameInFileNotFound { get; set; }
            public bool ContractIdNotFound { get; set; }
            public bool IsSuccess { get; set; }

            public static ContractDocumentValidationResult NotPdf => new ContractDocumentValidationResult { IsPdf = false };
            public static ContractDocumentValidationResult WrongFileName => new ContractDocumentValidationResult { ContractNameInFileNotFound = true };
            public static ContractDocumentValidationResult ContractNotFound => new ContractDocumentValidationResult { ContractIdNotFound = true };

            public static ContractDocumentValidationResult Success(string contractId, byte[] patternContent, int pageCount) =>
                new ContractDocumentValidationResult { IsSuccess = true, IsPdf = true, ContractId = contractId, PatternContent = patternContent, PageCount = pageCount };
        }
    }
}
