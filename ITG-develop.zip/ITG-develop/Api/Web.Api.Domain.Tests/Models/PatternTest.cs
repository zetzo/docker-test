﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Web.Api.Domain.Common;
using Web.Api.Domain.Models;
using Xunit;
using FluentAssertions;
using Web.Api.Domain.Models.DomainEvent;

namespace Web.Api.Domain.Tests.Models
{

    public class PatternTest
    {
        [Theory]
        [InlineData("sample1.png")]
        [InlineData("sample2.jpg")]
        public void FactoryMethod_PatternContenType_MimeTypesFromFileAreCorrect(string fileName)
        {
            Pattern pattern = Pattern.CreateNew("1", fileName, "to jest opis", "not important now");

            pattern.ContentType.MimeType.Should().Be(MimeTypes.GetMimeTypeByExtension(Path.GetExtension(fileName)));

            //Assert.Equal(MimeTypes.GetMimeTypeByExtension(Path.GetExtension(fileName)), pattern.ContentType.MimeType);            
        }

        [Theory]
        [InlineData("1", "sample1.png", "opis1", "sha256")]
        public void FactoryMethod_ObjectConstruction_PropertiesAreSet(string contractId, string fileName, string description, string sha256)
        {
            Pattern pattern = Pattern.CreateNew(contractId, fileName, description, sha256);
            pattern.ImportFileName.Should().Be(fileName);
            pattern.Description.Should().Be(description);
            pattern.EntityId.Should().Be(sha256);
            pattern.ImportDate.GetHashCode().Should().NotBe(0);
            pattern.ContentType.MimeType.Should().Be(MimeTypes.GetMimeTypeByExtension(Path.GetExtension(fileName)));
        }

        [Theory]
        [InlineData("sample1.png", "description", "sha256", "554345434454")]
        [InlineData("sample2.png", "description", "sha256", "554345434454")]
        public void FactoryMethod_ObjectUpdate_PropertiesAreUpdated(string fileName, string description, string sha256, string inn)
        {
            Pattern pattern = Pattern.CreateNew("12433", "pattern1.jpg", "desc", "BA654fdfdsr4", "120000200000");
            pattern = pattern.Update(inn, description, sha256, fileName);
            
            pattern.ImportFileName.Should().Be(fileName);
            pattern.Description.Should().Be(description);
            pattern.EntityId.Should().Be(sha256);
            pattern.INN.Should().Be(inn);
        }

        [Theory]
        [InlineData("", "", "", "")]
        public void FactoryMethod_ObjectUpdate_PropertiesAreNotUpdated_WhenArgumentsAreEmptyOrNull(string fileName, string description, string sha256, string inn)
        {
            Pattern patternBeforeUpdate = Pattern.CreateNew("12433", "pattern1.jpg", "desc", "BA654fdfdsr4", "120000200000");
            var patternAfterUpdate = patternBeforeUpdate.Update(inn, description, sha256, fileName);

            patternAfterUpdate.ContractId.Should().Be(patternBeforeUpdate.ContractId);
            patternAfterUpdate.ImportFileName.Should().Be(patternBeforeUpdate.ImportFileName);
            patternAfterUpdate.Description.Should().Be(patternBeforeUpdate.Description);
            patternAfterUpdate.EntityId.Should().Be(patternBeforeUpdate.EntityId);
            patternAfterUpdate.INN.Should().Be(patternBeforeUpdate.INN);
        }

        [Fact]
        public void DomainEvents_AddEvent_ObjectContainsEventsCollection()
        {
            Pattern pattern = Pattern.CreateNew("12433", "pattern1.jpg", "desc", "BA654fdfdsr4", "120000200000");

            pattern.CreateLogEntry(builder =>
                          builder.In(DomainModelTypeEnum.Pattern)
                                 .At(ActionTypeEnum.Update)
                                 .WithResult(ActionResultEnum.Published)
                                 .WithMessage(x => "Object updated", pattern)
                                 .RelatedTo(13)
                                 .AsUser(10));

            pattern.DomainEvents.Should().HaveCount(1);
        }
    }
}
