using System;
using Xunit;

namespace Web.Api.Domain.Tests
{
    public class PatternContentTypeTest
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
