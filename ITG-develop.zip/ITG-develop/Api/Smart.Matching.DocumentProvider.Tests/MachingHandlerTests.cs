﻿using FluentAssertions;
using Moq;
using Smart.Matching.DocumentProvider.Chains;
using Smart.Matching.DocumentProvider.Infrastructure;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;
using Xunit;

namespace Smart.Matching.DocumentProvider.Tests
{
    public class MachingHandlerTests
    {       
        public MachingHandlerTests()
        {
            
        }

        [Fact]
        public void Matching_chain_run_only_first()
        {
            var matchingServiceClient = new Mock<IMatchingServiceClient>();
            matchingServiceClient.Setup(x => x.Match(It.IsAny<byte[]>(), It.IsAny<byte[]>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<decimal>())).Returns(220);

            var _matchingHandler = new RawMatchingHandler(matchingServiceClient.Object);

            _matchingHandler.AddNext(new RightAutoGammaMatchingHandler(matchingServiceClient.Object));
            _matchingHandler.AddNext(new BothAutoGammaMatchingHandler(matchingServiceClient.Object));


            int score = _matchingHandler.Handle(0, MatchingPayload.Create(new byte[0] { }, new byte[0] { }, string.Empty, string.Empty));
            score.Should().Be(220);
        }

        private byte[] GetBitmapData()
        {
            //Create the empty image.
            Bitmap image = new Bitmap(50, 50);

            //draw a useless line for some data
            Graphics imageData = Graphics.FromImage(image);
            imageData.DrawLine(new Pen(Color.Red), 0, 0, 50, 50);

            //Convert to byte array
            MemoryStream memoryStream = new MemoryStream();
            byte[] bitmapData;

            using (memoryStream)
            {
                image.Save(memoryStream, ImageFormat.Png);
                bitmapData = memoryStream.ToArray();
            }
            return bitmapData;
        }

        [Fact]
        public void Matching_chain_run_two()
        {
            var matchingServiceClientForFirstHanlder = new Mock<IMatchingServiceClient>();
            matchingServiceClientForFirstHanlder.Setup(x => x.Match(It.IsAny<byte[]>(), It.IsAny<byte[]>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<decimal>())).Returns(190);

            var matchingServiceClientForSecondHanlder = new Mock<IMatchingServiceClient>();
            matchingServiceClientForSecondHanlder.Setup(x => x.Match(It.IsAny<byte[]>(), It.IsAny<byte[]>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<decimal>())).Returns(205);

            var _matchingHandler = new RawMatchingHandler(matchingServiceClientForFirstHanlder.Object);

            _matchingHandler.AddNext(new RightAutoGammaMatchingHandler(matchingServiceClientForSecondHanlder.Object));
            _matchingHandler.AddNext(new BothAutoGammaMatchingHandler(matchingServiceClientForFirstHanlder.Object));

            int score = _matchingHandler.Handle(0, MatchingPayload.Create(GetBitmapData() , GetBitmapData(), string.Empty, string.Empty));
            score.Should().Be(205);
        }

        [Fact]
        public void Matching_chain_run_all()
        {
            var matchingServiceClientForFirstHanlder = new Mock<IMatchingServiceClient>();
            matchingServiceClientForFirstHanlder.Setup(x => x.Match(It.IsAny<byte[]>(), It.IsAny<byte[]>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<decimal>())).Returns(1);

            var matchingServiceClientForSecondHanlder = new Mock<IMatchingServiceClient>();
            matchingServiceClientForSecondHanlder.Setup(x => x.Match(It.IsAny<byte[]>(), It.IsAny<byte[]>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<decimal>())).Returns(100);

            var matchingServiceClientForThirdHanlder = new Mock<IMatchingServiceClient>();
            matchingServiceClientForThirdHanlder.Setup(x => x.Match(It.IsAny<byte[]>(), It.IsAny<byte[]>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<decimal>())).Returns(800);


            var _matchingHandler = new RawMatchingHandler(matchingServiceClientForFirstHanlder.Object);

            _matchingHandler.AddNext(new RightAutoGammaMatchingHandler(matchingServiceClientForSecondHanlder.Object));
            _matchingHandler.AddNext(new BothAutoGammaMatchingHandler(matchingServiceClientForThirdHanlder.Object));

            int score = _matchingHandler.Handle(0, MatchingPayload.Create(GetBitmapData(), GetBitmapData(), string.Empty, string.Empty));
            score.Should().Be(800);
        }      
    }
}
