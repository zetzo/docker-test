﻿using Application.Services;
using CSharpFunctionalExtensions;
using System;
using Xunit;

namespace Smart.Matching.DocumentProvider.Tests
{
    public class DocumentProviderTest
    {
        private readonly ContractFinder _contractFinder;
        public DocumentProviderTest()
        {
            _contractFinder = new ContractFinder();
        }

        [Theory]
        [InlineData("Абу-Зарук УХ_ЗД_ЛС-57335_01.01.19-31.03.19.PDF")]
        public void Check_if_closing_document_name_is_ok(string closingDocumentFileName)
        {
            Result<string> contractResult = _contractFinder.GetFromClosingDocument(closingDocumentFileName);

            Assert.True(contractResult.IsSuccess);

            //Result<PdfHelper.PdfMetadata> pdfMetadataResult = PdfHelper.Instance.ReadMetadaFromFile(closingDocumentFile.FullName);

            //Result<byte[]> patternContentResult = await _patternMatchingService.GetPatternByContractId(contractResult.Value);

            //Result closingDocumentValidationResult = Result.Combine(contractResult, pdfMetadataResult, patternContentResult);

        }
    }
}
