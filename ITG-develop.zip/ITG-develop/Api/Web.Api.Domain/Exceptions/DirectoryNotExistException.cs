﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.Domain.Exceptions
{
    public class DirectoryNotExistException : DirectoryNotFoundException
    {
        public DirectoryNotExistException() { }
        public DirectoryNotExistException(string message) : base(message) { }
        public DirectoryNotExistException(string message, Exception innerException) : base(message, innerException) { }
    }
}
