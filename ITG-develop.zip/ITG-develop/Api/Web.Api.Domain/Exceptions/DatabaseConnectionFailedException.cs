﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Exceptions
{
    public class DatabaseConnectionFailedException : Exception
    {
    }
}
