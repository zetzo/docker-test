﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Exceptions
{
    public class PatternContentNotFoundException : Exception
    {
        public PatternContentNotFoundException() { }
        public PatternContentNotFoundException(string message) : base(message) { }
        public PatternContentNotFoundException(string message, Exception innerException) : base(message, innerException) { }
    }
}
