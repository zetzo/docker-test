﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.Domain.Exceptions
{
    public class FileNotExistException : FileNotFoundException
    {
        public FileNotExistException() { }
        public FileNotExistException(string message) : base(message) { }
        public FileNotExistException(string message, Exception innerException) : base(message, innerException) { }
    }
}
