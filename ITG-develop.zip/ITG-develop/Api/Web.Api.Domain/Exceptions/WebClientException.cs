﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.Domain.Exceptions
{
    public class WebClientException : Exception
    {
        public string Route { get; set; }
        public string WebClientStack { get; set; }
        public string Filename { get; set; }
        public WebClientException() { }
        public WebClientException(string message, string route, string stack, string filename) : base(message) 
        {
            Route = route;
            WebClientStack = stack;
            Filename = filename;
        }
    }
}
