﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Common;
using Web.Api.Domain.Models.DomainEvent;

namespace Web.Api.Domain.Builders
{
    public class LogEntryBuilder<T> where T : AggregateRoot
    {
        private readonly LogEntry _logEntry;

        public LogEntryBuilder(LogEntry logEntry)
        {
            _logEntry = logEntry;
            _logEntry.DateCreated = DateTime.Now;
        }

        public LogEntryBuilder<T> In(DomainModelTypeEnum domainModelType)
        {
            _logEntry.DomainModelType = domainModelType;
            return this;
        }

        public LogEntryBuilder<T> At(ActionTypeEnum actionTypeEnum)
        {
            _logEntry.ActionType = actionTypeEnum;
            return this;
        }

        public LogEntryBuilder<T> WithResult(ActionResultEnum actionResult)
        {
            _logEntry.ActionResult = actionResult;
            return this;
        }

        public LogEntryBuilder<T> WithMessage(Func<T, T, string> predicate, T entityOne, T entityTwo)
        {
            _logEntry.Message = predicate.Invoke(entityOne, entityTwo);
            return this;
        }

        public LogEntryBuilder<T> WithMessage(Func<T, string> predicate, T entity)
        {
            _logEntry.Message = predicate.Invoke(entity);
            return this;
        }

        public LogEntryBuilder<T> AsUser(int userId)
        {
            _logEntry.UserId = userId;
            return this;
        }

        public LogEntryBuilder<T> RelatedTo(int objectId)
        {
            _logEntry.RelatedObjectId = objectId;
            return this;
        }
    }
}
