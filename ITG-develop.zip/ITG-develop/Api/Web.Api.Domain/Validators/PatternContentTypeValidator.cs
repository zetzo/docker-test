﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.ValueObjects;

namespace Web.Api.Domain.Validators
{
    public class PatternContentTypeValidator : AbstractValidator<PatternContentType>
    {
       
        public PatternContentTypeValidator()
        {

        }
    }

    //if (!SupportedMimeType.ContainsValue(mimeType))
    //            throw new Exception("Mime Type not supported");

    //string keyFound = SupportedMimeType.FirstOrDefault(x => x.Value == mimeType).Key;


    //if (mimeType != null)
    //            MimeType = mimeType;
    //        else
    //        {
    //            if (!SupportedMimeType.ContainsKey(extension))
    //                throw new Exception("file extension not supported");

    //MimeType = SupportedMimeType[extension];
    //        }            
}
