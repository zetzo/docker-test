﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Interfaces
{
    public interface IDomainEventsPublisher
    {
        Task DispatchDomainEventsAsync(AggregateRoot entity);
    }
}
