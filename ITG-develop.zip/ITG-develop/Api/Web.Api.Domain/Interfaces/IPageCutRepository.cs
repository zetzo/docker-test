﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Domain.Interfaces
{
    public interface IPageCutRepository
    {
        Task AddPageCut(string cyrylicFileName, int cutLeft, int cutBottom);
        PageCut GetBy(string latinFileName);
        Task RemoveBy(string latinFileName);

        IReadOnlyList<PageCut> GetAll();
    }
}
