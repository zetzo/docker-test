﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Dtos;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Paging;
using Web.Api.Domain.Models.PatternActions;

namespace Web.Api.Domain.Interfaces
{
    public interface IPatternRepository
    {
        Task<IEnumerable<Pattern>> GetAll(CancellationToken cancellationToken = default);
        Task<IEnumerable<Pattern>> GetAll(Expression<Func<Pattern, bool>> predicate, CancellationToken cancellationToken = default);
        Task<PagedResult<Pattern>> GetPagedAsync(int pageIndex, int pageSize);
        Task<PagedResult<Pattern>> GetPagedAsync(Expression<Func<Pattern, bool>> predicate, int pageIndex, int pageSize);
        Task<PagedResult<Pattern>> GetPagedAsync(int pageIndex, int pageSize, List<FilterModel> filters);
        Task Create(Pattern pattern, CancellationToken cancellationToken = default);
        Task CreateNew(Pattern pattern, CancellationToken cancellationToken = default);
        Task Delete(Pattern pattern, CancellationToken cancellationToken = default);
        Task<ICollection<Pattern>> GetUnconfirmed();
        Task<ICollection<Pattern>> GetWarnings();
        Task<ICollection<Pattern>> GetImageNotFound();
        Task<ICollection<Pattern>> GetByEntityIdDuplicate(string entityId);
        Task<Pattern> GetByEntityId(string entityId, CancellationToken cancellationToken = default);
        Task<Pattern> GetById(long id, CancellationToken cancellationToken = default);
        Task Update(Pattern pattern, CancellationToken cancellationToken = default);
        Task<Pattern> GetByContractId(string contractId);
        Task<IList<ContractScaffoldDto>> GetPatternsAge(string fromContractId, string toContractId);
    }
}
