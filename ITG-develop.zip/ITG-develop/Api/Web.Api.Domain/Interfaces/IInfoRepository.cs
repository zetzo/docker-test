﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Domain.Interfaces
{
    public interface IInfoRepository
    {
        Task<IEnumerable<VersionInfo>> GetLatestVersionInfo(int number, CancellationToken cancellationToken = default);
        Task<IEnumerable<MessageForUsers>> GetLatestUserMessages(int number, CancellationToken cancellationToken = default);
        Task CreateUserMessages(MessageForUsers message, CancellationToken cancellationToken = default);
    }
}