﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Domain.Interfaces
{
    public interface IStorageRepository
    {
        Task<bool> Add(string bucketName, string key, byte[] content);
        Task<bool> Delete(string bucketName, string key);
        Task<byte[]> GetById(string bucketName,string key);
        Task<Maybe<byte[]>> GetByIdRetMaybe(string bucketName, string key);

        Task<IReadOnlyList<string>> GetByKeys(string bucketName);

        Task<IEnumerable<PatternContent>> GetMany(List<string> keys);
    }
}
