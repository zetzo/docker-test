﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Interfaces
{
    public interface IRepository<TEntity> where TEntity : Entity 
    {
      
    }
}
