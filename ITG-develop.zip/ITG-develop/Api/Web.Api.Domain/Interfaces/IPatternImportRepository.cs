﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Domain.Interfaces
{
    public interface IPatternImportRepository
    {
        Task AddPatternImportWithConfirmOld(string contractId, string cyrylicFileName);
        Task AddPatternImport(string contractId, string cyrylicFileName);
        PatternImport GetBy(string contractId);
        Task RemoveBy(string contractId);
        Task<IList<PatternImport>> GetAll();
    }
}
