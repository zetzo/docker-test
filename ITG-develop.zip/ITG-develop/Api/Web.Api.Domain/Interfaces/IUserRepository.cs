﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Domain.Interfaces
{
    public interface IUserRepository
    {
        Task Create(User user, CancellationToken cancellationToken = default);
        Task<User> GetByUsername(string username, CancellationToken cancellationToken = default);
        Task<User> GetById(int id, CancellationToken cancellationToken = default);
        Task<IEnumerable<User>> GetAll(CancellationToken cancellationToken = default);
        Task<bool> Exist(string username, CancellationToken cancellationToken = default);
        Task Update(User user, CancellationToken cancellationToken = default);
    }
}
