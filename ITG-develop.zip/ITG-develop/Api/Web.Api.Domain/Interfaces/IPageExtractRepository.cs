﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Domain.Interfaces
{
    public interface IPageExtractRepository
    {
        PageExtract GetBy(string latinFileName);
        Task RemoveBy(string latinFileName);
        Task AddPageExtract(string cyrylicFileName, int pageNumber);
        Task<IList<PageExtract>> GetAll();
    }
}
