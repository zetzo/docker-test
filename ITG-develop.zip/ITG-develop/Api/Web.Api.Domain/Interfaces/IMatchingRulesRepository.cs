﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Domain.Interfaces
{
    public interface IMatchingRulesRepository
    {
        Task<MatchingRule> GetByMatchingRule(string contractId);
        Task<MatchingRule> GetGlobalMatchingRule();
    }
}
