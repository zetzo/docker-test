﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Models.DomainEvent;
using Web.Api.Domain.Models.Paging;

namespace Web.Api.Domain.Interfaces
{
    public interface ILogEntryRepository
    {
        Task AddAsync(INotification notification, CancellationToken cancellationToken = default);
        void Add(INotification notification);
        Task<PagedResult<LogEntry>> GetPagedAsync(int pageIndex, int pageSize);
    }
}
