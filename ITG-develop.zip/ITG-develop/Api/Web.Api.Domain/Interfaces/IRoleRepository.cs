﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Models.Roles;

namespace Web.Api.Domain.Interfaces
{
    public interface IRoleRepository
    {
        Task Create(Role role, CancellationToken cancellationToken = default);
        Task Update(Role role, CancellationToken cancellationToken = default);
        Task<IEnumerable<Role>> GetAll(CancellationToken cancellationToken = default);
        Task<Role> Get(int id, CancellationToken cancellationToken = default);
    }
}
