﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Interfaces
{
    public interface IInnContractRepository
    {
        Maybe<string> GetLatestContractIdBy(string contractId);
    }
}
