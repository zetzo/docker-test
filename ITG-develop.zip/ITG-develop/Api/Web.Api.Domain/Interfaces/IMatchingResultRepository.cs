﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Paging;

namespace Web.Api.Domain.Interfaces
{
    public interface IMatchingResultRepository
    {
        Task<PagedResult<MatchingResult>> GetPagedAsync(Expression<Func<MatchingResult, bool>> predicate, int pageIndex, int pageSize);
        Task<IEnumerable<MatchingResult>> GetMatchingResults();
        Task<IEnumerable<MatchingResult>> GetMatchingResultsBy(DateTime dateTime);
        Task<IEnumerable<MatchingResult>> GetMatchingResultsBy(DateTime matchingdate, int hourFrom, int hourTo);
    }
}
