﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Web.Api.Domain.Common
{
    public static class MimeTypes
    {
        private static Dictionary<string, string> SupportedMimeType = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase)
        {
            [".png"] = "image/png",        
            [".jpg"] = "image/jpeg"           
        };

        //TODO what about case sensitive
        public static string GetFileExtensionByMimeType(string mimeType)
        {
            string key = SupportedMimeType.FirstOrDefault(x => x.Value == mimeType).Key;

            if (key == null)
                throw new Exception($"{mimeType} is not supported");

            return key;
        }

        //TODO what about case sensitive
        public static string GetMimeTypeByExtension(string extension)
        {
            return SupportedMimeType[extension];
        }
    }
}
