﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Dtos
{
    public sealed class ScoringDTO
    {
        public string ContractId { get; set; }
        public string FileName { get; set; }
        public int Score { get; set; }
        public DateTime DateCreated {get;set;}
    }
}
