﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Models;

namespace Web.Api.Domain.Dtos
{
    public class PatternDto
    {
        public PatternStatusEnum Status { get; private set; }
        public byte[] Content { get; private set; }

        private PatternDto(PatternStatusEnum status)
        {
            Status = status;            
        }

        private PatternDto(PatternStatusEnum status, byte[] content)
        {
            Status = status;
            Content = content;
        }

        public static PatternDto VendorHasNoStamp() => new PatternDto(PatternStatusEnum.VendorHasNoStamp);
        public static PatternDto Confirmed(byte[] content) => new PatternDto(PatternStatusEnum.Confirmed, content);
        public static PatternDto Empty() => new PatternDto(PatternStatusEnum.NotInUse);

        public  bool IsVendorHasNoStamp => PatternStatusEnum.VendorHasNoStamp == Status;

    }
}
