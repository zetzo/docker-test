﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Dtos
{
    public class DocumentFile
    {
        public int NumericPartOfContractId { get; protected set; }
        public string OrginalFileName { get; protected set; }
        public DateTime FileDate { get; protected set; }

        public int PagesCount { get; protected set; }
        
        protected DocumentFile(string fileName, int numericPartOfContractId, DateTime fileDate, int pagesCount)
        {
            OrginalFileName = fileName;
            NumericPartOfContractId = numericPartOfContractId;
            FileDate = fileDate;
            PagesCount = pagesCount;
        }

        public static DocumentFile CreateNew(string fileName, int numericPartOfContractId, DateTime fileDate, int pagesCount)
            => new DocumentFile(fileName, numericPartOfContractId, fileDate, pagesCount);       
    }
}

