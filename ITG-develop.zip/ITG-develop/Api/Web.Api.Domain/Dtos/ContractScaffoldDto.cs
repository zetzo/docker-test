﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Dtos
{
    public class ContractScaffoldDto
    {
        public string ContractId { get; set; }
        public double Hours { get; set; }
    }
}
