﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Dtos
{
    public class TsvOcrRow
    {       
        public int Level { get; set; }    
        public int PageNum { get; set; }    
        public int BlockNum { get; set; }        
        public int ParNum { get; set; }        
        public int LineNum { get; set; }        
        public int WordNum { get; set; }        
        public int Left { get; set; }        
        public int Top { get; set; }        
        public int Width { get; set; }        
        public int Height { get; set; }        
        public int Conf { get; set; }        
        public string Text { get; set; }
    }
}
