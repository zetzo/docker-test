﻿using CSharpFunctionalExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using FluentValidation;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.ValueObjects
{   
    public class PatternContentType : ValueObject
    {
        public virtual string Extension { get; protected set; }
        public virtual string MimeType { get; }
        protected PatternContentType(string extension, string mimeType)
        {            
            Extension = extension;
            MimeType = mimeType;            
        }
        
        public static PatternContentType CreateNewByMimeType(string mimeType)
        {            
            return new PatternContentType(MimeTypes.GetFileExtensionByMimeType(mimeType), mimeType);
        }

        public static PatternContentType CreateNewByExtension(string extension)
        {
            return new PatternContentType(extension, MimeTypes.GetMimeTypeByExtension(extension));
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Extension;
            yield return MimeType;
        }

        public static implicit operator string(PatternContentType patternContentType)
        {
            return patternContentType.MimeType;
        }
    }

    public enum MimeType
    {
        Png, Jpg
    }
}
