﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.Domain.Models
{
    public enum PatternStatusEnum
    {
        Warning = 10,
        Confirmed = 11,
        Unconfirmed = 12,
        VendorHasNoStamp = 20,
        ImageNotFound = 21,
        NotInUse = 30
    }
}
