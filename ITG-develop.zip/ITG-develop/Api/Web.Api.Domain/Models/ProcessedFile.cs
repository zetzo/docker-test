﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models
{
    public class ProcessedFile : Entity
    {
        public virtual string ProcessedFileName { get; protected set; }
        public virtual DateTime ProcessedDate { get; protected set; }
        public virtual DateTime LastWriteDate { get; protected set; }    
        public string DocumentId { get; protected set; }
        public string DocumentType { get; protected set; }	
    }
}
