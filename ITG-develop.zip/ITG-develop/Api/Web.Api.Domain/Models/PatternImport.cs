﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models
{
    public class PatternImport : Entity
    {
        public virtual string ContractId { get; protected set; }
        public virtual string ImportFileName { get; protected set; }      
        public virtual bool ConfirmOld { get; protected set; }

        protected PatternImport()
        {

        }

        protected PatternImport(string contractId, string cyrylicFileName)
        {
            ContractId = contractId;
            ImportFileName = cyrylicFileName;
        }

        protected PatternImport(string contractId, string cyrylicFileName, bool confirmOld)
        {
            ContractId = contractId;
            ImportFileName = cyrylicFileName;
            ConfirmOld = confirmOld;
        }

        public static PatternImport CreateNew(string contractId, string cyrylicFileName) => new PatternImport(contractId, cyrylicFileName);

        public static PatternImport NewConfirmOld(string contractId, string cyrylicFileName) => new PatternImport(contractId, cyrylicFileName, true);

        public virtual void SetConfirmOld()
        {
            ConfirmOld = true;
        }
    }
}
