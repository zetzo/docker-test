﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models
{
    public class MessageForUsers : AggregateRoot
    {
        public virtual string Message { get; set; }
        public virtual DateTime DateCreated { get; set; }
        public virtual string Details { get; set; }
    }
}
