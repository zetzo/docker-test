﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models
{
    public class PageCut : Entity
    {
        public virtual string ImportFileName { get; protected set; }
        public virtual int CutLeft { get; protected set; }
        public virtual int CutBottom { get; protected set; }
        public virtual bool Reverse { get; protected set; }

        protected PageCut()
        {

        }

        protected PageCut(string importFileName, int cutLeft, int cutBottom)
        {
            ImportFileName = importFileName;
            CutLeft = cutLeft;
            CutBottom = cutBottom;
        }

        protected PageCut(string importFileName, int cutLeft, int cutBottom, bool reverse)
        {
            ImportFileName = importFileName;
            CutLeft = cutLeft;
            CutBottom = cutBottom;
            Reverse = reverse;
        }

        public static PageCut CreateNew(string importFileName, int cutLeft, int cutBottom) => new PageCut(importFileName, cutLeft, cutBottom);
        public static PageCut CreateNew(string importFileName, int cutLeft, int cutBottom, bool reverse) => new PageCut(importFileName, cutLeft, cutBottom, reverse);
    }
}
