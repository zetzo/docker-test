﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.Domain.Models
{
    public class PatternContent
    {
        public string Key { get; protected set; }
        public byte[] Value { get; protected set; }

        protected PatternContent(string key, byte[] value)
        {
            Key = key;
            Value = value;
        }

        public static PatternContent Create(string key, byte[] value) => new PatternContent(key, value);
    }
}
