﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Models.PatternActions
{
    public class Folder
    {
        public string Name { get; set; }
        public string Path { get; set; }
        public List<Folder> ChildFolders { get; set; }
        public List<File> Files { get; set; }
    }
}
