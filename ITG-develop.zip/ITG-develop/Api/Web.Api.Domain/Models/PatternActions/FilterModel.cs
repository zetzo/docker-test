﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.Domain.Models.PatternActions
{
    public class FilterModel
    {
        public string PropertyName { get; set; }
        public OperatorEnum Operator { get; set; }
        public string Value { get; set; }
        public string Value2 { get; set; }
    }

    public enum OperatorEnum
    {
        EXACT = 0,
        LIKE = 1,
        RANGE = 2,
        AGE_RANGE = 3,
        STATUS = 4,
        LIST = 5
    }
}
