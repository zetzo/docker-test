﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Models.PatternActions
{
    public class FileElement
    {
        public Guid Uuid { get; set; }
        public bool IsFolder { get; set; }
        public string Name { get; set; }
        public string Extension { get; set; }
        public Guid? Parent { get; set; }
        public DateTime CreationDate { get; set; }
    }
}
