﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Models.PatternActions
{
    public class File
    {
        public string FileName { get; set; }
        public string FileExtension { get; set; }
        public string FullName { get; set; }
        public bool ActionDisabled { get; set; }
    }
}
