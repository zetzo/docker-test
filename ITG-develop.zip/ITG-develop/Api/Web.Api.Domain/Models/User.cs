﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Common;
using Web.Api.Domain.Models.Roles;

namespace Web.Api.Domain.Models
{
    public class User : AggregateRoot
    {
        public virtual string FirstName { get; set; }
        public virtual string LastName { get; set; }
        public virtual string Username { get; set; }
        public virtual byte[] PasswordHash { get; set; }
        public virtual byte[] PasswordSalt { get; set; }
        public virtual IEnumerable<Role> Roles { get; set; }
        public virtual bool IsAdmin { get; set; }
        public virtual bool IsConfirmed { get; set; }
        public virtual string Settings { get; set; }

        protected User() { }

        protected User(string username, string firstname, string lastname, IEnumerable<Role> roles, bool isAdmin, bool isConfirmed)
        {
            Username = username;
            FirstName = firstname;
            LastName = lastname;
            Roles = roles;
            IsAdmin = isAdmin;
            IsConfirmed = isConfirmed;
        }

        public virtual User Update(string username, string firstname, string lastname, IEnumerable<Role> roles, 
            bool? isAdmin, bool? isConfirmed)
        {
            Username = username;
            FirstName = firstname;
            LastName = lastname;
            Roles = roles;
            IsAdmin = isAdmin ?? IsAdmin;
            IsConfirmed = isConfirmed ?? IsConfirmed;

            return this;
        }

        public virtual User UpdateUserSettings(string settings)
        {
            Settings = settings;

            return this;
        }

        public static User CreateUserFromIbmId(string username, string firstname, string lastname)
        {
            return new User(username, firstname, lastname, null, false, false);
        }

        public static User CreateForDebugMode(IEnumerable<Role> roles)
        {
            var user = new User("Admin", "Admin", "Admin", roles, true, true);
            user.Id = 110111011;

            return user;
        }
    }
}
