﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Models
{
    public class MatchingResult
    {
        public virtual int Id { get; set; }
        public virtual DateTime DateCreated { get; set; }
        public virtual string ContractId { get; set; }
        public virtual string FileName { get; set; }
        public virtual int Score { get; set; }
    }
}
