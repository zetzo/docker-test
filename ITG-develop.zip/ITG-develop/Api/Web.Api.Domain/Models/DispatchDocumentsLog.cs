﻿using System;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models
{
    public class DispatchDocumentsLog : Entity
    {
        public const string PdfMetadaErrorStatus = "PdfMetadataError";
        public const string ContractIdReadingErrorStatus = "ContractIdReadingError";
        public virtual string ImportFileName { get; protected set; }
        public virtual string LatinImportFileName { get; protected  set; }
        //public virtual DateTime ImportDate { get; protected set; }
        public virtual string DocumentType { get; protected set; } = "Unknown";
        public virtual string ImportStatus { get; protected set; } = "Success";           
        public virtual string Sha2 { get; protected set; }	                

        protected DispatchDocumentsLog()
        {

        }

        protected DispatchDocumentsLog(string cyrylicImportFileName, string latinImportFileName, string sha2)
        {
            ImportFileName = cyrylicImportFileName;
            LatinImportFileName = latinImportFileName;            
            Sha2 = sha2;
        }

        public static DispatchDocumentsLog Create(string cyrylicImportFileName, string latinImportFileName, string sha2)
           => new DispatchDocumentsLog(cyrylicImportFileName, latinImportFileName, sha2);
            
        public virtual void SetErrorReadingContractId()
        {
            ImportStatus = "ContractIdReadingError";
            ImportStatus = "Failed";
        }

        public virtual void SetAddendum()
        {
            DocumentType = "Addendum";
        }
        public virtual void SetContract()
        {
            DocumentType = "Contract";
        }
    }   
}
