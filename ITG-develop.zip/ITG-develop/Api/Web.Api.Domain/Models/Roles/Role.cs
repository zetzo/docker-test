﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models.Roles
{
    public class Role : AggregateRoot
    {
        public virtual string Name { get; protected set; }
        public virtual string Description { get; protected set; }
        public virtual string AggregatedPermissionList { get; protected set; }
        public virtual bool IsActive { get; protected set; }

        protected Role() { }

        protected Role(string name, string description, string aggregatedPermissionList, bool isActive)
        {
            Name = name;
            Description = description;
            AggregatedPermissionList = aggregatedPermissionList;
            IsActive = isActive;
        }

        public static Role Create(string name, string description, IEnumerable<Permissions> permissions, bool isActive)
        {
            if (permissions == null || !permissions.Any())
                throw new InvalidOperationException("There should be at least one permission associated with a role.");

            var aggregatedPermissionList = permissions.PackPermissionsIntoString();

            return new Role(name, description, aggregatedPermissionList, isActive);
        }

        public virtual Role Update(string name, string description, IEnumerable<Permissions> permissions, bool isActive)
        {
            if (permissions == null || !permissions.Any())
                throw new InvalidOperationException("There should be at least one permission associated with a role.");

            Name = name;
            Description = description;
            AggregatedPermissionList = permissions.PackPermissionsIntoString();
            IsActive = isActive;

            return this;
        }
    }
}
