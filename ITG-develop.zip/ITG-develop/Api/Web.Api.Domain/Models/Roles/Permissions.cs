﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.Domain.Models.Roles
{
    public enum Permissions
    {
        [Display(GroupName = "Pattern", Name = "Read", Description = "Can read patterns")]
        PatternRead = 0x10,
        [Display(GroupName = "Pattern", Name = "Create", Description = "Can craete a pattern")]
        PatternCreate = 0x11,
        [Display(GroupName = "Pattern", Name = "Update", Description = "Can update a pattern")]
        PatternUpdate = 0x12,
        [Display(GroupName = "Pattern", Name = "Delete", Description = "Can delete a pattern")]
        PatternDelete = 0x13,
        [Display(GroupName = "Mapping", Name = "Create", Description = "Can create inn - contract id mappings")]
        MappingsCreate = 0x14,

        [Display(GroupName = "User", Name = "Read", Description = "Can read users")]
        UserRead = 0x20,
        [Display(GroupName = "User", Name = "Change", Description = "Can change user data")]
        UserChange = 0x21,
        [Display(GroupName = "User", Name = "Create", Description = "Can create user")]
        UserCreate = 0x22,

        [Display(GroupName = "Role", Name = "Read", Description = "Can read roles")]
        RoleRead = 0x30,
        [Display(GroupName = "Role", Name = "Create", Description = "Can create role")]
        RoleCreate = 0x31,
        [Display(GroupName = "Role", Name = "Change", Description = "Can change role permissions")]
        RoleChange = 0x32,

        [Display(GroupName = "Log", Name = "Read", Description = "Can read logs")]
        LogEntryRead = 0x40,
        [Display(GroupName = "MatchingResult", Name = "Read", Description = "Can read results of document matching")]
        MatchingResultRead = 0x41
    }
}
