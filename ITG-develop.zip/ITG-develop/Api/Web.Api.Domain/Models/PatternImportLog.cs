﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models
{
    public class PatternImportLog : Entity
    {
        const string ConfirmedFromWebMessage = "Old Pattern was better and was confirmed from web";

        public virtual string FileName { get; protected set; }
        public virtual string Message { get; protected set; }
        public virtual string ContractId { get;protected set; }
        public virtual DateTime ImportTime { get; protected set; } = DateTime.Now;

        public virtual string TaskName { get; protected set; }

        protected PatternImportLog()
        {

        }

        protected PatternImportLog(string fileName, string taskName, string contractId)
        {
            FileName = fileName;
            TaskName = taskName;
            ContractId = contractId;
        }

        public virtual void SetTaskName(string taskName)
        {
            TaskName = taskName;
        }

        public virtual void SetPatternChange(string message)
        {
            Message = message;
        }

        public virtual void SetContractId(string contractId)
        {
            ContractId = contractId;
        }

        public virtual void SetConfirmedFromWeb()
        {
            Message = ConfirmedFromWebMessage;
        }

        public virtual void SetError(string message)
        {
            Message = message;
        }

        public virtual void SetCurrentImportTime()
        {
            ImportTime = DateTime.Now;
        }

        public static PatternImportLog CreateNew(string fileName, string taskName, string contractId) => new PatternImportLog(fileName, taskName, contractId);
        
    }
}
