﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Web.Api.Domain.Common;
using Web.Api.Domain.ValueObjects;

namespace Web.Api.Domain.Models
{
    public class Pattern : AggregateRoot
    {
        public virtual string ContractId { get; protected set; }
        public virtual string INN { get; protected set; }
        public virtual string ImportFileName { get; protected set; }
        public virtual string LatinImportFileName { get; protected set; }
        public virtual DateTime ImportDate { get; protected set; }
        //date from pdf inside info 
        public virtual DateTime CreationDate { get; protected set; }
        public virtual string Description { get; protected set; }        
        public virtual string Status { get; protected set; }

        //Redis key
        public virtual string EntityId { get; protected set; }

        public virtual int Age { get { return (int)(DateTime.Now - ImportDate).TotalHours; } }

        public virtual byte[] Icon { get; protected set; }


        private string _contentType;
        public virtual PatternContentType ContentType { get => PatternContentType.CreateNewByMimeType(_contentType); protected set => _contentType = value; }        

        protected Pattern() { }

        protected Pattern(string contractId, DateTime creationDate, string importFileName, string latinImportFileName, string entityId)
        {
            ContractId = contractId;
            CreationDate = creationDate;
            ImportFileName = importFileName;
            LatinImportFileName = latinImportFileName;
            ContentType = PatternContentType.CreateNewByExtension(Path.GetExtension(importFileName));            
            EntityId = entityId;
            ImportDate = DateTime.Now;
        }

        protected Pattern(string contractId, string importFileName, string description, string entityId, string inn)
        {
            ContractId = contractId;
            INN = inn;
            ImportFileName = importFileName;
            ContentType = PatternContentType.CreateNewByExtension(Path.GetExtension(importFileName));
            Description = description;
            EntityId = entityId;            
            ImportDate = DateTime.Now;
        }

        public static Pattern CreateNew(string contractId, DateTime createdDate, string importFileName, string latinImportFileName, string entityId)
        => new Pattern(contractId, createdDate, importFileName, latinImportFileName, entityId);

        public static Pattern CreateNew(string contractId, string importFileName, string description, string entityId, string inn = "")
         => new Pattern(contractId, importFileName, description, entityId, inn);

        public virtual Pattern Update(string inn, string description, string entityId, string importFileName)
        {
            INN = !string.IsNullOrEmpty(inn) ? inn : INN;
            Description = !string.IsNullOrEmpty(description) ? description : Description;
            EntityId = !string.IsNullOrEmpty(entityId) ? entityId : EntityId;
            ImportFileName = !string.IsNullOrEmpty(importFileName) ? importFileName : ImportFileName;

            return this;
        }       

        public virtual bool HasPatternSameContentHash(string hash) => EntityId.Equals(hash, StringComparison.Ordinal);

        public virtual void SetLatinImportFileName(string latinImportFileName)
        {
            LatinImportFileName = latinImportFileName;
        }

        public virtual void SetImportFileName(string importFileName)
        {
            ImportFileName = importFileName;
        }

        public virtual void ChangeEntityId(string entityId)
        {
            EntityId = entityId;
        }

        public virtual void SetImportDate(DateTime importDateTime)
        {
            ImportDate = importDateTime;
        }

        public virtual void SetCreationDate(DateTime creationDate)
        {
            CreationDate = creationDate;
        }

        public virtual void SetStatus(string statusName)
        {
            Status = statusName;
        }

        public virtual void SetIconContent(byte[] content)
        {
            Icon = content;
        }

        public virtual bool IsConfirmed { get => PatternStatusEnum.Confirmed.ToString().Equals(Status, StringComparison.OrdinalIgnoreCase); }
        public virtual bool VendorHasNoStamp { get => PatternStatusEnum.VendorHasNoStamp.ToString().Equals(Status, StringComparison.OrdinalIgnoreCase); }
    }
}
