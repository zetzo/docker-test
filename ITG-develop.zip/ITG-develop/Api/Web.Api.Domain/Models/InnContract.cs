﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models
{
    public class InnContract : Entity
    {
        public virtual string Inn { get; protected set; }
        public virtual string ContractId { get; protected set; }        
    }
}
