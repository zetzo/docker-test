﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Domain.Models
{
    public class PatternImageRefitted
    {
        public long Id { get; set; }
        public string ImageData { get; set; }
    }
}
