﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models
{
    public class PageExtract : Entity
    {
        public virtual string ImportFileName { get; protected set; }
        public virtual int PageNumber { get; protected set; }

        protected PageExtract()
        {

        }

        protected PageExtract(string importFileName, int pageNumber)
        {            
            ImportFileName = importFileName;
            PageNumber = pageNumber;
        }

        public static PageExtract CreateNew(string importFileName, int pageNumber) => new PageExtract(importFileName, pageNumber);       
    }
}
