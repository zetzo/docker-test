﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.Domain.Models.DomainEvent
{
    public enum DomainModelTypeEnum
    {
        Pattern = 0,
        PatternContent = 1,
        Contract = 2,
        User = 3,
        Role = 4
    }
}
