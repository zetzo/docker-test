﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Api.Domain.Models.DomainEvent
{
    public enum ActionTypeEnum
    {
        Create = 0,
        Read = 1,
        Update = 2,
        Delete = 3
    }
}
