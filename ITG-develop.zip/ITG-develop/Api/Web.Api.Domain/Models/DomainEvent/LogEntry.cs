﻿using MediatR;
using System;

namespace Web.Api.Domain.Models.DomainEvent
{
    public class LogEntry : INotification
    {
        public virtual int Id { get; set; }
        public virtual DateTime DateCreated { get; set; }
        public virtual DomainModelTypeEnum DomainModelType { get; set; }
        public virtual ActionTypeEnum ActionType { get; set; }
        public virtual ActionResultEnum ActionResult { get; set; }
        public virtual int? RelatedObjectId { get; set; }
        public virtual string Message { get; set; }
        public virtual int UserId { get; set; }
    }
}
