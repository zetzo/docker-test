﻿using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models
{
    public class VersionInfo : Entity
    {
        public virtual DateTime DateCreated { get; set; }
        public virtual string VersionCode { get; set; }
        public virtual IEnumerable<Change> Changes { get; set; }
    }

    public class Change : Entity
    {
        public virtual string Description { get; set; }
    }


}
