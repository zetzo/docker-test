﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using Web.Api.Domain.Common;

namespace Web.Api.Domain.Models
{
    public class MatchingRule : Entity
    {
        public virtual string ContractId { get; protected set; }
        public virtual int Matched { get; protected set; }
        public virtual int UnMatched { get; protected set; }
                
        //between 0.6 and 0.9
        public virtual decimal Distance { get; set; }
        protected MatchingRule()
        {

        }

        protected MatchingRule(string contractId, int matched, int unmatched, decimal distance)
        {
            ContractId = contractId;
            Matched = matched;
            UnMatched = unmatched;           
            Distance = distance;
        }

        //default matching values
        public static MatchingRule Default => new MatchingRule("global",250,11, 0.6M);
    }
}
