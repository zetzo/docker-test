﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Polly;
using Polly.Retry;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMQ.Client.Exceptions;
using RabbitMQ.ClientWrapper.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMQ.ClientWrapper
{
    public class RpcQueueConsumer : IRpcQueueConsumer
    {
        private bool _isDisposed = false;
        private readonly IRabbitMQPersistentConnection _persistentConnection;
        private readonly ILogger<RpcQueueConsumer> _logger;
        private static EventingBasicConsumer _consumer;
        private IModel _channel;
        private readonly int _retryCount;
        private string _exchange;
        private string _queue;

        public RpcQueueConsumer(IRabbitMQPersistentConnection persistentConnection, ILogger<RpcQueueConsumer> logger,
            IOptions<RabbitSettings> rabbitSettings)
        {
            _persistentConnection = persistentConnection ?? throw new ArgumentNullException(nameof(persistentConnection));
            _logger = logger;
            _retryCount = rabbitSettings.Value.RetryCount;
            _exchange = rabbitSettings.Value.Exchange;
            _queue = rabbitSettings.Value.Queue;
        }
        public RpcQueueConsumer()
        {

        }
        public void Receive<T>(Func<T, Task> handler)
        {
            var policy = RetryPolicy
              .Handle<BrokerUnreachableException>()
              .Or<SocketException>()
              .WaitAndRetry(_retryCount, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)), (ex, time) =>
              {
                  _logger.LogWarning(ex, "Could not subscribe to queue: {Message} after {Timeout}s ({ExceptionMessage})", nameof(T), $"{time.TotalSeconds:n1}", ex.Message);
              });

            policy.Execute(() =>
            {
                _channel = CreateConsumerChannel();
                var queueName = DeclareAndBindQueueToExchange(_channel, _exchange, _queue);
                _consumer.Received += async (ch, ea) => await Consumer_Received(ch, ea, handler);

                _channel.BasicConsume(queue: queueName,
                                     autoAck: true,
                                     consumer: _consumer);
            });
        }

        private async Task Consumer_Received<T>(object sender, BasicDeliverEventArgs eventArgs, Func<T, Task> handler)
        {
            var message = Encoding.UTF8.GetString(eventArgs.Body);
            T item = DeserializeObject<T>(message);

            try
            {
                await handler(item);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "ERROR Processing message \"{message}\"", message);
                throw;
            }
        }

        private IModel CreateConsumerChannel()
        {
            if (!_persistentConnection.IsConnected)
            {
                _persistentConnection.TryConnect();
            }

            _logger.LogTrace("Creating RabbitMQ consumer channel");

            var channel = _persistentConnection.CreateModel();

            channel.CallbackException += (sender, ea) =>
            {
                _logger.LogWarning(ea.Exception, "Recreating RabbitMQ consumer channel");

                _channel.Dispose();
                //_channel = CreateConsumerChannel();
            };

            return channel;
        }

        private static string DeclareAndBindQueueToExchange(IModel channel, string exchange, string queue)
        {
            channel.ExchangeDeclare(exchange: exchange, type: "direct", true);

            var queueInfo = channel.QueueDeclare(queue: queue,
                                 durable: true,
                                 exclusive: false,
                                 autoDelete: false,
                                 arguments: null);

            channel.QueueBind(queue: queue, exchange: exchange, routingKey: "");
            //_consumer = new AsyncEventingBasicConsumer(channel);
            _consumer = new EventingBasicConsumer(channel);

            return queueInfo.QueueName;
        }

        public virtual string SerializeObject(object obj)
        {
            return JsonConvert.SerializeObject(obj);
        }

        public virtual R DeserializeObject<R>(string r)
        {
            return JsonConvert.DeserializeObject<R>(r);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                }

                _persistentConnection.Close();
                _persistentConnection.Dispose();
            }
            _isDisposed = true;
        }

        ~RpcQueueConsumer()
        {
            Dispose(false);
        }
    }
}
