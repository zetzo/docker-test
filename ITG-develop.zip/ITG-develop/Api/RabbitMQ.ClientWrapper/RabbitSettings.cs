﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RabbitMQ.ClientWrapper
{
    public class RabbitSettings
    {
        public string Queue { get; set; }
        public int RetryCount { get; set; }
        public string Exchange { get; set; }
    }
}
