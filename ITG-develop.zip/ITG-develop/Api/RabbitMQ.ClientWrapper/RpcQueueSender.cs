﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Polly;
using Polly.Retry;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMQ.Client.Exceptions;
using RabbitMQ.ClientWrapper.Interfaces;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMQ.ClientWrapper
{
    public class RpcQueueSender : IRpcQueueSender
    {
        private bool _isDisposed = false;
        private readonly IRabbitMQPersistentConnection _persistentConnection;
        private readonly ILogger<RpcQueueSender> _logger;
        private readonly int _retryCount;
        private string _rpcQueue;
        private string _exchange;

        public RpcQueueSender()
        {

        }

        public RpcQueueSender(IRabbitMQPersistentConnection persistentConnection, ILogger<RpcQueueSender> logger,
            IOptions<RabbitSettings> rabbitSettings)
        {
            _persistentConnection = persistentConnection ?? throw new ArgumentNullException(nameof(persistentConnection));
            _logger = logger;

            _rpcQueue = rabbitSettings.Value.Queue;
            _retryCount = rabbitSettings.Value.RetryCount;
            _exchange = rabbitSettings.Value.Exchange;
            DoQueueBindings(_rpcQueue);
        }

        private void DoQueueBindings(string rpcQueue)
        {
            if (!_persistentConnection.IsConnected)
            {
                _persistentConnection.TryConnect();
            }

            using (var channel = _persistentConnection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: _exchange, type: "direct", true);
                channel.QueueDeclare(rpcQueue, true, false, false, null);
                channel.QueueBind(queue: rpcQueue, exchange: _exchange, routingKey: rpcQueue);
            }
        }

        public virtual string SerializeObject(object obj)
        {
            return JsonConvert.SerializeObject(obj);
        }

        public virtual R DeserializeObject<R>(string r)
        {
            return JsonConvert.DeserializeObject<R>(r);
        }

        public R SendAndReceive<T, R>(T message) where T : class where R : class
        {
            if (!_persistentConnection.IsConnected)
            {
                _persistentConnection.TryConnect();
            }

            var policy = RetryPolicy.Handle<BrokerUnreachableException>()
              .Or<SocketException>()
              .WaitAndRetry(_retryCount, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)), (ex, time) =>
              {
                  _logger.LogWarning(ex, "Could not publish message: {Message} after {Timeout}s ({ExceptionMessage})", nameof(T), $"{time.TotalSeconds:n1}", ex.Message);
              });

            using (var channel = _persistentConnection.CreateModel())
            {
                _logger.LogTrace("Declaring RabbitMQ exchange to publish message: {Message}", nameof(message));

                var replyToQueue = channel.QueueDeclare();
                channel.QueueBind(queue: replyToQueue, exchange: _exchange, routingKey: replyToQueue);
                string replyQueueName = replyToQueue.QueueName;
                var consumer = new EventingBasicConsumer(channel);
                channel.BasicQos(0, 1, false);

                var sendItem = SerializeObject(message);
                var body = Encoding.UTF8.GetBytes(sendItem);

                BlockingCollection<R> _respQueue = new BlockingCollection<R>();
                R receivedMessage = default;
                policy.Execute(() =>
                {
                    var properties = channel.CreateBasicProperties();

                    string correlationId = Guid.NewGuid().ToString();
                    properties.CorrelationId = correlationId;
                    properties.ReplyTo = replyQueueName;

                    EventHandler<BasicDeliverEventArgs> receiver = (model, ea) =>
                    {
                        if (ea.BasicProperties.CorrelationId == correlationId)
                        {
                            R response = DeserializeObject<R>(Encoding.UTF8.GetString(ea.Body));
                            _respQueue.Add(response);
                        }
                    };

                    consumer.Received += receiver;

                    _logger.LogTrace("Publishing message to RabbitMQ: {Message}", nameof(T));

                    channel.BasicPublish(
                        exchange: _exchange,
                        routingKey: _rpcQueue,
                        mandatory: true,
                        basicProperties: properties,
                        body: body);

                    channel.BasicConsume(
                          consumer: consumer,
                          queue: replyQueueName,
                          autoAck: true);

                    receivedMessage = _respQueue.Take();
                    consumer.Received -= receiver;
                });

                return receivedMessage;
            }
        }

        public void Publish<T>(T message) where T : class
        {
            if (!_persistentConnection.IsConnected)
            {
                _persistentConnection.TryConnect();
            }

            var policy = RetryPolicy.Handle<BrokerUnreachableException>()
              .Or<SocketException>()
              .WaitAndRetry(_retryCount, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)), (ex, time) =>
              {
                  _logger.LogWarning(ex, "Could not publish message: {Message} after {Timeout}s ({ExceptionMessage})", nameof(T), $"{time.TotalSeconds:n1}", ex.Message);
              });

            using (var channel = _persistentConnection.CreateModel())
            {
                _logger.LogTrace("Declaring RabbitMQ exchange to publish message: {Message}", nameof(message));

                channel.ExchangeDeclare(exchange: _exchange, type: "direct", true);
                var replyToQueue = channel.QueueDeclare(queue: _rpcQueue,
                                     durable: true, exclusive: false, autoDelete: false, arguments: null);

                channel.QueueBind(queue: replyToQueue, exchange: _exchange, routingKey: replyToQueue);
                string replyQueueName = replyToQueue.QueueName;
                var consumer = new EventingBasicConsumer(channel);
                channel.BasicQos(0, 1, false);

                var sendItem = SerializeObject(message);
                var body = Encoding.UTF8.GetBytes(sendItem);
                policy.Execute(() =>
                {
                    var properties = channel.CreateBasicProperties();

                    string correlationId = Guid.NewGuid().ToString();
                    properties.CorrelationId = correlationId;
                    properties.ReplyTo = replyQueueName;

                    _logger.LogTrace("Publishing message to RabbitMQ: {Message}", nameof(T));

                    channel.BasicPublish(
                        exchange: _exchange,
                        routingKey: _rpcQueue,
                        mandatory: true,
                        basicProperties: properties,
                        body: body);

                });
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                }

                _persistentConnection.Dispose();
            }
            _isDisposed = true;
        }

        ~RpcQueueSender()
        {
            Dispose(false);
        }
    }
}
