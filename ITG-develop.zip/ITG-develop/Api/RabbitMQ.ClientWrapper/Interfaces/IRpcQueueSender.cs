﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMQ.ClientWrapper.Interfaces
{
    public interface IRpcQueueSender : IDisposable
    {
        R SendAndReceive<T, R>(T message) where T : class where R : class;
        void Publish<T>(T message) where T : class;
    }
}
