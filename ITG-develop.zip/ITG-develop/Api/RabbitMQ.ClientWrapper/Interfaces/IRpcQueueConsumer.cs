﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMQ.ClientWrapper.Interfaces
{
    public interface IRpcQueueConsumer
    {
        void Receive<T>(Func<T, Task> handler);
    }
}
