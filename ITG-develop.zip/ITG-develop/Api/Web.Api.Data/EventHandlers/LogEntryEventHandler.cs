﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models.DomainEvent;

namespace Web.Api.Data.EventHandlers
{
    public class LogEntryEventHandler : INotificationHandler<LogEntry>
    {
        private readonly ILogEntryRepository _logEntryRepository;
        public LogEntryEventHandler(ILogEntryRepository logEntryRepository)
        {
            _logEntryRepository = logEntryRepository;
        }
        public async Task Handle(LogEntry notification, CancellationToken cancellationToken)
        {
            await _logEntryRepository.AddAsync(notification, cancellationToken);
        }
    }
}
