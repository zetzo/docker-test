﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NHibernate;
using NHibernate.Linq;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Repository
{
    public class PatternImportRepository : BaseRepository<PatternImport>, IPatternImportRepository
    {
        public PatternImportRepository(ISession session) : base(session)
        {

        }


        public async Task AddPatternImportWithConfirmOld(string contractId, string cyrylicFileName)
        {
            PatternImport patternImport = GetBy(contractId);
            if (patternImport == null)
            {
                await _session.SaveOrUpdateAsync(PatternImport.NewConfirmOld(contractId, cyrylicFileName));
                await _session.FlushAsync();
            }
        }


        public async Task AddPatternImport(string contractId, string cyrylicFileName)
        {
            PatternImport patternImport = GetBy(contractId);
            if (patternImport == null)
            {
                await _session.SaveOrUpdateAsync(PatternImport.CreateNew(contractId, cyrylicFileName));
                await _session.FlushAsync();
            }
        }

        public async Task<IList<PatternImport>> GetAll()
        {
            return await _session.Query<PatternImport>().ToListAsync();
        }

        public PatternImport GetBy(string contractId)
        {
            return _session.Query<PatternImport>().Where(x => x.ContractId == contractId).FirstOrDefault();
        }

        public async Task RemoveBy(string contractId)
        {
            PatternImport pageExtract = GetBy(contractId);
            if (pageExtract != null)
            {
                await _session.DeleteAsync(pageExtract);
                await _session.FlushAsync();
            }
        }
    }
}
