﻿using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Repository
{
    public class MatchingRulesRepository : BaseRepository<MatchingRule>, IMatchingRulesRepository
    {
        public MatchingRulesRepository(ISession session) : base(session)
        {
        }

        public async Task<MatchingRule> GetByMatchingRule(string contractId)
        {
            return await _session.Query<MatchingRule>().Where(x => x.ContractId == contractId).SingleOrDefaultAsync();
        }

        public async Task<MatchingRule> GetGlobalMatchingRule()
        {
            return await _session.Query<MatchingRule>().Where(x => x.ContractId == "global").SingleOrDefaultAsync();
        }
    }
}
