﻿using CSharpFunctionalExtensions;
using MediatR;
using NHibernate;
using NHibernate.Criterion;
using NHibernate.Linq;
using NHibernate.Transform;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Data.Extensions;
using Web.Api.Domain.Dtos;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Paging;
using Web.Api.Domain.Models.PatternActions;

namespace Web.Api.Data.Repository
{
    public class PatternRepository : BaseRepository<Pattern>, IPatternRepository
    {
        public PatternRepository(ISession session) : base(session)
        {

        }

        public async Task Create(Pattern pattern, CancellationToken cancellationToken = default)
        {
            await _session.SaveAsync(pattern, cancellationToken);
            await _session.FlushAsync();
        }

        public async Task CreateNew(Pattern pattern, CancellationToken cancellationToken = default)
        {
            await base.SaveEntityAsync(pattern, cancellationToken);
        }

        public async Task Delete(Pattern pattern, CancellationToken cancellationToken = default)
        {
            await base.DeleteEntityAsync(pattern, cancellationToken);
        }

        public async Task<IEnumerable<Pattern>> GetAll(CancellationToken cancellationToken = default)
        {
            return await _session.Query<Pattern>().ToListAsync(cancellationToken);
        }

        public async Task<IEnumerable<Pattern>> GetAll(System.Linq.Expressions.Expression<Func<Pattern, bool>> predicate, CancellationToken cancellationToken = default)
        {
            return await _session.Query<Pattern>().Where(predicate).ToListAsync(cancellationToken);
        }

        public Task<Pattern> GetByContractId(string contractId)
        {
            return _session.Query<Pattern>().Where(x => x.ContractId == contractId).FirstOrDefaultAsync();
        }

        public async Task<Pattern> GetByEntityId(string entityId, CancellationToken cancellationToken = default)
        {
            return await _session.Query<Pattern>().Where(x => x.EntityId == entityId).FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<Pattern> GetById(long id, CancellationToken cancellationToken = default)
        {
            return await _session.Query<Pattern>().Where(x => x.Id == id).SingleOrDefaultAsync(cancellationToken);
        }

        public async Task<PagedResult<Pattern>> GetPagedAsync(int pageIndex, int pageSize)
        {
            return await _session.Query<Pattern>()
                                 .OrderByDescending(x => x.CreationDate)
                                 .GetPagedAsync(pageIndex, pageSize);
        }

        public async Task<PagedResult<Pattern>> GetPagedAsync(System.Linq.Expressions.Expression<Func<Pattern, bool>> predicate, int pageIndex, int pageSize)
        {
            return await _session.Query<Pattern>()
                                 .OrderByDescending(x => x.CreationDate)
                                 .GetPagedAsync(predicate, pageIndex, pageSize);
        }

        public async Task<PagedResult<Pattern>> GetPagedAsync(int pageIndex, int pageSize, List<FilterModel> filters)
        {            
            var criteria = BuildCriteria(filters);

            var criteriaRowCount = criteria
                   .SetProjection(Projections.RowCount())
                   .FutureValue<int>();

            var count = await criteriaRowCount.GetValueAsync();

            return await BuildCriteria(filters)
                .AddOrder(Order.Desc("ImportDate"))
                         .AddOrder(Order.Desc("ContractId"))                                                    
                         .GetPagedAsync<Pattern>(count, pageIndex,pageSize);
        }

        public async Task Update(Pattern pattern, CancellationToken cancellationToken = default)
        {
            using (var transaction = _session.BeginTransaction())
            {
                await _session.UpdateAsync(pattern, pattern.Id);
                transaction.Commit();
            }
        }

        public async Task<ICollection<Pattern>> GetUnconfirmed()
        {
            return await _session.Query<Pattern>().Where(x => x.Status == PatternStatusEnum.Unconfirmed.ToString()).ToListAsync();
        }

        public async Task<ICollection<Pattern>> GetWarnings()
        {
            return await _session.Query<Pattern>().Where(x => x.Status == PatternStatusEnum.Warning.ToString()).ToListAsync();
        }

        public async Task<ICollection<Pattern>> GetImageNotFound()
        {
            return await _session.Query<Pattern>().Where(x => x.Status == PatternStatusEnum.ImageNotFound.ToString()).ToListAsync();
        }

        public async Task<ICollection<Pattern>> GetByEntityIdDuplicate(string entityId)
        {
            return await _session.Query<Pattern>().Where(x => x.EntityId == entityId).ToListAsync();
        }

        private ICriteria BuildCriteria(List<FilterModel> filters)
        {
            ICriteria criteria = _session.CreateCriteria<Pattern>();

            foreach (var filter in filters)
            {
                switch (filter.Operator)
                {
                    case OperatorEnum.LIST:
                        criteria.Add(Expression.In(filter.PropertyName, filter.Value.Split(',')));
                        break;
                    case OperatorEnum.EXACT:
                        criteria = criteria.Add(Expression.Eq(filter.PropertyName, filter.Value).IgnoreCase());
                        break;
                    case OperatorEnum.STATUS:
                        criteria = criteria.Add(Expression.Eq(filter.PropertyName, filter.Value).IgnoreCase());
                        break;
                    case OperatorEnum.LIKE:
                        criteria = criteria.Add(Expression.Like(filter.PropertyName, filter.Value).IgnoreCase());
                        break;
                    case OperatorEnum.RANGE:
                        criteria = criteria.Add(Expression.Between(filter.PropertyName, filter.Value, filter.Value2));
                        break;
                    case OperatorEnum.AGE_RANGE:
                        criteria = criteria.Add(Expression.Gt("ImportDate",
                            DateTime.Now.Subtract(new TimeSpan(Int32.Parse(filter.Value2), 0, 0))));
                        criteria = criteria.Add(Expression.Lt("ImportDate",
                            DateTime.Now.Subtract(new TimeSpan(Int32.Parse(filter.Value), 0, 0))));
                        break;
                    default:
                        break;
                }
            }

            //if (filters.Count == 0)
            //    criteria = criteria.Add(Expression.Sql("1=1"));

            return criteria;
        }

        public async Task<IList<ContractScaffoldDto>> GetPatternsAge(string fromContractId, string toContractId)
        {
            return await _session.CreateSQLQuery("select * from smart.v_patterns_age where contractid between :from and :to")
                .SetString("from", fromContractId).SetString("to", toContractId)
                .SetResultTransformer(Transformers.AliasToBean(typeof(ContractScaffoldDto))).ListAsync<ContractScaffoldDto>();
        }
    }
}
