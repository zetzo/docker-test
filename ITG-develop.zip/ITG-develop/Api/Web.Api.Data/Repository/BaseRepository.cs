﻿using MediatR;
using NHibernate;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Data.Extensions;
using Web.Api.Domain.Common;
using Web.Api.Domain.Interfaces;

namespace Web.Api.Data.Repository
{
    public class BaseRepository<TEntity> : IRepository<TEntity> where TEntity : Entity
    {
        protected readonly ISession _session;
        public BaseRepository(ISession session)
        {
            _session = session;
        }
     
        public async Task SaveEntityAsync(AggregateRoot entity, CancellationToken cancellationToken = default(CancellationToken))
        {
            using (var transaction = _session.BeginTransaction())
            {
                await _session.SaveOrUpdateAsync(entity);
                await transaction.CommitAsync();
            }
        }

        public async Task DeleteEntityAsync(AggregateRoot entity, CancellationToken cancellationToken = default(CancellationToken))
        {
            using (var transaction = _session.BeginTransaction())
            {
                await _session.DeleteAsync(entity, cancellationToken);
                await transaction.CommitAsync();
            }
        }
    }
}
