﻿using CsvHelper;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Web.Api.Domain.Dtos;
using CsvHelper.Configuration;
using Web.Api.Data.Mappings;
using System;
using Web.Api.Data.Infrastructure;
using System.Text;

namespace Web.Api.Data.Repository
{
    public sealed class OcrRespository
    {
        private readonly Configuration _configuration;
        public OcrRespository()
        {
            _configuration = new Configuration
            {
                Delimiter = "\t",   
                
                //TODO fix this
                BadDataFound = (data) => {  }
            };
            //_configuration.TypeConverterCache.AddConverter(typeof(string), new HyphenToStringEmptyConverter());
            _configuration.RegisterClassMap<TsvOcrRowMap>();
        }

        public List<TsvOcrRow> GetFromFile(string filePath)
        {
            try
            {
                using (var reader = new StreamReader(filePath))
                using (var csv = new CsvReader(reader, _configuration))
                {
                    return csv.GetRecords<TsvOcrRow>().ToList();
                }
            }
            catch(Exception e)
            {

            }

            return new List<TsvOcrRow>();
        }
    }
}
