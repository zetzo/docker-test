﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NHibernate;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Repository
{
    public class PageCutRepository : BaseRepository<PageCut>, IPageCutRepository
    {
        public PageCutRepository(ISession session) : base(session)
        {

        }

        public async Task AddPageCut(string importFileName, int cutLeft, int cutBottom, bool reverse)
        {
            PageCut pageCut = GetBy(importFileName);
            if (pageCut == null)
            {
                await _session.SaveAsync(PageCut.CreateNew(importFileName, cutLeft, cutBottom, reverse));
                await _session.FlushAsync();
            }
        }

        public async Task AddPageCut(string importFileName, int cutLeft, int cutBottom)
        {
            PageCut pageCut = GetBy(importFileName);
            if (pageCut == null)
            {
                await _session.SaveAsync(PageCut.CreateNew(importFileName, cutLeft, cutBottom));
                await _session.FlushAsync();
            }
        }

        public IReadOnlyList<PageCut> GetAll()
        {
            return _session.Query<PageCut>().ToList();
        }

        public PageCut GetBy(string importFileName)
        {
            return _session.Query<PageCut>().Where(x => x.ImportFileName == importFileName).FirstOrDefault();
        }

        public async Task RemoveBy(string latinFileName)
        {
            PageCut pageCut = GetBy(latinFileName);
            if (pageCut != null)
            {
                await _session.DeleteAsync(pageCut);
                await _session.FlushAsync();
            }
        }
    }
}
