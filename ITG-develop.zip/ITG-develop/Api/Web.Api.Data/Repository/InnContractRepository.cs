﻿using NHibernate;
using NHibernate.Linq;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;
using CSharpFunctionalExtensions;

namespace Web.Api.Data.Repository
{
    public class InnContractRepository : BaseRepository<InnContract>, IInnContractRepository
    {
        //const string findMap = "SELECT m.INN FROM SMART.INN_CONTRACT_MAP m inner join smart.patterns p on m.contract_id = p.contract_id where p.status = 'Confirmed' and m.contract_id  = ? ";
            
        public InnContractRepository(ISession session) : base(session)
        {
        }

        public Maybe<string> GetLatestContractIdBy(string contractId)
        {
            var query = _session.CreateSQLQuery("SELECT INN FROM SMART.INN_CONTRACT_MAP WHERE CONTRACT_ID = ?");
            //var query = _session.CreateSQLQuery(findMap);

            var inn = query.SetString(0, contractId).UniqueResult<String>();

            if (string.IsNullOrEmpty(inn))
                return Maybe<string>.None;

            List<InnContract> innContracts = _session.Query<InnContract>().Where(x => x.Inn == inn).OrderByDescending(x=>x.ContractId).ToList();

            if (innContracts.Count == 0)
                return Maybe<string>.None;

            if (innContracts.Count == 1)
                return innContracts.First().ContractId;
            
            return innContracts.Skip(1).Take(1).First().ContractId;
        }
    }
}
