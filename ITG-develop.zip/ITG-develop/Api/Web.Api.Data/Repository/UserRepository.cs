﻿using MediatR;
using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Data.Extensions;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Repository
{
    public class UserRepository : BaseRepository<User>, IUserRepository
    {
        public UserRepository(ISession session) : base(session) { }

        public async Task Create(User user, CancellationToken cancellationToken = default)
        {
            using (var transaction = _session.BeginTransaction())
            {
                await _session.SaveAsync(user, cancellationToken);
                await transaction.CommitAsync();
            }
        }

        public async Task<User> GetByUsername(string username, CancellationToken cancellationToken = default)
        {
            return await _session.Query<User>().Where(x => x.Username == username).SingleOrDefaultAsync(cancellationToken);
        }

        public async Task<User> GetById(int id, CancellationToken cancellationToken = default)
        {
            return await _session.Query<User>().Where(x => x.Id == id).SingleOrDefaultAsync(cancellationToken);
        }

        public async Task<bool> Exist(string username, CancellationToken cancellationToken = default)
        {
            return await _session.Query<User>().AnyAsync(x => x.Username == username, cancellationToken);
        }

        public async Task<IEnumerable<User>> GetAll(CancellationToken cancellationToken = default)
        {
            return await _session.Query<User>().ToListAsync();
        }

        public async Task Update(User user, CancellationToken cancellationToken = default)
        {
            await base.SaveEntityAsync(user, cancellationToken);
        }
    }
}
