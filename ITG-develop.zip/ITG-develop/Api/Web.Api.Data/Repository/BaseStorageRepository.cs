﻿using IBM.Minio.ClientWrapper;
using Minio;
using Web.Api.Data.Infrastructure;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Repository
{
    public abstract class BaseStorageRepository
    {
        protected readonly MinioWrapper _minioWrapper;

        public BaseStorageRepository(MinioWrapper minioWrapper)
        {
            _minioWrapper = minioWrapper;
        }
    }
}
