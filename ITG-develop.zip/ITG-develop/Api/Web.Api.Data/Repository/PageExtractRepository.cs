﻿using System.Collections.Generic;
using NHibernate;
using System.Linq;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;
using System.Threading.Tasks;
using NHibernate.Linq;

namespace Web.Api.Data.Repository
{
    public class PageExtractRepository : BaseRepository<PageExtract>, IPageExtractRepository
    {
        public PageExtractRepository(ISession session) : base(session)
        {

        }

        public async Task AddPageExtract(string importFileName, int pageNumber)
        {
            PageExtract pageExtract = GetBy(importFileName);
            if (pageExtract == null)
            {
                await _session.SaveAsync(PageExtract.CreateNew(importFileName, pageNumber));
                await _session.FlushAsync();
            }
        }

        public async Task<IList<PageExtract>> GetAll()
        {
            return await _session.Query<PageExtract>().ToListAsync();
        }

        public PageExtract GetBy(string importFileName)
        {
            return _session.Query<PageExtract>().Where(x => x.ImportFileName == importFileName).SingleOrDefault();
        }

        public async Task RemoveBy(string importFileName)
        {
            PageExtract pageExtract = GetBy(importFileName);
            if (pageExtract != null)
            {
                await _session.DeleteAsync(pageExtract);
                await _session.FlushAsync();
            }
        }
    }
}
