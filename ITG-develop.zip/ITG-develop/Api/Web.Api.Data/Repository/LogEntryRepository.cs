﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using NHibernate;
using Web.Api.Data.Extensions;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models.DomainEvent;
using Web.Api.Domain.Models.Paging;

namespace Web.Api.Data.Repository
{
    public class LogEntryRepository : ILogEntryRepository
    {
        private readonly ISession _session;

        public LogEntryRepository(ISessionFactory session)
        {
            _session = session.OpenSession();
        }

        public void Add(INotification notification)
        {
            _session.Save(notification);
        }

        public async Task AddAsync(INotification notification, CancellationToken cancellationToken = default)
        {
            using (var transaction = _session.BeginTransaction())
            {
                await _session.SaveAsync(notification, cancellationToken);
                await transaction.CommitAsync();
            }
        }

        public async Task<PagedResult<LogEntry>> GetPagedAsync(int pageIndex, int pageSize)
        {

            return await _session.Query<LogEntry>()
                                 .OrderByDescending(x => x.DateCreated)
                                 .GetPagedAsync(pageIndex, pageSize);
        }
    }
}
