﻿using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models.Roles;

namespace Web.Api.Data.Repository
{
    public class RoleRepository : BaseRepository<Role>, IRoleRepository
    {
        public RoleRepository(ISession session) : base(session) { }

        public async Task Create(Role role, CancellationToken cancellationToken = default)
        {
            await base.SaveEntityAsync(role, cancellationToken);
        }

        public async Task<Role> Get(int id, CancellationToken cancellationToken = default)
        {
            return await _session.Query<Role>().Where(x => x.Id == id).SingleOrDefaultAsync(cancellationToken);
        }

        public async Task<IEnumerable<Role>> GetAll(CancellationToken cancellationToken = default)
        {
            return await _session.Query<Role>().ToListAsync(cancellationToken);
        }

        public async Task Update(Role role, CancellationToken cancellationToken = default)
        {
            await base.SaveEntityAsync(role, cancellationToken);
        }
    }
}
