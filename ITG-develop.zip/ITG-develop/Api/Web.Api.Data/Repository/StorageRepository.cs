﻿using CSharpFunctionalExtensions;
using IBM.Minio.ClientWrapper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Repository
{
    public class StorageRepository : BaseStorageRepository, IStorageRepository
    {
        public StorageRepository(MinioWrapper minioWrapper) : base(minioWrapper)
        {

        }
        public async Task<bool> Add(string bucketName, string key, byte[] content)
        {
            try
            {
                using (MemoryStream ms = new MemoryStream(content))
                {
                    await _minioWrapper.PutObjectAsync(bucketName, key, ms, content.Length);
                }
            }
            catch
            {
                return false;
            }

            return true;
        }

        public async Task<byte[]> GetById(string bucketName, string key)
        {
            try
            {
                return await _minioWrapper.GetObjectAsync(bucketName, key);
            }
            catch
            {
                return await Task.FromResult(new byte[0]);
            }            
        }


        [Obsolete("//Should be removed")]
        public Task<IEnumerable<PatternContent>> GetMany(List<string> keys)
            => Task.FromResult(Enumerable.Empty<PatternContent>());


        public async Task<bool> Delete(string bucketName, string key)
        {
            try
            {
                await _minioWrapper.RemoveObjectAsync(bucketName, key);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<IReadOnlyList<string>> GetByKeys(string bucketName)
        {
            var minioItems = await _minioWrapper.ListObjectAsync(bucketName);
            return minioItems.Select(x => x.Key).ToList().AsReadOnly();
        }
       
        public async Task<Maybe<byte[]>> GetByIdRetMaybe(string bucketName, string key)
        {
            try
            {
                return await _minioWrapper.GetObjectAsync(bucketName, key);
            }
            catch
            {
                return null;
            }
        }
    }
}
