﻿using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Repository
{
    public interface IPatternImportLogRespository
    {
        Task Add(PatternImportLog patternImportLog);
        Task Update(PatternImportLog patternImportLog);
    }
}
