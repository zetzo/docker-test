﻿using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Repository
{
    public class InfoRepository : BaseRepository<VersionInfo>, IInfoRepository
    {
        public InfoRepository(ISession session) : base(session) { }

        public async Task<IEnumerable<MessageForUsers>> GetLatestUserMessages(int number, CancellationToken cancellationToken = default)
        {
            return await _session.Query<MessageForUsers>()
                                 .OrderByDescending(x => x.DateCreated)
                                 .Take(number)
                                 .ToListAsync(cancellationToken);
        }

        public async Task<IEnumerable<VersionInfo>> GetLatestVersionInfo(int number, CancellationToken cancellationToken = default)
        {
            return await _session.Query<VersionInfo>()
                                 .OrderByDescending(x => x.DateCreated)
                                 .Take(number)
                                 .ToListAsync(cancellationToken);
        }

        public async Task CreateUserMessages(MessageForUsers message, CancellationToken cancellationToken = default)
        {
            await base.SaveEntityAsync(message, cancellationToken);
        }
    }
}