﻿using NHibernate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Repository
{
    public class PatternImportLogRespository : BaseRepository<PatternImportLog>, IPatternImportLogRespository
    {
        public PatternImportLogRespository(ISession session) : base(session)
        {

        }

        public async Task Add(PatternImportLog patternImportLog)
        {
            var lastPatternImportLog = 
                _session.Query<PatternImportLog>().Where(x => x.ContractId == patternImportLog.ContractId && x.FileName == patternImportLog.FileName && patternImportLog.Message == patternImportLog.Message).FirstOrDefault();
            
            if(lastPatternImportLog != null)
            {
                lastPatternImportLog.SetError(patternImportLog.Message);   
                lastPatternImportLog.SetCurrentImportTime();
                await _session.UpdateAsync(lastPatternImportLog);
            }
            else
            {
                await _session.SaveAsync(patternImportLog);                
            }
            await _session.FlushAsync();
        }

        public async Task Update(PatternImportLog patternImportLog)
        {
            await _session.UpdateAsync(patternImportLog);
            await _session.FlushAsync();
        }
    }
}
