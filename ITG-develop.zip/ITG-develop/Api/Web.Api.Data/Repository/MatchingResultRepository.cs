﻿using NHibernate;
using NHibernate.Linq;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Data.Extensions;
using Web.Api.Domain.Interfaces;
using Web.Api.Domain.Models;
using Web.Api.Domain.Models.Paging;

namespace Web.Api.Data.Repository
{
    public class MatchingResultRepository : IMatchingResultRepository
    {
        private readonly ISession _session;

        public MatchingResultRepository(ISession session)
        {
            _session = session;
        }

        public async Task<IEnumerable<MatchingResult>> GetMatchingResults()
        {
            return await _session.Query<MatchingResult>().Take(1000).OrderByDescending(x => x.DateCreated).OrderBy(x=>x.DateCreated).ToListAsync();
        }

        public async Task<IEnumerable<MatchingResult>> GetMatchingResultsBy(DateTime matchingDate)
        {
            return await _session.Query<MatchingResult>().Where(x=>x.DateCreated.Date == matchingDate.Date).OrderBy(x => x.DateCreated).ToListAsync();
        }

        public async Task<IEnumerable<MatchingResult>> GetMatchingResultsBy(DateTime matchingdate, int hourFrom, int hourTo)
        {
            DateTime queryDateTimeFrom = new DateTime(matchingdate.Year, matchingdate.Month, matchingdate.Day, hourFrom, 0, 0);
            DateTime queryDateTimeTo = new DateTime(matchingdate.Year, matchingdate.Month, matchingdate.Day, hourTo, 0, 0);

            return await _session.Query<MatchingResult>().Where(x => x.DateCreated > queryDateTimeFrom && x.DateCreated < queryDateTimeTo).OrderBy(x => x.DateCreated).ToListAsync();
        }

        public async Task<PagedResult<MatchingResult>> GetPagedAsync(Expression<Func<MatchingResult, bool>> predicate, int pageIndex, int pageSize)
        {
            return await _session.Query<MatchingResult>()
                                 .OrderByDescending(x => x.DateCreated)
                                 .GetPagedAsync(predicate, pageIndex, pageSize);
        }
    }
}
