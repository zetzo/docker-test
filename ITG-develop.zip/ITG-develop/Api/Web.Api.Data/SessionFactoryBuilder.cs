﻿using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Dialect;
using NHibernate.Tool.hbm2ddl;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Data.Infrastructure;

namespace Web.Api.Data
{
    public sealed class SessionFactoryBuilder
    {
        public static ISessionFactory BuildSessionFactory<T>(string connectionString)
        {
            try
            {
                return Fluently
            .Configure()
            .Database(PostgreSQLConfiguration.Standard
            .ConnectionString(connectionString)
            .Dialect<PostgreSQL82Dialect>())
            .Mappings(m => m.FluentMappings.AddFromAssemblyOf<T>())
            .BuildSessionFactory();
            }
            catch
            {
                Console.WriteLine(connectionString);
                throw;
            }
        }
    }
}
