﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models.Roles;

namespace Web.Api.Data.Mappings
{
    public class RoleMap : ClassMap<Role>
    {
        public RoleMap()
        {
            Schema("smart");
            Table("roles");
            Id(x => x.Id).GeneratedBy.Sequence("roles_id_seq");
            Map(x => x.Name).Column("name");
            Map(x => x.Description).Column("description");
            Map(x => x.AggregatedPermissionList).Column("aggregated_permission_list");
            Map(x => x.IsActive).Column("is_active");
        }
    }
}
