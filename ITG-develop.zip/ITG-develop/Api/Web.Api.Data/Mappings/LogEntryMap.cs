﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models.DomainEvent;

namespace Web.Api.Data.Mappings
{
    public class LogEntryMap : ClassMap<LogEntry>
    {
        public LogEntryMap()
        {
            Schema("smart");
            Table("logs");
            Id(x => x.Id).GeneratedBy.Sequence("smart.logs_id_seq");
            Map(x => x.DateCreated).Column("date_created").CustomType<DateTime>();
            Map(x => x.DomainModelType).Column("domain_model_type").CustomType<GenericEnumMapper<DomainModelTypeEnum>>();
            Map(x => x.ActionType).Column("action_type").CustomType<GenericEnumMapper<ActionTypeEnum>>();
            Map(x => x.ActionResult).Column("action_result").CustomType<GenericEnumMapper<ActionResultEnum>>();
            Map(x => x.Message).Column("message");
            Map(x => x.UserId).Column("user_id");
            Map(x => x.RelatedObjectId).Column("related_object_id");
        }
    }
}


