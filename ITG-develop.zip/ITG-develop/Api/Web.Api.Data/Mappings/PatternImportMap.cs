﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class PatternImportMap : ClassMap<PatternImport>
    {
        public PatternImportMap()
        {
            Schema("smart");
            Table("pattern_import");
            Id(x => x.Id).GeneratedBy.Sequence("pattern_import_id_seq");
            Map(x => x.ContractId).Column("contract_id").Nullable();
            Map(x => x.ImportFileName).Column("import_file_name");
            Map(x => x.ConfirmOld).Column("confirm_old");
        }
    }
}
