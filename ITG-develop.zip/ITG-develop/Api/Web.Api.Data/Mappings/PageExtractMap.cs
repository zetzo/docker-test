﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class PageExtractMap : ClassMap<PageExtract>
    {
        public PageExtractMap()
        {
            Schema("smart");
            Table("page_extract");
            Id(x => x.Id);
            Id(x => x.ImportFileName).Column("import_file_name");                        
            Map(x => x.PageNumber).Column("page_number");            
        }
    }
}
