﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    class MatchingResultMap : ClassMap<MatchingResult>
    {
        public MatchingResultMap()
        {
            Schema("smart");
            Table("matching_outcome");
            Id(x => x.Id).Column("id");
            Map(x => x.DateCreated).Column("date_created").CustomType<DateTime>();
            Map(x => x.ContractId).Column("contract_id");
            Map(x => x.FileName).Column("file_name");
            Map(x => x.Score).Column("score");
        }
    }
}
