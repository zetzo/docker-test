﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class PageCutMap : ClassMap<PageCut>
    {
        public PageCutMap()
        {
            Schema("smart");
            Table("page_cut");
            Id(x => x.Id).GeneratedBy.Sequence("page_cut_id_seq");                    
            Map(x => x.ImportFileName).Column("import_file_name");            
            Map(x => x.CutLeft).Column("cut_left");
            Map(x => x.CutBottom).Column("cut_bottom");
            //Map(x => x.Reverse).Column("reverse");
        }
    }
}
