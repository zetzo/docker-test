﻿using FluentNHibernate.Mapping;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class VersionInfoMap : ClassMap<VersionInfo>
    {
        public VersionInfoMap()
        {
            Schema("smart");
            Table("version_info");
            Id(x => x.Id).GeneratedBy.Sequence("smart.version_info_id_seq");
            Map(x => x.DateCreated).Column("date_created");
            Map(x => x.VersionCode).Column("version_code");
            HasManyToMany(x => x.Changes)
                .Schema("smart")
                .Table("version_version_changes")
                .ParentKeyColumn("version_info_id")
                .ChildKeyColumn("change_id");
        }
    }

    public class ChangesMap : ClassMap<Change>
    {
        public ChangesMap()
        {
            Schema("smart");
            Table("version_info_changes");
            Id(x => x.Id).GeneratedBy.Sequence("smart.version_info_changes_id_seq");
            Map(x => x.Description).Column("description");
        }
    }
}
