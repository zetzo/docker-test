﻿using FluentNHibernate.Mapping;
using System;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class DispatchDocumentsLogMap : ClassMap<DispatchDocumentsLog>
    {
        public DispatchDocumentsLogMap()
        {
            Schema("smart");
            Table("dispatch_documents_logs");
            Id(x => x.Id).GeneratedBy.Sequence("dispatch_documents_logs_id_seq");
            Map(x => x.ImportFileName).Column("import_file_name");
            Map(x => x.LatinImportFileName).Column("latin_import_file_name");
            //Map(x => x.ImportDate).Column("import_date").CustomType<DateTime>();
            Map(x => x.DocumentType).Column("document_type");
            Map(x => x.ImportStatus).Column("import_status");            
            Map(x => x.Sha2).Column("sha2");
        }
    }    
}
