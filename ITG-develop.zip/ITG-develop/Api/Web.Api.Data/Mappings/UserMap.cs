﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class UserMap : ClassMap<User>
    {
        public UserMap()
        {
            Schema("smart");
            Table("users");
            Id(x => x.Id).GeneratedBy.Sequence("users_id_seq");
            Map(x => x.FirstName).Column("first_name");
            Map(x => x.LastName).Column("last_name");
            Map(x => x.Username).Column("username");
            Map(x => x.PasswordHash).Column("password_hash");
            Map(x => x.PasswordSalt).Column("password_salt");
            Map(x => x.IsAdmin).Column("is_admin");
            Map(x => x.IsConfirmed).Column("is_confirmed");
            Map(x => x.Settings).Column("settings");
            HasManyToMany(x => x.Roles)
                .Schema("smart")
                .Table("user_role")
                .ParentKeyColumn("user_id")
                .ChildKeyColumn("role_id");
        }
    }
}
