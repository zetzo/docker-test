﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class MessageForUsersMap : ClassMap<MessageForUsers>
    {
        public MessageForUsersMap()
        {
            Schema("smart");
            Table("user_message");
            Id(x => x.Id).GeneratedBy.Sequence("user_message_id_seq");
            Map(x => x.Message).Column("message");
            Map(x => x.DateCreated).Column("date_created");
            Map(x => x.Details).Column("details");
        }
    }
}
