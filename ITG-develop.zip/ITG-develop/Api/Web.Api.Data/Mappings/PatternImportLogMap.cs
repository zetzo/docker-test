﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class PatternImportLogMap : ClassMap<PatternImportLog>
    {
        public PatternImportLogMap()
        {
            Table("smart.pattern_import_log");
            Id(x => x.Id);
            Map(x => x.ContractId,"contract_id");
            Map(x => x.FileName,"file_name");
            Map(x => x.Message, "message");
            Map(x => x.ImportTime, "import_time");
            Map(x => x.TaskName, "task_name");
        }
    }
}
