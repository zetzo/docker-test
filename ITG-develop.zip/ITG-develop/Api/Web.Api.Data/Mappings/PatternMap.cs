﻿using FluentNHibernate.Mapping;
using System;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class PatternMap : ClassMap<Pattern>
    {
        public PatternMap()
        {
            Schema("smart");
            Table("patterns");
            Id(x => x.Id).GeneratedBy.Sequence("patterns_id_seq");
            Map(x => x.ContractId).Column("contract_id").Nullable();
            Map(x => x.ImportFileName).Column("import_file_name");
            Map(x => x.LatinImportFileName).Column("latin_import_file_name");
            Map(x => x.Description);
            Map(x => x.ImportDate).Column("import_date").CustomType<DateTime>();
            Map(x => x.CreationDate).Column("creation_date").CustomType<DateTime>();
            Map(x => x.EntityId).Column("entity_id");            
            Map(x => x.ContentType).Column("content_type").CustomType<string>().Access.CamelCaseField(Prefix.Underscore);            
            Map(x => x.Status).Column("status");
            Map(x => x.Icon).Column("icon");
        }
    }
}
