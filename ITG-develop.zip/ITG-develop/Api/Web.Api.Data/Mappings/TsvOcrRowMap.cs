﻿using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Dtos;

namespace Web.Api.Data.Mappings
{
    public class TsvOcrRowMap : ClassMap<TsvOcrRow>
    {
        public TsvOcrRowMap()
        {
            Map(x => x.Level).Name("level");
            Map(x => x.PageNum).Name("page_num");
            Map(x => x.BlockNum).Name("block_num");
            Map(x => x.ParNum).Name("par_num");
            Map(x => x.LineNum).Name("line_num");
            Map(x => x.WordNum).Name("word_num");
            Map(x => x.Left).Name("left");
            Map(x => x.Top).Name("top");
            Map(x => x.Width).Name("width");
            Map(x => x.Height).Name("height");
            Map(x => x.Height).Name("conf");
            Map(x => x.Text).Name("text");
        }
    }
}
