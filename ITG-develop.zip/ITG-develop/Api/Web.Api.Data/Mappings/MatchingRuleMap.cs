﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class MatchingRuleMap : ClassMap<MatchingRule>
    {
        public MatchingRuleMap()
        {
            Table("smart.matching_rules");
            Id(x => x.Id);
            Map(x => x.ContractId, "contract_id");
            Map(x => x.Matched);
            Map(x => x.UnMatched);            
            Map(x => x.Distance);
        }
    }
}
