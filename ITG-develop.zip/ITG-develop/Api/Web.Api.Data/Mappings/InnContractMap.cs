﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Text;
using Web.Api.Domain.Models;

namespace Web.Api.Data.Mappings
{
    public class InnContractMap : ClassMap<InnContract>
    {
        public InnContractMap()
        {
            Table("smart.v_inn_contract_map");
            Id(x => x.Id);
            Map(x => x.Inn);
            Map(x => x.ContractId, "contract_id");            
            
            //References(x => x.ContractId).Column("contract_id");
        }
    }
}
