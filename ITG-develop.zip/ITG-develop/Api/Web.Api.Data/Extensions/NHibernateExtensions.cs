﻿using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using Microsoft.Extensions.DependencyInjection;
using NHibernate;
using Polly;
using Polly.Retry;
using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;

namespace Web.Api.Data.Extensions
{
    public static class NHibernateExtensions
    {

        public delegate ISession ServiceResolver(string key);

        public static void AddNHibernate(this IServiceCollection services, string connectionString)
        {
            services.AddSingleton(SessionFactoryBuilder.BuildSessionFactory<NHibernateMarker>(connectionString));
            services.AddScoped(x => x.GetService<ISessionFactory>().OpenSession());
        }
    }
}
