﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Common;
using Web.Api.Domain.Interfaces;

namespace Web.Api.Data.Extensions
{
    public class DomainEventsPublisher : IDomainEventsPublisher
    {
        private readonly IMediator _mediator;
        public DomainEventsPublisher(IMediator mediator)
        {
            _mediator = mediator;
        }
        public async Task DispatchDomainEventsAsync(AggregateRoot entity)
        {
            List<INotification> domainEvents = new List<INotification>();
            domainEvents.AddRange(entity.DomainEvents);

            entity.ClearDomainEvents();

            var tasks = domainEvents
            .Select(async (domainEvent) =>
            {
                await _mediator.Publish(domainEvent);
            });

            await Task.WhenAll(tasks);
        }
    }
}
