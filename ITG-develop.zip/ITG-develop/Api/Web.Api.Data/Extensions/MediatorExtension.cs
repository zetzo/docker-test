﻿using MediatR;
using NHibernate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Domain.Common;

namespace Web.Api.Data.Extensions
{
    public static class MediatorExtension
    {
        public static async Task DispatchDomainEventsAsync(this IMediator mediator, AggregateRoot entity)
        {
            var domainEvents = entity.DomainEvents;

            entity.ClearDomainEvents();

            try
            {
                var tasks = domainEvents
                .Select(async (domainEvent) =>
                {
                    await mediator.Publish(domainEvent);
                });

                await Task.WhenAll(tasks);
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
