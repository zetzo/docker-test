﻿using Microsoft.Extensions.Logging;
using Polly;
using Polly.Retry;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Web.Api.Data.Infrastructure
{
    public sealed class RedisConnection
    {
        private readonly SemaphoreSlim _connectionLock = new SemaphoreSlim(initialCount: 1, maxCount: 1);
        private readonly string _configuration;
        private readonly ILogger<RedisConnection> _logger;
        private volatile ConnectionMultiplexer _connection;
        private IDatabase _database;        

        public RedisConnection(string configuration, ILogger<RedisConnection> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        private AsyncRetryPolicy PolicyOnTimeoutAsync(Action onTimeout)
        {
            return Policy.Handle<RedisTimeoutException>()
              .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)), (ex, time) =>
              {                
                  onTimeout();

                  _logger.LogWarning(ex, "Redis client could not process after {TimeOut}s ({ExceptionMessage})", $"{time.TotalSeconds:n1}", ex.Message);
              }
          );
        }

        private AsyncRetryPolicy PolicyReconnectOnTimeoutAsync()
        {
            return PolicyOnTimeoutAsync(async () => { CloseMultiplexer(); await ConnectAsync(); });
        }

        public async Task<bool> KeyExistsAsync(string key)
        {
            return await PolicyReconnectOnTimeoutAsync().ExecuteAsync<bool>(async () =>
            {
                await ConnectAsync();
                return await _database.KeyExistsAsync(key);
            });
        }

        public async Task<bool> KeyDeleteAsync(string key)
        {
            return await PolicyReconnectOnTimeoutAsync().ExecuteAsync<bool>(async () =>
            {
                await ConnectAsync();
                return await _database.KeyDeleteAsync(key);
            });
        }

        public async Task<byte[]> StringGetAsync(string key)
        {
            return await PolicyReconnectOnTimeoutAsync().ExecuteAsync<byte[]>(async () =>
            {
                await ConnectAsync();
                return await _database.StringGetAsync(key);            
            });
        }

        public async Task<bool> StringSetAsync(string key, byte[] content)
        {
            return await PolicyReconnectOnTimeoutAsync().ExecuteAsync<bool>(async () =>
            {
                await ConnectAsync();
                return await _database.StringSetAsync(key, content);
            });
        }
        public async Task<RedisValue[]> StringGetAsync(RedisKey[] redisKeys)
        {
            return await PolicyReconnectOnTimeoutAsync().ExecuteAsync<RedisValue[]>(async () =>
            {
                await ConnectAsync();
                return await _database.StringGetAsync(redisKeys);
            });
        }

        public byte[] StringGet(RedisKey key)
        {            
            Connect();
            return _database.StringGet(key);
        }       
               
        //Connect if connection doesn't exists
        private async Task ConnectAsync(CancellationToken token = default(CancellationToken))
        {
            token.ThrowIfCancellationRequested();

            await _connectionLock.WaitAsync(token);
            try
            {
                if (_database == null)
                {
                    _connection = await ConnectionMultiplexer.ConnectAsync(_configuration);

                    _database =  _connection.GetDatabase();
                }
            }
            finally
            {
                _connectionLock.Release();
            }
        }

        private void Connect()
        {
            if (_database != null)
            {
                return;
            }

            _connectionLock.Wait();
            try
            {
                if (_database == null)
                {
                    if (_connection == null)
                    {
                        _connection = ConnectionMultiplexer.Connect(_configuration);

                        _database = _connection.GetDatabase();
                    }
                }
            }
            finally
            {
                _connectionLock.Release();
            }
        }

        private void CloseMultiplexer()
        {
            try
            {
                _connection?.Close();
            }
            finally
            {
                _connection = null;
                _database = null;
            }
        }
    }
}
