﻿using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Data.Infrastructure
{
    public class HyphenToStringEmptyConverter : StringConverter
    {
        public override object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
        {
            Console.WriteLine(text);

            if (text.StartsWith("-") && text.Length > 2)
            {
                return string.Empty;
            }

            return base.ConvertFromString(text, row, memberMapData);
        }
    }
}
