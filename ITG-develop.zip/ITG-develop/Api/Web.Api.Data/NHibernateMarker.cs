﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Api.Data
{
    public sealed class NHibernateMarker
    {
        private NHibernateMarker() { }
    }
}
