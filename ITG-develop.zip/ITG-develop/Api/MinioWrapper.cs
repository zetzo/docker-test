﻿using Microsoft.Extensions.Options;
using Minio;
using System;
using System.Collections.Generic;
using System.Text;

namespace IBM.Minio.ClientWrapper
{
    public class MinioWrapper
    {
        private readonly MinioClient _minioClient;
        public MinioWrapper(MinioClient minioClient)
        {
            _minioClient = minioClient;
        }

    }
}
