﻿using Minio.DataModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Linq;
using ExcelDataReader;
using System.Data;
using Microsoft.Collections.Extensions;
using MicroOrm.Dapper.Repositories.Attributes;
using MicroOrm.Dapper.Repositories;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using MoreLinq;
using Dapper;
using Web.Api.Domain.Interfaces;
using Web.Api.Data.Repository;
using Web.Api.Data;
using Jaeger.Samplers;
using Jaeger;
using Microsoft.Extensions.Logging;
using Jaeger.Reporters;
using OpenTracing;
using Jaeger.Senders.Thrift;

namespace Smart.Cli
{
    class Program
    {       
        static async Task Main(string[] args)
        {
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            var loggerFactory = new LoggerFactory(); // get Microsoft.Extensions.Logging ILoggerFactory
            var serviceName = "initExampleService";

            var reporter = new RemoteReporter.Builder()
                .WithLoggerFactory(loggerFactory)
                .WithMaxQueueSize(100)
                .WithFlushInterval(TimeSpan.FromSeconds(1))
                .WithSender(new UdpSender("localhost", 6831, 0))
                .Build();

            var sampler = new ConstSampler(true);
            var tracer = new Tracer.Builder("test")
                .WithLoggerFactory(loggerFactory)
                .WithReporter(reporter)
                .WithSampler(sampler)
                .Build();


            ISpan span = tracer.BuildSpan("someWork").Start();
            span.Log("dupa").Finish();
            
            //var bytes = await File.ReadAllBytesAsync("f:\\122.pdf");
            //string base64 = Convert.ToBase64String(bytes);            

            //Supporter supporter = new Supporter("Server=plkrcon23q1;port=5432;Database=ITGDB;User Id=pguser01;Password=Ataesert12#", "Server=plkrcon38p1;port=5432;Database=ITGDB;User Id=pguser01;Password=byhuEJeMRn4fusjwACPPjhcWr56FzJxA8EFpYK2FHFL3WG989NyhVAQWfMur7QC5",
            //            new Minio.MinioClient("10.48.106.122:9001", "miau", "miaumiaumiau"),
            //            new Minio.MinioClient("plkrcon38p1:9001", "bGztjcxadS5NJbZFGj4SquVB6L4LyrWZVKsYgxbHxQnd3E7JKY3rETtDJHSr6wcU", "aeeZpRqNYgr6RZxyqSEb7y2gS8exGynCTEXR7P7VSakxGEThkCXdRYCa2vH9BhRX"));

            //await supporter.MoveFromProdToQA(new string[] { "LS-74358" });
            //await supporter.DeletePatterns(new string[] { "LS-99999" });



            //var connection = new Npgsql.NpgsqlConnection("Server=plkrcon38p1;port=5432;Database=ITGDB;User Id=pguser01;Password=byhuEJeMRn4fusjwACPPjhcWr56FzJxA8EFpYK2FHFL3WG989NyhVAQWfMur7QC5");
            //await connection.OpenAsync();
            //var command = connection.CreateCommand();
            //string update = "update smart.patterns set status = 'Confirmed' where contract_id = 'LS-78648'";
            //command.CommandText = update;

            //command.CommandText = "select status from smart.patterns p where contract_id = 'LS-78648'";
            //object resulr = command.ExecuteNonQuery();

            //IPatternRepository patternRepository = new PatternRepository(SessionFactoryBuilder.BuildSessionFactory<NHibernateMarker>("Server=plkrcon38p1;port=5432;Database=ITGDB;User Id=pguser01;Password=byhuEJeMRn4fusjwACPPjhcWr56FzJxA8EFpYK2FHFL3WG989NyhVAQWfMur7QC5").OpenSession());

            //StorageRepository storageRepository = new StorageRepository(new IBM.Minio.ClientWrapper.MinioWrapper(new Minio.MinioClient("plkrcon38p1:9001", "bGztjcxadS5NJbZFGj4SquVB6L4LyrWZVKsYgxbHxQnd3E7JKY3rETtDJHSr6wcU", "aeeZpRqNYgr6RZxyqSEb7y2gS8exGynCTEXR7P7VSakxGEThkCXdRYCa2vH9BhRX")));

            //var pattern = await patternRepository.GetByContractId("LS-74358");
            //var patternContent = await storageRepository.GetById("patterns", pattern.EntityId);

            //await File.WriteAllBytesAsync($"F:\\backup\\{pattern.ContractId}", patternContent);

            //var minioClient = new Minio.MinioClient("plkrcon38p1:9001", "bGztjcxadS5NJbZFGj4SquVB6L4LyrWZVKsYgxbHxQnd3E7JKY3rETtDJHSr6wcU", "aeeZpRqNYgr6RZxyqSEb7y2gS8exGynCTEXR7P7VSakxGEThkCXdRYCa2vH9BhRX");

            //IInnContractRepository innContractRepository = new InnContractRepository(SessionFactoryBuilder.BuildSessionFactory<NHibernateMarker>("Server=plkrcon38p1;port=5432;Database=ITGDB;User Id=pguser01;Password=byhuEJeMRn4fusjwACPPjhcWr56FzJxA8EFpYK2FHFL3WG989NyhVAQWfMur7QC5");

            //var connection = new Npgsql.NpgsqlConnection("Server=plkrcon38p1;port=5432;Database=ITGDB;User Id=pguser01;Password=byhuEJeMRn4fusjwACPPjhcWr56FzJxA8EFpYK2FHFL3WG989NyhVAQWfMur7QC5");
            //InnContractPairRepository innContractPairRepository = new InnContractPairRepository(connection);
            ////var patternscopy = connection.Query<Pattern>("select contract_id, entity_id from smart.patterns where status = 'Unconfirmed' and contract_id like 'LS-67%' and length(contract_id) = 8 order by contract_id").ToList();

            ////await minioClient.GetObjectAsync("CGROUP");
            //MultiValueDictionary<string, string> innContractMaps = new MultiValueDictionary<string, string>();
            //using (var stream = File.Open("F:\\INN.xls", FileMode.Open, FileAccess.Read))
            //{
            //    // Auto-detect format, supports:
            //    //  - Binary Excel files (2.0-2003 format; *.xls)
            //    //  - OpenXml Excel files (2007 format; *.xlsx)
            //    List<InnContractIdPair> innContractPairs = new List<InnContractIdPair>();

            //    using (var reader = ExcelReaderFactory.CreateReader(stream))
            //    {
            //        // Choose one of either 1 or 2:
            //        var data = reader.AsDataSet(new ExcelDataSetConfiguration
            //        {
            //            ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
            //            {
            //                UseHeaderRow = true,                            
            //            },

            //        });

            //        do
            //        {
            //            while (reader.Read())
            //            {
            //                string contractId = reader[0]?.ToString();
            //                string inn = reader[1]?.ToString();

            //                if(!string.IsNullOrEmpty(contractId) && !string.IsNullOrEmpty(inn))
            //                {
            //                    var innContractPair = new InnContractIdPair { ContractId = contractId, Inn = inn };
            //                    innContractPairs.Add(innContractPair);
            //                }
            //            }
            //        } while (reader.NextResult());


            //        var filteredList = innContractPairs.DistinctBy(x=>x.ContractId).ToList();

            //        //var filteredValues = data.Tables[0].DefaultView.ToTable(true);

            //        //foreach (DataRow row in data.Tables[0].Rows)
            //        //{
            //        //    string contractId = row[0].ToString();
            //        //    string inn = row[1].ToString();

            //        //    if (innContractMaps.ContainsKey(inn))
            //        //    {
            //        //        var values = innContractMaps.GetValueOrDefault(inn);
            //        //        if (!values.Contains(contractId))
            //        //            innContractMaps.Add(inn, contractId);
            //        //    }
            //        //    else
            //        //    {
            //        //        innContractMaps.Add(inn, contractId);
            //        //    }
            //        //}

            //        //var list1 = filteredValues.AsEnumerable().Select(x => new InnContractPair { Inn = x[0].ToString(), ContractId = x[1].ToString() }).ToList();

            //        //innContractMaps.Select(x => new InnContractPair { Inn = x.Key, ContractId = x.Value.First() });

            //        innContractPairRepository.BulkInsert(filteredList);

            //        //var values2 = innContractMaps["5905061344"];
            //        // 1. Use the reader methods

            //        // 2. Use the AsDataSet extension method                   
            //        // The result of each spreadsheet is in result.Tables
            //    }
            //}

            //ContractFinder contractFinder = new ContractFinder();
            //foreach (var file in new DirectoryInfo(@"F:\smart\Docs").GetFiles())
            //{
            //    var result = contractFinder.GetFromFile(file.Name);
            //    if(result.IsSuccess)
            //    {
            //        string contractId = result.Value;
            //        var pattern = await patternRepository.GetByContractId(contractId);
            //        if(pattern == null)
            //        {
            //            Console.WriteLine($"No Pattern {file.Name}");
            //        }
            //    }
            //    else
            //    {
            //        Console.WriteLine($"Error in {file.Name}");
            //    }
            //}
            //    string name = file.FullName;
            //    int lastDot = name.LastIndexOf('.');
            //    char[] signs = name.ToCharArray();
            //    List<char> newSigns = new List<char>();
            //    for (int i = 0; i < lastDot; i++)
            //    {
            //        if(signs[i] != '.')
            //        {
            //            newSigns.Add(signs[i]);
            //        }
            //    }

            //    string newFileNamePart1 = new string(newSigns.ToArray());
            //    string newFileName = newFileNamePart1 + file.Extension;

            //    File.Copy(name, Path.Combine(@"F:\smart\Docs", Path.GetFileName(newFileName)));
            //}


            //var values = await patternRepository.GetByContractId("LS-17022");

            //await minioClient.RemoveObjectAsync("patterns", values.EntityId);

            //var values = await patternRepository.GetImageNotFound();

            //foreach (var pattern in patternscopy)
            //{
            //    //var duplicates = await patternRepository.GetByEntityIdDuplicate(pattern.Entity_Id);

            //    //if(duplicates.Count > 1)
            //    //{
            //    //    Console.WriteLine($"nie kaseuje {pattern.Entity_Id}");
            //    //}

            //    await minioClient.RemoveObjectAsync("patterns", pattern.Entity_Id);
            //    //await patternRepository.Delete(pattern);
            //}


            //string fileName = @"F:\smart\CGroup\LS-7017\ИП Гусейнов Р.М. Контракт_ЛС-7017 Прил.1-3.pdf";
            //byte[] fileContent = await File.ReadAllBytesAsync(fileName);


            List<string> list = new List<string>();

            // Check whether 'mybucket' exists or not.
            //bool found = await minioClient.BucketExistsAsync("CGroup");
            //object gate = new object();
            //if (found)
            //{
            //    // List objects from 'my-bucketname'
            //    IObservable<Item> observable = minioClient.ListObjectsAsync("CGROUP", null, false);
            //    IDisposable subscription = observable.Subscribe(
            //              item => { 
            //                  Console.WriteLine("OnNext: {0}", item.Key);

            //                  string destinationFileName = Path.Combine("F:\\fake1", item.Key);
            //                  if (!File.Exists(destinationFileName))
            //                  {
            //                          try
            //                          {
            //                              minioClient.GetObjectAsync("CGROUP", item.Key, destinationFileName);
            //                          }
            //                          catch
            //                          {

            //                          }

            //                  }                             
            //              },
            //            ex => Console.WriteLine("OnError: {0}", ex.Message),
            //            () => Console.WriteLine("OnComplete: {0}"));

            //    Console.ReadLine();

            //    //var list2 = await minioClient.ListObjectsAsync("vol2", null, false).BufferAllAsync<Item>();

            //    //foreach (var file in list)
            //    //{
            //    //    string destinationFileName = Path.Combine("F:\\fake1", file);

            //    //    await minioClient.GetObjectAsync("vol2", file, destinationFileName);
            //    //}

            //    //subscription.Dispose();

            //}
            //else
            //{
            //    Console.WriteLine("mybucket does not exist");
            //}


        }
    }

    //public class InnContractPairRepository : DapperRepository<InnContractIdPair>
    //{

    //    public InnContractPairRepository(IDbConnection connection)
    //        : base(connection)
    //    {

    //    }
    //}

    //[Table("smart.inn_contract_map")]
    //public class InnContractIdPair
    //{
    //    [Key, Identity]
    //    public int Id { get; set; }

    //    [Column("contract_Id")]
    //    public string ContractId { get; set; }

    //    public string Inn { get; set; }
    //}



    public class InnContractMapDto
    {
        public string ContractId { get; set; }
        public string Inn { get; set; }
    }

    public class Pattern
    {
        public string Entity_Id { get; set; }
        public string Contract_Id { get; set; }
    }

    public static class ObExtenstions
    {
        public static Task<IList<T>> BufferAllAsync<T>(this IObservable<T> observable) where T : Item
        {
            List<T> result = new List<T>();
            object gate = new object();
            TaskCompletionSource<IList<T>> finalTask = new TaskCompletionSource<IList<T>>();

            observable.Subscribe(
                value =>
                {
                    lock (gate)
                    {
                        result.Add(value);
                    }

                    Console.WriteLine("OnNext: {0}", value.Key);
                },
                exception => finalTask.TrySetException(exception),
                () => finalTask.SetResult(result.AsReadOnly())
            );

            return finalTask.Task;
        }
    }    
}
