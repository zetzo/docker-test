﻿using Minio;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Web.Api.Data;
using Web.Api.Data.Repository;
using Web.Api.Domain.Interfaces;

namespace Smart.Cli
{
    public class Supporter
    {
        private readonly IPatternRepository _qaPatternRepository;
        private readonly IPatternRepository _prodPatternRepository;
        private readonly StorageRepository _qaStorageRepository;
        private readonly StorageRepository _prodStorageRepository;

        public Supporter(string qa, string prod, MinioClient minioClientQA, MinioClient minioClientProd)
        {
            _qaPatternRepository = new PatternRepository(SessionFactoryBuilder.BuildSessionFactory<NHibernateMarker>(qa).OpenSession());
            _prodPatternRepository = new PatternRepository(SessionFactoryBuilder.BuildSessionFactory<NHibernateMarker>(prod).OpenSession());

            _qaStorageRepository = new StorageRepository(new IBM.Minio.ClientWrapper.MinioWrapper(minioClientQA));
            _prodStorageRepository = new StorageRepository(new IBM.Minio.ClientWrapper.MinioWrapper(minioClientProd));
        }

        public async Task MoveFromProdToQA(string[] contractIds)
        {
            foreach(var contractId in contractIds)
            {
                var pattern = await _prodPatternRepository.GetByContractId(contractId);
                if(pattern!=null)
                {
                    var patternContent = await _prodStorageRepository.GetById("patterns", pattern.EntityId);
                    if(patternContent.Length > 0)
                    {
                        await _qaPatternRepository.Create(pattern);
                        await _qaStorageRepository.Add("patterns",pattern.EntityId, patternContent);
                    }
                }
            }
        }

        public async Task DeletePatterns(string[] contractIds)
        {
            foreach (var contractId in contractIds)
            {

                var pattern = await _qaPatternRepository.GetByContractId(contractId);                

                if (pattern != null)
                {
                    await _qaStorageRepository.Delete("patterns", pattern.EntityId);
                    await _qaPatternRepository.Delete(pattern);
                }                    
            }
        }
    }
}
