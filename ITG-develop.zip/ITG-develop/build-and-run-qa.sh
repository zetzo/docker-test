#!/bin/bash
if [ $# -ne 3 ] ; then 
    echo 'Please provide 3 parameters - login and password to nexus docker registry and version' 
    exit 1
fi



export DOCKER_HOST= DOCKER_TLS_VERIFY= DOCKER_CERT_PATH= TAG=$3 REGISTRY=10.48.106.122:8083/itg
echo 'Build SMART version' $TAG
 docker-compose -f docker-compose-qa.yaml -f docker-compose-qa.override.yaml build
echo 'Completed!'
echo '######################'
echo 'login nexus docker registry (10.48.106.122:8083)'
docker login 10.48.106.122:8083 -u $1 -p $2
echo 'push to nexus docker registry (10.48.106.122:8083)'
 docker-compose -f docker-compose-qa.yaml -f docker-compose-qa.override.yaml push
echo 'Done!'

echo 'Change host to prod env'
export DOCKER_HOST=tcp://plkrcon23q1:2376 DOCKER_TLS_VERIFY=1 DOCKER_CERT_PATH=~/.docker/smiesznyserwerek/ REGISTRY=plkrcon23q1:8083/itg
echo 'pull SMART new version images from nexus docker registry (10.48.106.122:8083)'
docker-compose -f docker-compose-qa.yaml -f docker-compose-qa.override.yaml pull
echo 'Done!'

echo 'recreate SMART new version images and recreate version' $TAG
docker-compose -f docker-compose-qa.yaml -f docker-compose-qa.override.yaml down  
docker-compose -f docker-compose-qa.yaml -f docker-compose-qa.override.yaml up -d 

echo 'Taaa daaaa!'
