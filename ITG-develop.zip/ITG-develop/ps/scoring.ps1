$global:baseDirectory = "F:\m\"
$global:baseConfig = "scoring.json"

Write-Debug "$baseDirectory$baseConfig"

try {
	$global:config = Get-Content "$baseDirectory$baseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
	Write-Error -Message "Configuration file is missing!" -ErrorAction Stop
}

if (!($config)) {
	Write-Error -Message "Configuration file is missing!" -ErrorAction Stop
}

if (-not ([System.Management.Automation.PSTypeName]'ServerCertificateValidationCallback').Type)
{
$certCallback = @"
    using System;
    using System.Net;
    using System.Net.Security;
    using System.Security.Cryptography.X509Certificates;
    public class ServerCertificateValidationCallback
    {
        public static void Ignore()
        {
            if(ServicePointManager.ServerCertificateValidationCallback ==null)
            {
                ServicePointManager.ServerCertificateValidationCallback += 
                    delegate
                    (
                        Object obj, 
                        X509Certificate certificate, 
                        X509Chain chain, 
                        SslPolicyErrors errors
                    )
                    {
                        return true;
                    };
            }
        }
    }
"@
    Add-Type $certCallback
}

$global:apiKey = ($config.Service.ApiKey)
$global:serviceUrl = ($config.Service.ServiceUrl)
$global:serviceErrorLogUrl = ($config.Service.ServiceErrorLogUrl)

# $thumbprint = (Get-ChildItem -Path Cert:\CurrentUser\My | Where-Object {$_.Subject -eq "CN=itg.web, O=IBM BTO, L=IBM, S=malopolskie"}).Thumbprint
# Write-Warning $thumbprint

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
[ServerCertificateValidationCallback]::Ignore()

$global:year = Get-Date -Format "yyyy-MM-dd"
$global:hourTo = Get-Date -Format "HH"
$global:hourFrom = $hourTo -as [int]
$hourFrom = $hourFrom - ($config.Service.Frequency)
$global:scoringServiceUrl = $serviceUrl + $year + "/" + $hourFrom + "/" + $hourTo
#$global:scoringServiceUrl = $serviceUrl

$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("X-API-KEY", $ApiKey)
#$response = Invoke-RestMethod -CertificateThumbprint $thumbprint $scoringServiceUrl -Headers $headers
Write-Host $scoringServiceUrl
$response = Invoke-RestMethod $scoringServiceUrl -Headers $headers
#write $response

$allFilesLocation = ($config.Policy.Locations.Destination.All)
$matchedFilesLocation = ($config.Policy.Locations.Destination.Matched)
$unMatchedFilesLocation = ($config.Policy.Locations.Destination.Unmatched)
$ambiguousFilesLocation = ($config.Policy.Locations.Destination.Ambiguous)

Function Move-Files([string]$sourceFolder, [string]$destinationFolder, [string]$fileName) {
    $source = Join-Path -Path $sourceFolder -ChildPath $fileName
    if(![System.IO.File]::Exists($source))
    {
        throw [System.IO.FileNotFoundException] "$fileName not found!"
    }
    $destination = Join-Path -Path $destinationFolder -ChildPath $fileName
    Move-Item -Path $source -Destination $destination

    if(![System.IO.File]::Exists($destination))
    {
        throw [System.IO.FileNotFoundException] "$fileName not moved to $destination!"
    }
}

Function Match-Location([int]$score, [string]$contractId) {
    $contractConfiguration = ($config.Policy.Criteria | ? {$_.Name -eq $contractId})

    if(!($contractConfiguration)) { Write-Warning -Message "Contract configuration not found!" }

    $conf = if ($contractConfiguration -ne $null) 
                { $contractConfiguration } 
            else 
                { ($config.Policy.Criteria |? {$_.Name -eq "Global"}) }
    
    $ranges = $conf.Ranges

    switch($score) {
        {$_ -In $ranges.Matched.Min..$ranges.Matched.Max } { return "Matched" }
        {$_ -In $ranges.Ambiguous.Min..$ranges.Ambiguous.Max } { return "Ambiguous" }
        {$_ -In $ranges.Unmatched.Min..$ranges.Unmatched.Max } { return "Unmatched" }
        default { return "Ambiguous" }
    }
}

Function Send-Error-Log([string]$error) {
    $JSON = "`"" + $error + "`""
    Write-Warning $JSON
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-API-KEY", $ApiKey)
    #$response = Invoke-RestMethod -CertificateThumbprint $thumbprint -Uri $serviceErrorLogUrl -Method Post -Body $JSON -ContentType "application/json" -Headers $headers
    $response = Invoke-RestMethod -Uri $serviceErrorLogUrl -Method Post -Body $JSON -ContentType "application/json" -Headers $headers
    Write-Output "Error send"
}

foreach($item in $response) {

    Try {
        $destName = Match-Location -Score $item.Score -ContractId $item.ContractId
        Write-Host $destName
        #Write-Host $config.Policy.Locations.Destination
        $destination = ($config.Policy.Locations.Destination | Select -ExpandProperty $destName)
        Write-Host $destination
        Move-Files -sourceFolder $allFilesLocation -destinationFolder $destination -fileName $item.filename
        $message = "File $($item.filename) [contract id: $($item.ContractId)] moved to $($destination) directory"
        Write-Output $message
    }
    Catch  [System.IO.DirectoryNotFoundException] {
            $formatstring = "Scoring Script Exception:`n" +
                    "    + Message          : {0}`n"
            $fields = $_.Exception

            $exception = $formatstring -f $fields
            Send-Error-Log($exception)
    }
    Catch [System.IO.FileNotFoundException] {
            $formatstring = "Scoring Script Exception:`n" +
                    "    + Message          : {0}`n"
            $fields = $_.Exception,
                    $_.InvocationInfo.PositionMessage

            $exception = $formatstring -f $fields

            Send-Error-Log($exception)
    }
}

