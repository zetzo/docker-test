param (
    [Parameter(Mandatory = $true)]
    [string]$path,
    [string]$count = 200
)

Get-ChildItem -Force -File -Path $path -ErrorAction SilentlyContinue | Where-Object { $_.CreationTime.Date -lt (Get-Date).Date } | Sort-Object CreationTime -Descending | Select-Object -First $count CreationTime, Name | Export-Csv -Path files.csv -NoTypeInformation -Encoding Unicode