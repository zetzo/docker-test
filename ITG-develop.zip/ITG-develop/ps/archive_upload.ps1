# Load WinSCP .NET assembly
Add-Type -Path "F:\WinSCP-5.17-Automation\WinSCPnet.dll"
 
# Session.FileTransferred event handler
Function Send-Error-Log([string]$error) {
    $JSON = "`"" + $error + "`""
    Write-Warning $JSON
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("X-API-KEY",  $global:config.Service.ApiKey)
    #$response = Invoke-RestMethod -CertificateThumbprint  $global:config.Service.Thumbprint  -Uri  $global:config.Service.ServiceErrorLogUrl -Method Post -Body $JSON -ContentType "application/json" -Headers $headers
    $response = Invoke-RestMethod -Certificate (Get-PfxCertificate -FilePath "F:\localhost.pfx") -Uri  $global:config.Service.ServiceErrorLogUrl -Method Post -Body $JSON -ContentType "application/json" -Headers $headers
    #$response = Invoke-RestMethod -Uri  $global:config.Service.ServiceErrorLogUrl -Method Post -Body $JSON -ContentType "application/json" -Headers $headers
    Write-Output "Error send"
}

if (-not ([System.Management.Automation.PSTypeName]'ServerCertificateValidationCallback').Type)
{
$certCallback = @"
    using System;
    using System.Net;
    using System.Net.Security;
    using System.Security.Cryptography.X509Certificates;
    public class ServerCertificateValidationCallback
    {
        public static void Ignore()
        {
            if(ServicePointManager.ServerCertificateValidationCallback ==null)
            {
                ServicePointManager.ServerCertificateValidationCallback += 
                    delegate
                    (
                        Object obj, 
                        X509Certificate certificate, 
                        X509Chain chain, 
                        SslPolicyErrors errors
                    )
                    {
                        return true;
                    };
            }
        }
    }
"@
    Add-Type $certCallback
}

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
[ServerCertificateValidationCallback]::Ignore()
function FileTransferred
{
    param($e)
 
    if ($e.Error -eq $Null)
    {
        Write-Host "Upload of $($e.FileName) succeeded"
    }
    else
    {
        Write-Host "Upload of $($e.FileName) failed: $($e.Error)"
    }
 
    if ($e.Chmod -ne $Null)
    {
        if ($e.Chmod.Error -eq $Null)
        {
            Write-Host "Permissions of $($e.Chmod.FileName) set to $($e.Chmod.FilePermissions)"
        }
        else
        {
            Write-Host "Setting permissions of $($e.Chmod.FileName) failed: $($e.Chmod.Error)"
        }
 
    }
    else
    {
        Write-Host "Permissions of $($e.Destination) kept with their defaults"
    }
 
    if ($e.Touch -ne $Null)
    {
        if ($e.Touch.Error -eq $Null)
        {
            Write-Host "Timestamp of $($e.Touch.FileName) set to $($e.Touch.LastWriteTime)"
        }
        else
        {
            Write-Host "Setting timestamp of $($e.Touch.FileName) failed: $($e.Touch.Error)"
        }
 
    }
    else
    {
        # This should never happen during "local to remote" synchronization
        Write-Host "Timestamp of $($e.Destination) kept with its default (current time)"
    }
}

$global:baseConfig = "archive_upload.json"

try {
	$global:config = Get-Content "$baseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
	Write-Error -Message "Configuration file is missing!" -ErrorAction Stop
}

if (!($config)) {
	Write-Error -Message "Configuration file is missing!" -ErrorAction Stop
}

# Main script
Function Upload-Contracts-Archive()
{
    try
    {
        $sessionOptions = New-Object WinSCP.SessionOptions -Property @{
            Protocol = [WinSCP.Protocol]::Sftp
            HostName = $global:config.Sftp.HostName
            UserName = $global:config.Sftp.UserName
            Password = $global:config.Sftp.Password
            SshPrivateKeyPassphrase = $global:config.Sftp.Password
            SshHostKeyFingerprint = $global:config.Sftp.SshHostKeyFingerprint
            SshPrivateKeyPath=$global:config.Sftp.SshPrivateKeyPath            
        }
     
        $session = New-Object WinSCP.Session
        try
        {
            # Will continuously report progress of synchronization
            $session.add_FileTransferred( { FileTransferred($_) } )
     
            # Connect
            $session.Open($sessionOptions)
     
            # Synchronize files
            #$synchronizationResult = $session.SynchronizeDirectories([WinSCP.SynchronizationMode]::Remote,  $global:config.Sftp.ContractsDirectory,  $global:config.Sftp.RemoteDirectory, $False)
    
            $compareResult = $session.CompareDirectories([WinSCP.SynchronizationMode]::Remote,  $global:config.Sftp.ContractsDirectory,  $global:config.Sftp.RemoteDirectory,  $False)
    
            $takeOnlyLimitedCountOfFiles = $compareResult | Select-Object -First $global:config.Sftp.BatchSize
    
            if ($takeOnlyLimitedCountOfFiles.Count -gt 0) {
                foreach($item in $takeOnlyLimitedCountOfFiles)
                {
                    if(!$item.IsDirectory)
                    {   
                        $file=Get-Item $item.Local.FileName                    
                        $currentTime = Get-Date -Format "dddd MM/dd/yyyy HH:mm"
                        $uploadMessage = "[$($currentTime)] uploading $($item.Local.FileName) to  $($global:config.Sftp.RemoteDirectory)"
    
                        $uploadedFileName = "$($global:config.Sftp.RemoteDirectory)/$($file.Name)"
                        Write-Host $uploadMessage
                        $session.PutFiles($item.Local.FileName, $uploadedFileName,$False)                    
                    }
                }
            }
            else {
                Write-Host "Nothing to upload"
            }
    
            # Throw on any error
            #$synchronizationResult.Check()
        }
        finally
        {
            # Disconnect, clean up
            $session.Dispose()
        }
     
        exit 0
    }
    catch
    {
        Write-Host "Error: $($_.Exception.Message)"
        #Send-Error-Log($_.Exception.Message)
        exit 1
    }
}

Upload-Contracts-Archive

