# Load WinSCP .NET assembly
Add-Type -Path "F:\WinSCP-5.17-Automation\WinSCPnet.dll"
 
$global:baseConfig = "new_contracts.json"
function FileTransferred {
    param($e)
 
    if ($e.Error -eq $Null) {
        Write-Host "Upload of $($e.FileName) succeeded"
    }
    else {
        Write-Host "Upload of $($e.FileName) failed: $($e.Error)"
    }
 
    if ($e.Chmod -ne $Null) {
        if ($e.Chmod.Error -eq $Null) {
            Write-Host "Permissions of $($e.Chmod.FileName) set to $($e.Chmod.FilePermissions)"
        }
        else {
            Write-Host "Setting permissions of $($e.Chmod.FileName) failed: $($e.Chmod.Error)"
        }
 
    }
    else {
        Write-Host "Permissions of $($e.Destination) kept with their defaults"
    }
 
    if ($e.Touch -ne $Null) {
        if ($e.Touch.Error -eq $Null) {
            Write-Host "Timestamp of $($e.Touch.FileName) set to $($e.Touch.LastWriteTime)"
        }
        else {
            Write-Host "Setting timestamp of $($e.Touch.FileName) failed: $($e.Touch.Error)"
        }
 
    }
    else {
        # This should never happen during "local to remote" synchronization
        Write-Host "Timestamp of $($e.Destination) kept with its default (current time)"
    }
}


try {
    $global:config = Get-Content "$baseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
}
catch {
    Write-Error -Message "Configuration file is missing!" -ErrorAction Stop
}

if (!($config)) {
    Write-Error -Message "Configuration file is missing!" -ErrorAction Stop
}

$contractFiles = Get-ChildItem -Path $global:config.Sftp.NewContractsDirectory -filter "*.pdf"  | Select-Object -First $global:config.Sftp.BatchSize

try {
    $sessionOptions = New-Object WinSCP.SessionOptions -Property @{
        Protocol                = [WinSCP.Protocol]::Sftp
        HostName                = $global:config.Sftp.HostName
        UserName                = $global:config.Sftp.UserName
        Password                = $global:config.Sftp.Password
        SshPrivateKeyPassphrase = $global:config.Sftp.Password
        SshHostKeyFingerprint   = $global:config.Sftp.SshHostKeyFingerprint
        SshPrivateKeyPath       = $global:config.Sftp.SshPrivateKeyPath            
    }
     
    $session = New-Object WinSCP.Session
    try {
        # Will continuously report progress of synchronization
        $session.add_FileTransferred( { FileTransferred($_) } )
     
        # Connect
        $session.Open($sessionOptions)
               
        foreach ($contractFile in $contractFiles) {            
            $currentTime = Get-Date -Format "dddd MM/dd/yyyy HH:mm"
            $uploadMessage = "[$($currentTime)] uploading $($contractFile.FullName) to  $($global:config.Sftp.RemoteDirectory)"

            $uploadedFileName = "$($global:config.Sftp.RemoteDirectory)/$($contractFile.Name)"
            Write-Host $uploadMessage
            $session.PutFiles($contractFile.FullName, $uploadedFileName, $False)
            Move-Item -Path $contractFile.FullName -Destination $global:config.Sftp.ContractsDirectory -Verbose *>> $($global:config.Sftp.LogFileFullPath)  
        }
           
    }
    finally {
        # Disconnect, clean up
        $session.Dispose()
    }
     
    exit 0
}
catch {
    Write-Host "Error: $($_.Exception.Message)"
    #Send-Error-Log($_.Exception.Message)
    exit 1
}
