#from __future__ import absolute_import, unicode_literals
import os
import time
import cv2
import base64
import json
import logging
from cmreslogging.handlers import CMRESHandler

from wrapt_timeout_decorator import *
from kombu import Connection, Queue
from kombu.mixins import ConsumerProducerMixin

from smart import matchByBytes

rpc_queue = Queue('new_patterns_matching_queue')

class Worker(ConsumerProducerMixin):

    def __init__(self, connection):
        self.connection = connection

    def get_consumers(self, Consumer, channel):
        return [Consumer(
            queues=[rpc_queue],
            on_message=self.on_request,
            accept={'application/json'},
            prefetch_count=1,
        )]

    def on_request(self, message):
        payload = json.loads(message.payload)
        contract_id = payload['contractId']
        patternContent = payload['patternContent']
        newPatternContent = payload['newPatternContent']

        pattern_img_data = base64.b64decode(patternContent)
        new_pattern_img_data = base64.b64decode(newPatternContent)

        try:
            log.info(f'New Contract got: {contract_id}')
            print(f'New Contract got: {contract_id}')
            score = matchByBytes(pattern_img_data,new_pattern_img_data, 0.6)
            result = {"score": score, "contractId": contract_id }
            print(f'Score: {score}')
        except BaseException as e:
            print("wyrabalo sie :[")
            log.info(f'Exception: {e}')
            with open("warning.png", "rb") as imageFile:
                file_in_base64 = base64.b64encode(imageFile.read())
                base64_string = file_in_base64.decode("utf-8")
                result = {"fileName": "warning", "content": base64_string}

        self.producer.publish(
            {'result': result },
            exchange='', routing_key=message.properties['reply_to'],
            correlation_id=message.properties['correlation_id'],
            serializer='json',
            retry=True,
        )
        message.ack()


def main():
    user = os.getenv('RABBIT_USER', 'rabbitmq')
    password = os.getenv('RABBIT_PASSWORD', 'rabbitmq')
    hostname = os.getenv('RABBIT_HOSTNAME', 'localhost')
    port = int(os.getenv('RABBIT_PORT', '5672'))

    connection = Connection(hostname=hostname, userid=user, password=password, port=port)
    log.info('[Contract Matching] Awaiting KOMBU CONTRACT MATCHING requests')
    print('[Contract Matching] Awaiting KOMBU CONTRACT MATCHING requests')
    worker = Worker(connection)
    worker.run()


logging.basicConfig(level=logging.INFO, filename='../smart_contract_matching_server/app.log', filemode='w',
                    format='%(name)s - %(levelname)s - %(message)s')
log = logging.getLogger("smart_contract_server_kombu")

handler = CMRESHandler(hosts=[{'host': os.getenv('ELASTICSEARCH_HOST', "rabbitmq"), 'port': 9200}],
                           auth_type=CMRESHandler.AuthType.BASIC_AUTH,
                           auth_details=('elastic', os.getenv('KIBANA_PASSWORD', "rabbitmq")),
                           use_ssl=True,
                           verify_ssl=False,
                           es_index_name="smartcontractrpc")
log.addHandler(handler)

if __name__ == '__main__':
    main()
