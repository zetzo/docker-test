import os
from kombu import Connection, Queue

rpc_queue = Queue('contracts_matching_queue')

user = os.getenv('RABBIT_USER', 'rabbitmq')
password = os.getenv('RABBIT_PASSWORD', 'rabbitmq')
hostname = os.getenv('RABBIT_HOSTNAME', 'localhost')
port = int(os.getenv('RABBIT_PORT', '5672'))

connection = Connection(hostname=hostname, userid=user, password=password, port=port)

try:
    print(f'trying to connect : {connection}')
    print(f'user : {user}')
    print(f'password : {password}')
    print(f'hostname : {hostname}')
    connection.connect()
    print(f'connected')
except BaseException as e:
    print(f"{e}")

