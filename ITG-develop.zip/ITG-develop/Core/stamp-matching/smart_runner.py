import os
import sys
import time
from smart import match

# if len(sys.argv) == 1:
#     sys.exit("[Error] Please provide input arguments:  (1) imagefile (2) patternfile (3) distance default = 0.6")

#image_file = sys.argv[2]
#pattern_file = sys.argv[1]
#print(sys.argv)

distance = 0.6
pattern_file = "f:\\LS-54274.png"
image_file = "f:\\page1.png"

imageFileExists = os.path.exists(image_file)
patternFileExists = os.path.exists(pattern_file)

if imageFileExists == False:
    sys.exit("Image File not found")
elif patternFileExists == False:
    sys.exit("Pattern File not found")

print("******************Matching Started******************")

start_time = time.time()

score = match(pattern_file, image_file, 0.6)

elapsed_time = time.time() - start_time

print("score : \n", score)
#print("time : {0} s".format(elapsed_time))
