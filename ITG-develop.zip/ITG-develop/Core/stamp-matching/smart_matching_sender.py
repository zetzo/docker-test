import base64

import pika
import sys
import json
import os

def read_file_to_base64(filename):
    with open(filename, "rb") as image_file:
        data = base64.b64encode(image_file.read())

    return data


def get_json_from_files(patternFile, imageFile, contractId):
    patternContent = read_file_to_base64(patternFile)
    closingDocumentContent = read_file_to_base64(imageFile)
    return {"contractId": contractId, "fileName": imageFile, "patternContent": patternContent,
            "closingDocumentContent": closingDocumentContent}


def send(message):
    credentials = pika.PlainCredentials("rabbitmq", "rabbitmq")
    print(credentials)
    connection = pika.BlockingConnection(pika.ConnectionParameters(
        "localhost",
        5672,
        "/",
        credentials))
    print(connection)
    channel = connection.channel()
    print(channel)

    channel.queue_declare("patterns_matching_queue", durable=True)
    # channel.queue_bind(exchange='matching',
    #                    queue="patterns_matching_queue")

    channel.basic_publish(exchange='matching', routing_key='patterns_matching_queue', body=message)
    # print(" [x] Sent %r" % message)
    connection.close()


print(pika.__version__)

patternfile = sys.argv[1]
imagefile = sys.argv[2]
input_message = json.dumps(get_json_from_files(patternfile, imagefile, "LS-48000"))

send(input_message)
