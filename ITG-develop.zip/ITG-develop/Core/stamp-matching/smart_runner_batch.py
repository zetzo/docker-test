import os
import sys
import time
from smart import match
from smart import match_with_img_result
import csv
import cv2
import shutil
from matplotlib import pyplot as plt

# input_dir_name = sys.argv[1]
# it_logo_path = sys.argv[2]
# output_dir_name = sys.argv[3]
# csv_output_path = sys.argv[4]

input_dir_name = "F:\smart\pairs"

listOfDirs = os.listdir(input_dir_name)

scores = []


def export_to_csv(array, file_name):
    with open(file_name, 'w') as f:
        writer = csv.writer(f)
        for row in array:
            writer.writerow(row)


def apply_brightness_contrast(input_img, brightness=0, contrast=0):
    if brightness != 0:
        if brightness > 0:
            shadow = brightness
            highlight = 255
        else:
            shadow = 0
            highlight = 255 + brightness
        alpha_b = (highlight - shadow) / 255
        gamma_b = shadow

        buf = cv2.addWeighted(input_img, alpha_b, input_img, 0, gamma_b)
    else:
        buf = input_img.copy()

    if contrast != 0:
        f = 131 * (contrast + 127) / (127 * (131 - contrast))
        alpha_c = f
        gamma_c = 127 * (1 - f)

        buf = cv2.addWeighted(buf, alpha_c, buf, 0, gamma_c)

    return buf


def show_rgb_equalized(image):
    channels = cv2.split(image)
    eq_channels = []
    for ch, color in zip(channels, ['B', 'G', 'R']):
        eq_channels.append(cv2.equalizeHist(ch))

    eq_image = cv2.merge(eq_channels)
    eq_image = cv2.cvtColor(eq_image, cv2.COLOR_BGR2RGB)
    plt.imshow(eq_image)
    plt.show()


def show_hsv_equalized(image):
    H, S, V = cv2.split(cv2.cvtColor(image, cv2.COLOR_BGR2HSV))
    #eq_V = cv2.equalizeHist(V)
    #eq_image = cv2.cvtColor(cv2.merge([H, S, eq_V]), cv2.COLOR_HSV2RGB)
    eq_S = cv2.equalizeHist(S)
    #eq_image = cv2.cvtColor(cv2.merge([H, eq_S, V]), cv2.COLOR_HSV2RGB)
    #eq_H = cv2.equalizeHist(H)
    eq_image = cv2.cvtColor(cv2.merge([H, eq_S, V]), cv2.COLOR_HSV2RGB)

    plt.imshow(eq_image)
    plt.show()
    return eq_image
    #plt.imshow(eq_image)
    #plt.show()


def process():
    for dir in listOfDirs:
        full_path = os.path.join(input_dir_name, dir)
        pattern_file = ""
        contract_file = ""
        contract_files = []

        for file in os.listdir(full_path):
            child_path = os.path.join(input_dir_name, file)
            if file == dir + ".png":
                pattern_file = os.path.join(full_path, file)
            else:
                contract_file = os.path.join(full_path, file)
                contract_files.append(contract_file)

        print("pattern " + pattern_file)
        #print("contract " + contract_file)
        #for contract_file in contract_files:
            #print(contract_file)

        for contract_file in contract_files:
            score, out = match_with_img_result(pattern_file, contract_file, 0.6)
            #score = 1
            path1 = os.path.basename(contract_file)
            result_file = os.path.join(full_path,  str(score) + "_" + path1)
            #print("result " + result_file)
            cv2.imwrite(result_file, out)

process()
#img = cv2.imread('F:/beforec/51232/VERSO_ZD_LS-51232_01.07.18-30.09.18.png')
#out = show_hsv_equalized(img)
#cv2.imshow('New Image', out)
# Wait until user press some key
#cv2.waitKey()

#score, out = match_with_img_result('F:/smart/pairs/LS-61661/LS-61661.png', 'F:/smart/pairs/LS-61661/LS-61661_c.png', 0.6)
#cv2.imshow('New Image', out)
#print(score)
#cv2.imwrite('F:/smart/pairs/LS-61661/result.png', out)
# Wait until user press some key
#cv2.waitKey()
#print(score)

# new_image = cv2.convertScaleAbs(img, 3, 0.9)

# new_image = apply_brightness_contrast(img,0,-10)

# cv2.imwrite('f:/cos.png', new_image)

# cv2.imshow('Original Image', img)
# cv2.imshow('New Image', new_image)
# Wait until user press some key
# cv2.waitKey()

# double
# beta = (1.0 - alpha);
# cv::addWeighted(inFrame, alpha, black, beta, 0.0);
