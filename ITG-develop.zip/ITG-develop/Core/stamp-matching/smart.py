import cv2
import numpy as np
from matplotlib import pyplot as plt


def match_with_img_result(pattern_file_name, image_file_name, distance):
    print("pattern file: ", pattern_file_name)
    print("image file: ", image_file_name)
    pattern = cv2.imread(pattern_file_name, 0)  # queryImage
    img = cv2.imread(image_file_name, 0)  # trainImage

    # Initiate KAZE detector
    sift = cv2.KAZE_create()

    # find the keypoints and descriptors with SIFT
    kp1, des1 = sift.detectAndCompute(pattern, None)
    kp2, des2 = sift.detectAndCompute(img, None)
    # FLANN parameters
    FLANN_INDEX_KDTREE = 0
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)  # or pass empty dictionary
    flann = cv2.FlannBasedMatcher(index_params, search_params)
    matches = flann.knnMatch(des1, des2, k=2)
    # Need to draw only good matches, so create a mask
    score = 0
    matchesMask = [[0, 0] for i in range(len(matches))]
    # ratio test as per Lowe's paper
    for i, (m, n) in enumerate(matches):
        if m.distance < distance * n.distance:
            matchesMask[i] = [1, 0]
            score += 1

    draw_params = dict(matchColor=(0, 255, 0),
                       singlePointColor=(255, 0, 0),
                       matchesMask=matchesMask,
                       flags=0)

    img_result = cv2.drawMatchesKnn(pattern, kp1, img, kp2, matches, None, **draw_params)

    return score, img_result


def match(patternfile, imagefile, distance):
    print("image file: ", imagefile)
    print("pattern file: ", patternfile)

    img1 = cv2.imread(patternfile, 0)  # queryImage

    if type(imagefile) == str:
        img2 = cv2.imread(imagefile, 0)  # trainImage
    else:
        img2 = imagefile
    # img2 = cv2.convertScaleAbs(img2, 1, 0.9)

    # Initiate SIFT detector
    sift = cv2.KAZE_create()

    # find the keypoints and descriptors with SIFT
    kp1, des1 = sift.detectAndCompute(img1, None)
    kp2, des2 = sift.detectAndCompute(img2, None)
    # FLANN parameters
    FLANN_INDEX_KDTREE = 0
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)  # or pass empty dictionary
    flann = cv2.FlannBasedMatcher(index_params, search_params)
    matches = flann.knnMatch(des1, des2, k=2)
    # Need to draw only good matches, so create a mask
    score = 0
    matchesMask = [[0, 0] for i in range(len(matches))]
    # ratio test as per Lowe's paper
    for i, (m, n) in enumerate(matches):
        if m.distance < distance * n.distance:
            matchesMask[i] = [1, 0]
            score += 1

    draw_params = dict(matchColor = (0,255,0),
                 singlePointColor = (255,0,0),
                 matchesMask = matchesMask,
                 flags = 0)

    img3 = cv2.drawMatchesKnn(img1,kp1,img2,kp2,matches,None,**draw_params)
    plt.imsave("result.png",img3,dpi=300)

    return score


def matchByBytes(patternfile, imagefile, distance):
    pattern_file_array = np.fromstring(patternfile, np.uint8)
    pattern = cv2.imdecode(pattern_file_array, cv2.IMREAD_UNCHANGED)
    img_array = np.fromstring(imagefile, np.uint8)
    img = cv2.imdecode(img_array, cv2.IMREAD_UNCHANGED)

    sift = cv2.KAZE_create()
    kp1, des1 = sift.detectAndCompute(pattern, None)
    kp2, des2 = sift.detectAndCompute(img, None)

    FLANN_INDEX_KDTREE = 0
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)  # or pass empty dictionary
    flann = cv2.FlannBasedMatcher(index_params, search_params)
    matches = flann.knnMatch(des1, des2, k=2)

    score = 0
    matchesMask = [[0, 0] for i in range(len(matches))]

    for i, (m, n) in enumerate(matches):
        if m.distance < distance * n.distance:
            matchesMask[i] = [1, 0]
            score += 1

    # draw_params = dict(matchColor=(0, 255, 0),
    #                    singlePointColor=(255, 0, 0),
    #                    matchesMask=matchesMask,
    #                    flags=0)
    #
    # img3 = cv2.drawMatchesKnn(pattern, kp1, img, kp2, matches, None, **draw_params)
    # plt.imsave("/smart/global/result.png", img3)
    #plt.imsave("f:\\result.png", img3)
    return score
