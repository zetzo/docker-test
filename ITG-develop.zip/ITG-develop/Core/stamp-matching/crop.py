import cv2
import numpy as np
import os
import shutil

def save_file(bytes,destfile):
    w = open(destfile, 'wb')
    w.write(bytes)
    w.close()

def cut_out(img, final):
    x, y, w, h = cv2.boundingRect(final)
    dst = img[y:y + h, x:x + w]
    _, _bytes = cv2.imencode('.png', dst)
    return _bytes

def crop_the_biggest(img_array):
    img = cv2.imdecode(img_array, cv2.IMREAD_ANYCOLOR)
    imgArray = []
    ## (1) Convert to gray, and threshold
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    th, threshed = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)

    ## (2) Morph-op to remove noise
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11,11))
    morphed = cv2.morphologyEx(threshed, cv2.MORPH_CLOSE, kernel)

    ## (3) Find the max-area contour
    cnts = cv2.findContours(morphed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
    cnt = sorted(cnts, key=cv2.contourArea)
    print(len(cnt))
    final1 = cnt[-1]
    final2 = cnt[-2]
    final3 = cnt[-3]

    imgArray.append(cut_out(img, final1))
    imgArray.append(cut_out(img, final2))
    imgArray.append(cut_out(img, final3))
    return imgArray
    # x1, y1, w1, h1 = cv2.boundingRect(final1)
    # x2, y2, w2, h2 = cv2.boundingRect(final2)
    #
    # diff1 = min([w1, h1], key=abs)
    # diff2 = min([w2, h2], key=abs)
    #
    # if x1 > x2:
    #     x, y, w, h = cv2.boundingRect(final1)
    #     dst = img[y:y + h, x:x + w]
    #     _, _bytes = cv2.imencode('.png', dst)
    #     return _bytes
    # else:
    #     x, y, w, h = cv2.boundingRect(final2)
    #     dst = img[y:y + h, x:x + w]
    #     _, _bytes = cv2.imencode('.png', dst)
    #     return _bytes


    ## (4) Crop and save it

    #cv2.imwrite(output_file_name, dst)

dest_dir_name = r"f:/files4";
listOfDirs = os.listdir(r"f:/files3")
for file in listOfDirs:
     sourcefile = os.path.join(os.sep, r"f:/files3", file)
     destfile = os.path.join(dest_dir_name, file)
     file_exists = os.path.exists(sourcefile)
     print(file_exists)
     f = open(sourcefile, "rb");
     img_in_bytes = f.read()
     img_array = np.frombuffer(img_in_bytes, np.uint8)
     bytesOfBytes = crop_the_biggest(img_array)
     i = 1
     print(bytesOfBytes)
     for bytes in bytesOfBytes:
        destfile = os.path.splitext(file)[0] + str(i) + ".PNG"
        destfileNext = os.path.join(dest_dir_name, destfile)
        save_file(bytes, destfileNext)
        i+=1


# f = open('f:/files3/А.С.А.Контракт_ЛС-7023Прил.1-3.PNG', "rb");
# img_in_bytes = f.read()
# img_array = np.frombuffer(img_in_bytes, np.uint8)
# bytes = crop_the_biggest(img_array)
# w = open('f:/files4/dupa.png', 'wb')
# w.write(bytes)
# w.close()