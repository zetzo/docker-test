import base64

import pika
import sys
import json
import os

def on_request(ch, method, properties, body):
    print("Message got")
    data = json.loads(body)
    score = data["score"]
    contractId = data["contractId"]
    fileName = data["fileName"]
    result = {"score": score, "fileName": fileName, "contractId": contractId}
    print(json.dumps(result))

try:
    print(pika.__version__)

    credentials = pika.PlainCredentials("rabbitmq", "rabbitmq")
    print(credentials)
    connection = pika.BlockingConnection(pika.ConnectionParameters(
        "localhost",
        5672,
        "/",
        credentials))
    print(connection)
    channel = connection.channel()
    #print(channel)
    channel.exchange_declare(exchange='matching', exchange_type='direct',durable=True)
    channel.queue_declare("patterns_matching_outcome", durable=True)
    channel.queue_bind(exchange='matching', queue='patterns_matching_outcome')
    channel.basic_consume("patterns_matching_outcome", on_message_callback=on_request, auto_ack=False)
    print("[x] Awaiting Matching response")
    channel.start_consuming()
except:
    print("Oops!", sys.exc_info(), "occured.")