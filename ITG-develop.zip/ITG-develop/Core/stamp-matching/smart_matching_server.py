import pika
import sys
import json
import base64
import os
import logging
from smart import matchByBytes
from cmreslogging.handlers import CMRESHandler


def on_request(ch, method, properties, body):
    data = json.loads(body)
    contractId = data["contractId"]
    fileName = data["fileName"]
    log.info(f'Received filename: {fileName}')
    patternContent = base64.b64decode(data["patternContent"])
    closingDocumentContent = base64.b64decode(data["closingDocumentContent"])
    try:
        score = matchByBytes(patternContent, closingDocumentContent, 0.6)
        log.info(f'Score: {score} fileName: {fileName}')
        result = {"score": score, "fileName": fileName, "contractId": contractId}
        ch.basic_ack(delivery_tag=method.delivery_tag)
        send(json.dumps(result))
    except BaseException as e:
        result = {"score": -1, "contractId": contractId, "fileName": fileName}
        send(json.dumps(result))


def send(message):
    try:
        log.info(f'Message prepared: {message}')
        connection = get_rabbit_connection();
        log.info('Connected!')
        channel = connection.channel()
        log.info(f'Trying send message {message} to queue patterns_matching_outcome')
        channel.queue_declare("patterns_matching_outcome", durable=True)
        channel.queue_bind(exchange='matching', queue='patterns_matching_outcome')
        channel.basic_publish(exchange='matching', routing_key='patterns_matching_outcome', body=message)
        connection.close()
    except:
        logging.critical(f'Oops! {sys.exc_info()} occured.')


def get_rabbit_connection():
    log.info('Get connection to RabbitMq')
    credentials = pika.PlainCredentials(os.getenv('RABBIT_USER', "rabbitmq"), os.getenv('RABBIT_PASSWORD', "rabbitmq"))
    return pika.BlockingConnection(pika.ConnectionParameters(
        host=os.getenv('RABBIT_HOSTNAME', "localhost"),
        port=os.getenv('RABBIT_PORT', "5672"),
        virtual_host="/",
        credentials=credentials))


while True:
    try:
        logging.basicConfig(level=logging.INFO, filename='app.log', filemode='w',
                            format='%(name)s - %(levelname)s - %(message)s')
        log = logging.getLogger("smart_matching_server")

        handler = CMRESHandler(hosts=[{'host': os.getenv('ELASTICSEARCH_HOST', "rabbitmq"), 'port': 9200}],
                               auth_type=CMRESHandler.AuthType.BASIC_AUTH,
                               auth_details=('elastic', os.getenv('KIBANA_PASSWORD', "rabbitmq")),
                               use_ssl=True,
                               verify_ssl=False,
                               es_index_name="smartmatching")

        log.addHandler(handler)
        connection = get_rabbit_connection()
        channel = connection.channel()
        channel.exchange_declare(exchange='matching', exchange_type='direct', durable=True)
        channel.queue_declare("patterns_matching_queue", durable=True)
        channel.queue_bind(exchange='matching', queue='patterns_matching_queue')
        channel.basic_consume("patterns_matching_queue", on_message_callback=on_request, auto_ack=False)
        channel.basic_qos(prefetch_count=1)
        log.info('Awaiting Matching requests')
        print("[x] Awaiting Matching requests")
        channel.start_consuming()
    except:
        log.critical(f'Oops! {sys.exc_info()} occured.')
        continue
        # print("Oops!", sys.exc_info(), "occured.")
