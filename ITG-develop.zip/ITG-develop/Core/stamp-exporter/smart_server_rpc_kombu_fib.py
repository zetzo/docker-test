#from __future__ import absolute_import, unicode_literals
import os
import time
import lib_test

from wrapt_timeout_decorator import *
from kombu import Connection, Queue
from kombu.mixins import ConsumerProducerMixin

rpc_queue = Queue('rpc_queue')

class Worker(ConsumerProducerMixin):

    def __init__(self, connection):
        self.connection = connection

    def get_consumers(self, Consumer, channel):
        return [Consumer(
            queues=[rpc_queue],
            on_message=self.on_request,
            accept={'application/json'},
            prefetch_count=1,
        )]

    def on_request(self, message):
        n = message.payload['n']
        print(' [.] fib({0})'.format(n))
        result = 1

        try:
            print("start")
            print(type(n))
            lib_test.mytest(int(n))
            print("End")
            #timeout(dec_timeout=5)(fib)(n)
        except BaseException as e:
            print(e)
        finally:
            retult = -1

        self.producer.publish(
            {'result': result},
            exchange='', routing_key=message.properties['reply_to'],
            correlation_id=message.properties['correlation_id'],
            serializer='json',
            retry=True,
        )
        message.ack()


def start_worker(broker_url):
    connection = Connection(broker_url)
    print(' [x] Awaiting RPC requests')
    worker = Worker(connection)
    worker.run()

def main():
    time.sleep(5)
    user = os.getenv('RABBIT_USER', 'rabbitmq')
    password = os.getenv('RABBIT_PASSWORD', 'rabbitmq')
    hostname = os.getenv('RABBIT_HOSTNAME', 'localhost')
    port = 5672

    connection = Connection(hostname=hostname, userid=user, password=password, port=port)
    print(' [x] Awaiting RPC requests')
    worker = Worker(connection)
    worker.run()


if __name__ == '__main__':
    main()

#fib(5)