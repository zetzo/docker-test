import pika
import json
import os
import sys
import base64
import cv2
import numpy as np
import signal
import time
import wt

from pattern_exporter import process_one_pattern_from_mat_for_addendum

def main():
    img_data = cv2.imread('bad.PNG', cv2.IMREAD_COLOR)
    img2 = wt.pattern_extract_wt(img_data)

    # try:
    #     img2 = process_one_pattern_from_mat_for_addendum(img_data, False)
    # except TimeoutError as t:
    #     print(t)

#out_data = process_one_pattern_from_mat_for_addendum(img_data,True)

if __name__ == '__main__':
    main()