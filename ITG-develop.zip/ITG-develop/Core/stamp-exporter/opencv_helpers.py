import cv2
import numpy as np


def set_border(img, bordersize):
    row, col = img.shape[:2]
    bottom = img[row - 2:row, 0:col]
    mean = cv2.mean(bottom)[0]

    border = cv2.copyMakeBorder(
        img,
        top=bordersize,
        bottom=bordersize,
        left=bordersize,
        right=bordersize,
        borderType=cv2.BORDER_CONSTANT,
        value=[mean, mean, mean]
    )
    return border


def ResizeWithAspectRatio(image, width=None, height=None, inter=cv2.INTER_AREA):
    dim = None
    (h, w) = image.shape[:2]

    if width is None and height is None:
        return image
    if width is None:
        r = height / float(h)
        dim = (int(w * r), height)
    else:
        r = width / float(w)
        dim = (width, int(h * r))

    return cv2.resize(image, dim, interpolation=inter)


def detect_circles(bgr_img, oimg, radius=120, show=False):
    # print("detect circle")
    horg = oimg.shape[0]
    worg = oimg.shape[1]
    retcircles = []
    maxes = []

    if bgr_img is not None:
        if bgr_img.shape[-1] == 3:  # color image
            b, g, r = cv2.split(bgr_img)  # get b,g,r
            rgb_img = cv2.merge([r, g, b])  # switch it to rgb
            gray_img = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2GRAY)
        else:
            gray_img = bgr_img

        img = cv2.medianBlur(gray_img, 5)
        cimg = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

        circles = cv2.HoughCircles(img, cv2.HOUGH_GRADIENT, 1, 90, param1=20, param2=30, minRadius=90, maxRadius=360)

        # print("ilosc kolek")
        # print(circles)
        if circles is not None:
            circles = np.uint16(np.around(circles))
            for c in circles[0, :]:
                if show:
                    # cv2.circle(cimg, (c[0], c[1]), c[2], (0, 0, 255), -1)
                    cv2.circle(cimg, (c[0], c[1]), c[2], (0, 0, 255), 1)
                    resize = ResizeWithAspectRatio(cimg, width=600)
                    cv2.imshow('Image', resize)
                    cv2.waitKey(0)

                a1 = np.round(c[0]).astype("int")
                b1 = np.round(c[1]).astype("int")
                dr = np.round(c[2]).astype("int")

                p = (a1, b1, dr)

                retcircles.append(p)

        return retcircles


def detect_circles_for_addendum(bgr_img, oimg, radius=120, show=False):
    # print("detect circle")
    horg = oimg.shape[0]
    worg = oimg.shape[1]
    retcircles = []
    maxes = []

    if bgr_img is not None:
        if bgr_img.shape[-1] == 3:  # color image
            b, g, r = cv2.split(bgr_img)  # get b,g,r
            rgb_img = cv2.merge([r, g, b])  # switch it to rgb
            gray_img = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2GRAY)
        else:
            gray_img = bgr_img

        img = cv2.medianBlur(gray_img, 5)
        cimg = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

        circles = cv2.HoughCircles(img, cv2.HOUGH_GRADIENT, 1, 90, param1=20, param2=30, minRadius=90, maxRadius=360)

        if circles is not None:
            circles = np.uint16(np.around(circles))
            for c in circles[0, :]:
                if show:
                    # cv2.circle(cimg, (c[0], c[1]), c[2], (0, 0, 255), -1)
                    cv2.circle(cimg, (c[0], c[1]), c[2], (0, 0, 255), 1)
                    resize = ResizeWithAspectRatio(cimg, width=600)
                    cv2.imshow('Image', resize)
                    cv2.waitKey(0)

                a1 = np.round(c[0]).astype("int")
                b1 = np.round(c[1]).astype("int")
                dr = np.round(c[2]).astype("int")

                p = (a1, b1, dr)

                retcircles.append(p)

        return retcircles


def sort_contours(cnts, method="left-to-right"):
    # initialize the reverse flag and sort index
    reverse = False
    i = 0

    # handle if we need to sort in reverse
    if method == "right-to-left" or method == "bottom-to-top":
        reverse = True

    # handle if we are sorting against the y-coordinate rather than
    # the x-coordinate of the bounding box
    if method == "top-to-bottom" or method == "bottom-to-top":
        i = 1

    # construct the list of bounding boxes and sort them from top to
    # bottom
    boundingBoxes = [cv2.boundingRect(c) for c in cnts]
    (cnts, boundingBoxes) = zip(*sorted(zip(cnts, boundingBoxes),
                                        key=lambda b: b[1][i], reverse=reverse))

    # return the list of sorted contours and bounding boxes
    return (cnts, boundingBoxes)


def get_contours(arg_frame, arg_binaryMethod=1):
    # Otsu's thresholding after Gaussian filtering
    arg_frame = hsv_equalized(arg_frame)

    tmp = cv2.cvtColor(arg_frame, cv2.COLOR_RGB2GRAY)
    blur = gaussian_blur(tmp)
    gradX, gradY, blur = sobel_gradient(blur)
    # thresh = Thresh_and_blur(blur)
    # cv2.imshow("Output", thresh)
    # cv2.waitKey(0)

    if arg_binaryMethod == 0:
        ret, thresholdedImg = cv2.threshold(blur.copy(), 128, 255, 0)
    elif arg_binaryMethod == 1:
        ret, thresholdedImg = cv2.threshold(blur.copy(), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    elif arg_binaryMethod == 2:
        thresholdedImg = cv2.adaptiveThreshold(blur.copy(), 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 5,
                                               0)

    result = cv2.cvtColor(thresholdedImg, cv2.COLOR_GRAY2RGB)
    ctrs, hier = cv2.findContours(thresholdedImg, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    ctrs, boundingBoxes = sort_contours(ctrs, "left-to-right")

    rects = [[cv2.boundingRect(ctr), ctr] for ctr in ctrs]

    for rect, ctrs in rects:
        cv2.drawContours(result, [ctrs], 0, (0, 128, 255), 3)

    if result is not None:
        return result
    else:
        return arg_frame


def gaussian_blur(gray):  # Gaussian denoising (remove noise in the image)
    """
    Gaussian blur is essentially a low pass filter:
    Each pixel of the output image is the weighted sum of the corresponding pixel on the original image and the surrounding pixels.

    Dimensions and standard deviations of Gaussian matrices:
    (9, 9) indicates the length and width of the Gaussian matrix. When the standard deviation is 0, OpenCV calculates itself according to the size of the Gaussian matrix.
    The larger the size of the Gaussian matrix, the larger the standard deviation, and the greater the degree of blurring of the processed image.
    """
    blurred = cv2.GaussianBlur(gray, (9, 9), 0)
    return blurred


def sobel_gradient(blurred):
    """
        Sobelian operator to calculate the gradient in the x and y directions
        For the operator, please check: https://blog.csdn.net/wsp_1138886114/article/details/81368890
    """
    gradX = cv2.Sobel(blurred, ddepth=cv2.CV_32F, dx=1, dy=0)
    gradY = cv2.Sobel(blurred, ddepth=cv2.CV_32F, dx=0, dy=1)
    gradient = cv2.subtract(gradX, gradY)
    gradient = cv2.convertScaleAbs(gradient)
    return gradX, gradY, gradient


def thresh_and_blur(gradient):  # threshold
    blurred = cv2.GaussianBlur(gradient, (9, 9), 0)
    (_, thresh) = cv2.threshold(blurred, 90, 255, cv2.THRESH_BINARY)
    """
         Cv2.threshold(src,thresh,maxval,type[,dst])->retval,dst (grayscale of binary values)
         Src: general input grayscale
       Thresh: threshold,
       Maxval: in the binary threshold THRESH_BINARY and
              The maximum value used in the inverse binary threshold THRESH_BINARY_INV 
       Type: the type of threshold used
         Return value retval is actually the threshold 
      """
    return thresh


def hsv_equalized(image):
    H, S, V = cv2.split(cv2.cvtColor(image, cv2.COLOR_BGR2HSV))

    eq_S = cv2.equalizeHist(S)
    eq_image = cv2.cvtColor(cv2.merge([H, eq_S, V]), cv2.COLOR_HSV2RGB)
    return eq_image


def image_morphology(thresh):
    """
         Create an elliptic kernel function
         Perform image morphology, check the documentation directly, it's very simple
    """
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25))
    closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
    closed = cv2.erode(closed, None, iterations=4)
    closed = cv2.dilate(closed, None, iterations=4)
    return closed
