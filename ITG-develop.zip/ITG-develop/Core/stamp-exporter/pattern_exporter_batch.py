import sys
import os
import shutil
import logging
import cv2

def input_main():
    input_dir_name = sys.argv[1]
    output_dir_name = sys.argv[2]
    # template_path = sys.argv[3]

    listOfFile = os.listdir(input_dir_name)

    for file in listOfFile:
        full_file_name = os.path.join(input_dir_name, file)
        output_file_name = os.path.join(output_dir_name, file)
        file_exists = os.path.exists(full_file_name)
        if file_exists:
            print(full_file_name)

            outcome = process_one_pattern(full_file_name)

            file_name = os.path.splitext(os.path.basename(full_file_name))[0] + ".png"
            dest = os.path.join(output_dir_name, file_name)

            cv2.imwrite(dest, outcome)

            is_valid = validate_img(dest)
            if is_valid is not True:
                error_file_name = os.path.join("f:/errors", file_name)
                shutil.copyfile(dest, error_file_name)
        else:
            print(full_file_name)
            print("no file in address")


logging.basicConfig(format='%(asctime)s %(message)s', datefmt='%d/%m/%Y %I:%M:%S %p', level=logging.DEBUG)

logging.info('[SMART] PATTERN EXPORTER STARTED')
# testOne()
# input_main()
logging.info('[SMART] PATTERN EXPORTER ENDED')
