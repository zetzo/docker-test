import sys
import os
import cv2
from PIL import Image
import shutil
import logging
import numpy as np

from opencv_helpers import set_border
from opencv_helpers import get_contours
from opencv_helpers import detect_circles
from opencv_helpers import detect_circles_for_addendum


def validate_img(image_path):
    try:
        img = Image.open(image_path)  # open the image file
        img.verify()  # verify that it is, in fact an image
        return True
    except (IOError, SyntaxError) as e:
        # print('Bad file:', image_path)  # print out the names of corrupt files
        return False


def cut_circles(circles, org):
    # print(circles)
    right = max(circles, key=lambda circle: circle[0] + circle[2])
    left = min(circles, key=lambda circle: circle[0] - circle[2])
    top = min(circles, key=lambda circle: circle[1] - circle[2])
    bottom = max(circles, key=lambda circle: circle[1] + circle[2])

    ratio = 40

    x1 = abs((left[0] - left[2])) - ratio
    y1 = abs((top[1] - top[2])) - ratio

    w = (right[0] + right[2]) - x1 + ratio
    h = (bottom[1] + bottom[2]) - y1 + ratio

    copy1 = org.copy()

    horg = org.shape[0]
    worg = org.shape[1]

    # print(x1, y1)

    if x1 < 0:
        x1 = 0

    if y1 < 0:
        y1 = 0

    if y1 + h > horg:
        h = horg

    if x1 + w > worg:
        w = worg

    # print(x1, y1)
    # print(x1+w, y1+h)

    crop = copy1[y1:y1 + h, x1:x1 + w]
    return crop


def testOne():
    org = cv2.imread('F:/smart/opencv/51247.png')
    # org = set_border(org, 150)
    # cv2.imshow('Image', org)
    # cv2.waitKey(0)

    img = get_contours(org, 1)

    circles = detect_circles(img, org, 240, show=True)
    if len(circles) > 0:
        crop = cut_circles(circles, org)
        print("wyciete")

        if crop is not None:
            cv2.imshow('Image', crop)
            cv2.waitKey(0)
        else:
            print("error")


def process_one_pattern(image_path):
    org = cv2.imread(image_path)

    img = get_contours(org, 1)

    circles = detect_circles(img, org, 240, show=False)
    if len(circles) > 0:
        crop = cut_circles(circles, org)
        return crop
    else:
        return org


def process_one_pattern_from_bytes(img_in_bytes):
    img_array = np.frombuffer(img_in_bytes, np.uint8)
    img = cv2.imdecode(img_array, cv2.IMREAD_ANYCOLOR)

    # template = cv2.imread('itg.png', cv2.IMREAD_COLOR)
    # img = remove_logo(img, template)

    img_with_contours = get_contours(img)
    circles = detect_circles(img_with_contours, img, 240, show=False)
    if len(circles) > 0:
        crop = cut_circles(circles, img)
        _, _bytes = cv2.imencode('.png', crop)
        return _bytes
    else:
        _, _bytes = cv2.imencode('.png', img)
        return _bytes


def process_one_pattern_from_mat(img):
    # template = cv2.imread('itg.png', cv2.IMREAD_COLOR)
    # img = remove_logo(img, template)

    img_with_contours = get_contours(img)
    circles = detect_circles(img_with_contours, img, 240, show=False)
    if len(circles) > 0:
        crop = cut_circles(circles, img)
        _, _bytes = cv2.imencode('.png', crop)
        return _bytes
    else:
        _, _bytes = cv2.imencode('.png', img)
        return _bytes


def imcrop(img, bbox):
    x1, y1, x2, y2 = bbox
    if x1 < 0 or y1 < 0 or x2 > img.shape[1] or y2 > img.shape[0]:
        img, x1, x2, y1, y2 = pad_img_to_fit_bbox(img, x1, x2, y1, y2)
    return img[y1:y2, x1:x2, :]


def pad_img_to_fit_bbox(img, x1, x2, y1, y2):
    img = np.pad(img, ((np.abs(np.minimum(0, y1)), np.maximum(y2 - img.shape[0], 0)),
                       (np.abs(np.minimum(0, x1)), np.maximum(x2 - img.shape[1], 0)), (0, 0)), mode="constant")
    y1 += np.abs(np.minimum(0, y1))
    y2 += np.abs(np.minimum(0, y1))
    x1 += np.abs(np.minimum(0, x1))
    x2 += np.abs(np.minimum(0, x1))
    return img, x1, x2, y1, y2


def cut_circles_for_addendum(circles, img):
    crop = img.copy()
    for c in circles:
        x = c[0]
        y = c[1]
        r = c[2]
        if r > 200:
            org = img.copy()
            x1 = x - r
            y1 = y - r
            x2 = x + r
            y2 = y + r
            if x1 > 0 and y1 > 0 and x2 > 0 and y2 > 0:
                crop = imcrop(org, (x1, y1, x2, y2))
                break
    return crop


def process_one_pattern_from_mat_for_addendum_bytes(img_in_bytes, show=False):
    img_array = np.frombuffer(img_in_bytes, np.uint8)
    img = cv2.imdecode(img_array, cv2.IMREAD_ANYCOLOR)

    img_with_contours = get_contours(img)
    # print(len(img_with_contours))
    circles = detect_circles_for_addendum(img_with_contours, img, 240, show)
    # print(len(circles))
    if len(circles) > 0:
        crop = cut_circles_for_addendum(circles, img)
        # print(crop)
        # cv2.imshow('Image', crop)
        # cv2.waitKey(0)
        _, _bytes = cv2.imencode('.png', crop)
        return _bytes
    else:
        _, _bytes = cv2.imencode('.png', img)
        return _bytes


def process_one_pattern_from_mat_for_addendum(img, show=False):
    img_with_contours = get_contours(img)
    circles = detect_circles_for_addendum(img_with_contours, img, 240, show)
    if len(circles) > 0:
        crop = cut_circles_for_addendum(circles, img)
        # print(crop)
        # cv2.imwrite("t1.png", crop)
        # cv2.imshow('Image', crop)
        # cv2.waitKey(0)
        _, _bytes = cv2.imencode('.png', crop)
        return _bytes
    else:
        _, _bytes = cv2.imencode('.png', img)
        return _bytes


def remove_logo(img, template):
    # w, h = template.shape[::]
    h = img.shape[0]
    w = img.shape[1]

    method = cv2.TM_CCOEFF

    # Apply template Matching
    res = cv2.matchTemplate(img, template, cv2.TM_CCOEFF)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)

    # If the method is TM_SQDIFF or TM_SQDIFF_NORMED, take minimum

    top_left = max_loc
    bottom_right = (top_left[0] + w, top_left[1] + h)

    cv2.rectangle(img, top_left, bottom_right, (255, 255, 255), -1)

    return img


def crop_the_biggest(img_array):
    img = cv2.imdecode(img_array, cv2.IMREAD_ANYCOLOR)
    imgArray = []
    ## (1) Convert to gray, and threshold
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    th, threshed = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)

    ## (2) Morph-op to remove noise
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11))
    morphed = cv2.morphologyEx(threshed, cv2.MORPH_CLOSE, kernel)

    ## (3) Find the max-area contour
    cnts = cv2.findContours(morphed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
    cnt = sorted(cnts, key=cv2.contourArea)
    final1 = cnt[-1]
    final2 = cnt[-2]
    final3 = cnt[-3]

    imgArray.append(cut_out(img, final1))
    imgArray.append(cut_out(img, final2))
    imgArray.append(cut_out(img, final3))
    return imgArray
