from wrapt_timeout_decorator import *
from time import sleep
from pattern_exporter import process_one_pattern_from_mat_for_addendum_bytes

@timeout(15)
def pattern_extract_wt(img_data):
    return process_one_pattern_from_mat_for_addendum_bytes(img_data)