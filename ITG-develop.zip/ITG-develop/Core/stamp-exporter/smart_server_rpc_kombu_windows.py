#from __future__ import absolute_import, unicode_literals
import os
import time
import wt
import cv2
import base64
import json
import logging
from cmreslogging.handlers import CMRESHandler

from wrapt_timeout_decorator import *
from kombu import Connection, Queue
from kombu.mixins import ConsumerProducerMixin

from pattern_exporter import process_one_pattern_from_mat_for_addendum_bytes
from pattern_exporter import crop_the_biggest

rpc_queue = Queue('patterns_extract_queue')

class Worker(ConsumerProducerMixin):

    def __init__(self, connection):
        self.connection = connection

    def get_consumers(self, Consumer, channel):
        return [Consumer(
            queues=[rpc_queue],
            on_message=self.on_request,
            accept={'application/json'},
            prefetch_count=1,
        )]

    def on_request(self, message):
        payload = json.loads(message.payload)
        fileName = payload['fileName']
        content = payload['content']


        img_data = base64.b64decode(content)

        try:
            print("Start")
            log.info(f'Message got: {fileName}')
            out_data = wt.pattern_extract_wt(img_data)
            file_in_base64 = base64.b64encode(out_data)
            base64_string = file_in_base64.decode("utf-8")
            result = {"fileName": fileName, "content": base64_string }
            log.info(f'Result sent: {fileName}')
            print("End")
        except BaseException as e:
            print("wyrabalo sie :[")
            log.info(f'Exception: {e}')
            with open("warning.png", "rb") as imageFile:
                file_in_base64 = base64.b64encode(imageFile.read())
                base64_string = file_in_base64.decode("utf-8")
                result = {"fileName": "warning", "content": base64_string}

        self.producer.publish(
            {'result': result },
            exchange='', routing_key=message.properties['reply_to'],
            correlation_id=message.properties['correlation_id'],
            serializer='json',
            retry=True,
        )
        message.ack()


def main():
    user = os.getenv('RABBIT_USER', 'rabbitmq')
    password = os.getenv('RABBIT_PASSWORD', 'rabbitmq')
    hostname = os.getenv('RABBIT_HOSTNAME', 'localhost')
    port = int(os.getenv('RABBIT_PORT', '5672'))

    connection = Connection(hostname=hostname, userid=user, password=password, port=port)
    log.info('[x] Awaiting KOMBU RPC requests')
    print('[x] Awaiting KOMBU RPC requests')
    worker = Worker(connection)
    worker.run()


logging.basicConfig(level=logging.INFO, filename='app.log', filemode='w',
                        format='%(name)s - %(levelname)s - %(message)s')
log = logging.getLogger("smart_server_rpc_kombu")

handler = CMRESHandler(hosts=[{'host': os.getenv('ELASTICSEARCH_HOST', "rabbitmq"), 'port': 9200}],
                           auth_type=CMRESHandler.AuthType.BASIC_AUTH,
                           auth_details=('elastic', os.getenv('KIBANA_PASSWORD', "rabbitmq")),
                           use_ssl=True,
                           verify_ssl=False,
                           es_index_name="smartrpc")
log.addHandler(handler)

if __name__ == '__main__':
    main()
