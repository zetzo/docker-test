import cv2
import numpy as np
import sys
import os
from PIL import Image
import shutil

def get_image(path):
    img = cv2.imread(path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return img, gray


def Gaussian_Blur(gray):  # Gaussian denoising (remove noise in the image)
    """
    Gaussian blur is essentially a low pass filter:
    Each pixel of the output image is the weighted sum of the corresponding pixel on the original image and the surrounding pixels.
      
    Dimensions and standard deviations of Gaussian matrices:
    (9, 9) indicates the length and width of the Gaussian matrix. When the standard deviation is 0, OpenCV calculates itself according to the size of the Gaussian matrix.
    The larger the size of the Gaussian matrix, the larger the standard deviation, and the greater the degree of blurring of the processed image.
    """
    blurred = cv2.GaussianBlur(gray, (9, 9), 0)
    return blurred


def Sobel_gradient(blurred):
    """
        Sobelian operator to calculate the gradient in the x and y directions
        For the operator, please check: https://blog.csdn.net/wsp_1138886114/article/details/81368890
    """
    gradX = cv2.Sobel(blurred, ddepth=cv2.CV_32F, dx=1, dy=0)
    gradY = cv2.Sobel(blurred, ddepth=cv2.CV_32F, dx=0, dy=1)
    gradient = cv2.subtract(gradX, gradY)
    gradient = cv2.convertScaleAbs(gradient)
    return gradX, gradY, gradient


def Thresh_and_blur(gradient):  # threshold
    blurred = cv2.GaussianBlur(gradient, (9, 9), 0)
    (_, thresh) = cv2.threshold(blurred, 90, 255, cv2.THRESH_BINARY)
    """
         Cv2.threshold(src,thresh,maxval,type[,dst])->retval,dst (grayscale of binary values)
         Src: general input grayscale
       Thresh: threshold,
       Maxval: in the binary threshold THRESH_BINARY and
              The maximum value used in the inverse binary threshold THRESH_BINARY_INV 
       Type: the type of threshold used
         Return value retval is actually the threshold 
      """
    return thresh


def image_morphology(thresh):
    """
         Create an elliptic kernel function
         Perform image morphology, check the documentation directly, it's very simple
    """
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25))
    closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
    closed = cv2.erode(closed, None, iterations=4)
    closed = cv2.dilate(closed, None, iterations=4)
    return closed


def findcnts_and_box_point(closed):
    # here opencv3 returns three parameters
    contours, hierarchy = cv2.findContours(closed.copy(),
                                           cv2.RETR_LIST,
                                           cv2.CHAIN_APPROX_SIMPLE)

    # print('Numbers of contours found=' + str(len(contours)))

    cnts, boundingBoxes = sort_contours(contours)

    # Calculate the maximum contour of the rotating bounding box
    con_stamp = get_box(cnts[0])
    logo = get_box(cnts[len(cnts) - 1])
    return [con_stamp]


def get_box(cnts):
    rect = cv2.minAreaRect(cnts)
    box = np.int0(cv2.boxPoints(rect))
    return box


def sort_contours(cnts, method="left-to-right"):
    # initialize the reverse flag and sort index
    reverse = False
    i = 0

    # handle if we need to sort in reverse
    if method == "right-to-left" or method == "bottom-to-top":
        reverse = True

    # handle if we are sorting against the y-coordinate rather than
    # the x-coordinate of the bounding box
    if method == "top-to-bottom" or method == "bottom-to-top":
        i = 1

    # construct the list of bounding boxes and sort them from top to
    # bottom
    boundingBoxes = [cv2.boundingRect(c) for c in cnts]
    (cnts, boundingBoxes) = zip(*sorted(zip(cnts, boundingBoxes),
                                        key=lambda b: b[1][i], reverse=reverse))

    # return the list of sorted contours and bounding boxes
    return (cnts, boundingBoxes)


def remove_logo(img, template):
    # w, h = template.shape[::]
    h = img.shape[0]
    w = img.shape[1]

    method = cv2.TM_CCOEFF

    # Apply template Matching
    res = cv2.matchTemplate(img, template, cv2.TM_CCOEFF)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)

    # If the method is TM_SQDIFF or TM_SQDIFF_NORMED, take minimum
    top_left = max_loc
    bottom_right = (top_left[0] + w, top_left[1] + h)

    cv2.rectangle(img, top_left, bottom_right, (255, 255, 255), -1)
    return img


def drawcnts_and_cut(original_img, boxes):  # Target image cropping
    # Because this function is extremely destructive, all need to draw on img.copy()
    white_img = original_img.copy()
    draw_img = original_img.copy()
    for box in boxes:
        draw_img = cv2.drawContours(draw_img.copy(), [box], -1, (0, 0, 255), 3)
        Xs = [i[0] for i in box]
        Ys = [i[1] for i in box]
        x1 = min(Xs)
        x2 = max(Xs)
        y1 = min(Ys)
        y2 = max(Ys)
        hight = y2 - y1
        width = x2 - x1

        white_img = cv2.rectangle(white_img.copy(), (x1, y1), (x1 + width, y1 + hight), (255, 255, 255), -1)

        crop_img = original_img[y1:y1 + hight, x1:x1 + width]
    return draw_img, crop_img, white_img


def walk():
    img_path = 'f:/smart3/65228.png'
    save_path = 'f:/smart5/65228.png'
    original_img, gray = get_image(img_path)
    blurred = Gaussian_Blur(gray)
    gradX, gradY, gradient = Sobel_gradient(blurred)
    thresh = Thresh_and_blur(gradient)
    closed = image_morphology(thresh)
    boxes = findcnts_and_box_point(closed)
    draw_img, crop_img, white_img = drawcnts_and_cut(original_img, boxes)

    # , show them all to see
    # cv2.imshow('original_img', original_img)
    # cv2.imshow('GaussianBlur', blurred)
    cv2.imshow('gradX', gradX)
    cv2.imshow('gradY', gradY)
    cv2.imshow('final', gradient)
    cv2.imshow('thresh', thresh)
    cv2.imshow('closed', closed)
    cv2.imshow('draw_img', draw_img)
    cv2.imshow('crop_img', crop_img)
    cv2.imshow('white_img', white_img)

    cv2.waitKey(20171219)
    # cv2.imwrite(save_path, crop_img)


def removelogo(img_path, template_path, save_path):
    original_img, gray = get_image(img_path)
    blurred = Gaussian_Blur(gray)
    gradX, gradY, gradient = Sobel_gradient(blurred)
    thresh = Thresh_and_blur(gradient)
    closed = image_morphology(thresh)
    boxes = findcnts_and_box_point(closed)
    draw_img, crop_img, white_img = drawcnts_and_cut(original_img, boxes)
    template = cv2.imread(template_path, cv2.IMREAD_COLOR)
    remove_logo(draw_img, template)
    cv2.imwrite(save_path, draw_img)


def lines_detect(image_path):
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    kernel_size = 5
    blur_gray = cv2.GaussianBlur(gray, (kernel_size, kernel_size), 0)
    low_threshold = 50
    high_threshold = 150
    edges = cv2.Canny(blur_gray, low_threshold, high_threshold)

    rho = 1  # distance resolution in pixels of the Hough grid
    theta = np.pi / 180  # angular resolution in radians of the Hough grid
    threshold = 15  # minimum number of votes (intersections in Hough grid cell)
    min_line_length = 50  # minimum number of pixels making up a line
    max_line_gap = 20  # maximum gap in pixels between connectable line segments
    line_image = np.copy(img) * 0  # creating a blank to draw lines on

    # Run Hough on edge detected image
    # Output "lines" is an array containing endpoints of detected line segments
    lines = cv2.HoughLinesP(edges, rho, theta, threshold, np.array([]),
                            min_line_length, max_line_gap)

    for line in lines:
        for x1, y1, x2, y2 in line:
            cv2.line(line_image, (x1, y1), (x2, y2), (255, 0, 0), 5)

    lines_edges = cv2.addWeighted(img, 0.8, line_image, 1, 0)
    cv2.imshow('white_img', lines_edges)

    cv2.waitKey(20171219)


def remove_noise(image):
    # smooth the image with alternative closing and opening
    # with an enlarging kernel
    im = cv2.imread(image)
    morph = im.copy()

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 1))
    morph = cv2.morphologyEx(morph, cv2.MORPH_CLOSE, kernel)
    morph = cv2.morphologyEx(morph, cv2.MORPH_OPEN, kernel)

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))

    # take morphological gradient
    gradient_image = cv2.morphologyEx(morph, cv2.MORPH_GRADIENT, kernel)

    # split the gradient image into channels
    image_channels = np.split(np.asarray(gradient_image), 3, axis=2)

    channel_height, channel_width, _ = image_channels[0].shape

    # apply Otsu threshold to each channel
    for i in range(0, 3):
        _, image_channels[i] = cv2.threshold(~image_channels[i], 0, 255, cv2.THRESH_OTSU | cv2.THRESH_BINARY)
        image_channels[i] = np.reshape(image_channels[i], newshape=(channel_height, channel_width, 1))

    # merge the channels
    image_channels = np.concatenate((image_channels[0], image_channels[1], image_channels[2]), axis=2)
    return image_channels


def unsharp_mask(img, blur_size=(9, 9), imgWeight=1.5, gaussianWeight=-0.5):
    gaussian = cv2.GaussianBlur(img, (5, 5), 0)
    return cv2.addWeighted(img, imgWeight, gaussian, gaussianWeight, 0)




# walk()
def proces_file(full_file_name):
    org = cv2.imread(full_file_name)
    img = get_contour(full_file_name, 1)
    cimg = detect_circle2(img, org)
    sorted_cimg = sorted(cimg, key=lambda tup: tup[0], reverse=True)
    indx = 0
    output_dir_name = os.path.dirname(full_file_name)
    for c in sorted_cimg:
        indx = indx + 1
        file_name = os.path.splitext(os.path.basename(full_file_name))[0] + "_" + str(indx) + ".png"
        dest = os.path.join(output_dir_name, file_name)
        cv2.imwrite(dest, c[1])
        break




def border(img, bordersize):
    row, col = img.shape[:2]
    bottom = img[row - 2:row, 0:col]
    mean = cv2.mean(bottom)[0]

    bordersize = 10
    border = cv2.copyMakeBorder(
        img,
        top=bordersize,
        bottom=bordersize,
        left=bordersize,
        right=bordersize,
        borderType=cv2.BORDER_CONSTANT,
        value=[mean, mean, mean]
    )
    return border


def validate_img(image_path):
    try:
        img = Image.open(image_path)  # open the image file
        img.verify()  # verify that it is, in fact an image
        return True
    except (IOError, SyntaxError) as e:
        # print('Bad file:', image_path)  # print out the names of corrupt files
        return False


def detect_circle2(bgr_img, oimg):
    print("detect circle")
    horg = oimg.shape[0]
    worg = oimg.shape[1]
    retcircles = []

    if bgr_img is not None:
        if bgr_img.shape[-1] == 3:  # color image
            b, g, r = cv2.split(bgr_img)  # get b,g,r
            rgb_img = cv2.merge([r, g, b])  # switch it to rgb
            gray_img = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2GRAY)
        else:
            gray_img = bgr_img

        img = cv2.medianBlur(gray_img, 5)
        cimg = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

        circles = cv2.HoughCircles(img, cv2.HOUGH_GRADIENT, 1, 90, param1=20, param2=30, minRadius=0, maxRadius=180)

        # circles = cv2.HoughCircles(img, cv2.HOUGH_GRADIENT, 1, 90, param1=50, param2=30, minRadius=0, maxRadius=180)

        circles = np.uint16(np.around(circles))

        print("ilosc kolek")
        print(circles)
        i = 0
        for c in circles[0, :]:
            print(i)
            i = i + 1
            # draw the outer circle
            # cv2.circle(cimg, (i[0], i[1]), i[2], (0, 255, 0), -1)
            # draw the center of the circle
            cv2.circle(cimg, (c[0], c[1]), 120, (0, 0, 255), 1)
            cv2.imshow('Image', cimg)
            cv2.waitKey(0)

            a1 = np.round(c[0]).astype("int")
            b1 = np.round(c[1]).astype("int")
            r = 120
            # print(a1)
            # print(b1)

            copy1 = oimg.copy()
            y = b1 - r
            x = a1 - r
            h = 2 * r
            w = 2 * r

            # print(x)
            # print(y)
            # print(h)
            # print(w)
            if y + h < horg and x + w < worg:
                crop = copy1[y:y + h, x:x + w]
                tup = (x, crop)
                retcircles.append(tup)
            # cv2.imshow('Image', crop)
            # cv2.waitKey(0)
            # break

        return retcircles


def cut(image):
    image = cv2.imread(image)
    y = 172 - 130
    x = 236 - 130
    h = 260
    w = 260
    crop = image[y:y + h, x:x + w]
    cv2.imshow('Image', crop)
    cv2.waitKey(0)


# input_main()

def testOne():
    org = cv2.imread('f:/smart7/C_LS_53379.png')
    org = border(org, 150)
    cv2.imshow('Image', org)
    cv2.waitKey(0)

    img = get_contours(org, 1)

    circles = detect_circle2(img, org)
    print(len(circles))


# validate_img('f:/result/51247.png')

testOne()
# for circle in sorted_cimg:
#     cv2.imshow('Image', circle[1])
#     cv2.waitKey(0)

# proces_file('f:/smart12/58831.png')
# canny = cv2.imread('f:/smart3/69.png')
# img2 = get_contour('f:/smart3/69.png', 'f:/result', 1)
# cimg = detect_circle2(img2, canny)
#
# for c in cimg:
#     cv2.imshow('Image', c)
#     cv2.waitKey(0)
