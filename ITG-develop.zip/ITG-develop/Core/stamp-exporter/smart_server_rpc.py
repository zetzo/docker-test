import pika
import json
import os
import sys
import base64
import cv2
import numpy as np
import process_pattern_with_timout
from wrapt_timeout_decorator import *

from pattern_exporter import process_one_pattern_from_bytes
from pattern_exporter import remove_logo
from pattern_exporter import process_one_pattern_from_mat
from pattern_exporter import process_one_pattern_from_mat_for_addendum_bytes

def save_to_file_bytes(file_path, data_in_bytes):
    f = open(file_path, 'wb')
    f.write(data_in_bytes)
    f.close()

def on_request(ch, method, props, body):
    print("Message got")

    data = json.loads(body)

    image_file_fame = data["fileName"]
    print(image_file_fame)

    img_data = base64.b64decode(data["content"])
    out_data = process_one_pattern_from_mat_for_addendum_bytes(img_data)

    file_in_base64 = base64.b64encode(out_data)
    base64_string = file_in_base64.decode("utf-8")

    response = json.dumps({"fileName": image_file_fame, "content": base64_string})

    ch.basic_publish(exchange="patterns",
                     routing_key=props.reply_to,
                     properties=pika.BasicProperties(correlation_id=props.correlation_id),
                     body=response)
    ch.basic_ack(delivery_tag=method.delivery_tag)

try:
    print(pika.__version__)
    credentials = pika.PlainCredentials(os.getenv('RABBIT_USER', 'rabbitmq'), os.getenv('RABBIT_PASSWORD','rabbitmq'))
    connection = pika.BlockingConnection(pika.ConnectionParameters(
		os.getenv('RABBIT_HOSTNAME', 'localhost'),
		os.getenv('RABBIT_PORT', '5672'),
        "/",
        credentials))
    print(connection)
    channel = connection.channel()
    print(channel)
    channel.queue_declare("patterns_extract_queue", durable=True)
    channel.basic_qos(prefetch_count=1)
    channel.basic_consume("patterns_extract_queue", on_message_callback=on_request)
    print(" [x] Awaiting RPC requests")
    channel.start_consuming()
except:
    print("Oops!", sys.exc_info(), "occured.")
