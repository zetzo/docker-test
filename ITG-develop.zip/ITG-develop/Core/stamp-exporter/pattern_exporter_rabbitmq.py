import pika
import json
import os
import base64
from pattern_exporter import process_one_pattern_from_bytes

credentials = pika.PlainCredentials("patternExporter", "Honda123456")
connection = pika.BlockingConnection(pika.ConnectionParameters(
    "plkrcon23q1",
    5672,
    '/',
    credentials))
channel = connection.channel()

exchange = 'PatternsExport'
queue_name = 'PatternsExport'
channel.exchange_declare(exchange=exchange, durable=True,
                         exchange_type='direct')

result = channel.queue_declare(exclusive=True)

# severities = sys.argv[1:]
# if not severities:
# sys.stderr.write("Usage: %s [info] [warning] [error]\n" % sys.argv[0])
# sys.exit(1)

# for severity in severities:
channel.queue_bind(exchange=exchange, queue=queue_name, routing_key=None)

print(' [*] Waiting for logs. To exit press CTRL+C')

currentpath = os.getcwd()


def save_to_file_bytes(file_path, data_in_bytes):
    f = open(file_path, 'wb')
    f.write(data_in_bytes)
    f.close()


def save_to_file_string(file_path, data_in_string):
    f = open(file_path, 'w')
    f.write(data_in_string)
    f.close()


def callback(ch, method, properties, body):
    print('callback ...')
    # print(body)
    data = json.loads(body)
    imagefileName = data["FileName"]
    imgdata = base64.b64decode(data["Content"])
    out = process_one_pattern_from_bytes(imgdata)
    # save_to_file_bytes('f:\\test.png', out)


def rpc_callback(ch, method, properties, body):
    #data = json.loads(body)
    #imagefileName = data["FileName"]
    #imgdata = base64.b64decode(data["Content"])
    #out = process_one_pattern_from_bytes(imgdata)

    # body_out = json.l

    print(properties)

    ch.basic_publish(exchange=exchange,
                     routing_key=properties.reply_to,
                     properties=pika.BasicProperties(correlation_id=properties.correlation_id),
                     body=str('test'))

    ch.basic_ack(delivery_tag=method.delivery_tag)


channel.basic_qos(prefetch_count=1)
channel.basic_consume(rpc_callback, queue=queue_name)

# channel.basic_consume(callback,
#                       queue=queue_name,
#                       no_ack=True)

channel.start_consuming()
