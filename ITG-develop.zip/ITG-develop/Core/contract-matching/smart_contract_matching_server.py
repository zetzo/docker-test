# from __future__ import absolute_import, unicode_literals
import os
import base64
import json
import logging
from cmreslogging.handlers import CMRESHandler
from kombu import Connection, Queue
from kombu.mixins import ConsumerProducerMixin

from smart import matchByBytes

rpc_queue = Queue('new_patterns_matching_queue')


class Worker(ConsumerProducerMixin):

    def __init__(self, connection):
        self.connection = connection

    def get_consumers(self, Consumer, channel):
        return [Consumer(
            queues=[rpc_queue],
            on_message=self.on_request,
            accept={'application/json'},
            prefetch_count=1,
        )]

    def on_request(self, message):
        payload = json.loads(message.payload)

        contractId = payload["contractId"]
        fileName = payload["fileName"]
        distance = payload["distance"]
        log.info(f'Received filename: {fileName}')
        patternContent = base64.b64decode(payload["patternContent"])
        closingDocumentContent = base64.b64decode(payload["closingDocumentContent"])
        rounded_distance = round(float(distance), 1)

        try:
            log.info(f'New Contract got: {contractId}')
            print(f'New Contract got: {contractId}')
            score = matchByBytes(patternContent, closingDocumentContent, rounded_distance)
            result = {"score": score, "contractId": contractId}
            print(f'Score: {score} - {fileName}')
        except Exception as e:
            print(e)
            log.info(f'Exception: {e}')
            result = {"score": -1, "contractId": contractId, "error": ""}

        self.producer.publish(
            {'result': result},
            exchange='', routing_key=message.properties['reply_to'],
            correlation_id=message.properties['correlation_id'],
            serializer='json',
            retry=True,
        )
        message.ack()


def main():
    user = os.getenv('RABBIT_USER', 'rabbitmq')
    password = os.getenv('RABBIT_PASSWORD', 'rabbitmq')
    hostname = os.getenv('RABBIT_HOSTNAME', 'localhost')
    port = int(os.getenv('RABBIT_PORT', '5672'))

    connection = Connection(hostname=hostname, userid=user, password=password, port=port)
    log.info('Awaiting Matching requests')
    print("[x] Awaiting Matching requests")
    worker = Worker(connection)
    worker.run()


logging.basicConfig(level=logging.INFO, filename='app.log', filemode='w',
                    format='%(name)s - %(levelname)s - %(message)s')

log = logging.getLogger("contract_matching_server")

handler = CMRESHandler(hosts=[{'host': os.getenv('ELASTICSEARCH_HOST', "rabbitmq"), 'port': 9200}],
                       auth_type=CMRESHandler.AuthType.BASIC_AUTH,
                       auth_details=('elastic', os.getenv('KIBANA_PASSWORD', "rabbitmq")),
                       use_ssl=True,
                       verify_ssl=False,
                       es_index_name="smart_contract_matching")
log.addHandler(handler)

main()
