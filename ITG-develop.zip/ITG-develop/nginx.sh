export DOCKER_HOST= DOCKER_TLS_VERIFY= DOCKER_CERT_PATH= REGISTRY=plkrcon23q1:8083/itg
TAG=1.0.7
docker build -t itg/nginx-gateway -f nginx/Dockerfile  .
docker tag itg/nginx-gateway:latest plkrcon23q1:8083/itg/nginx-gateway:$TAG
docker login plkrcon23q1:8083 -u pl65854 -p 

docker push plkrcon23q1:8083/itg/nginx-gateway:$TAG

echo 'switching to prod'
export DOCKER_HOST=tcp://plkrcon38p1:2376 DOCKER_TLS_VERIFY=1 DOCKER_CERT_PATH=~/.docker/itg/ REGISTRY=plkrcon23q1:8083/itg
echo 'reomve old one'
docker rm nginx-gateway --force
echo 'run new'
docker run -d --hostname nginx-gateway --name nginx-gateway --network itg_default -p 4443:4443 plkrcon23q1:8083/itg/nginx-gateway:$TAG
echo 'new nginx-gateway '
