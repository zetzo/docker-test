#!/bin/bash
echo 'Build SMART version' $TAG
if [ $# -ne 3 ] ; then 
    echo 'Please provide 3 parameters - login and password to nexus docker registry and version' 
    exit 1
fi

if [ ! -d  ./prod ]; then 
    echo "'prod' folder with prod.env does not exit! Please contact with person who wrote this script ;)"
exit 1 
fi

cp ./prod/prod.env .env

export DOCKER_HOST= DOCKER_TLS_VERIFY= DOCKER_CERT_PATH= TAG=$3 REGISTRY=plkrcon23q1:8083/itg
docker-compose -f docker-compose.yaml -f docker-compose.override.yaml build
echo 'Completed!'
echo '######################'
echo 'login nexus docker registry (10.48.106.122:8083)'
docker login plkrcon23q1:8083 -u $1 -p $2
echo 'push to nexus docker registry (10.48.106.122:8083)'
 docker-compose -f docker-compose.yaml -f docker-compose.override.yaml push
echo 'Done!'

echo 'Change host to prod env'
export DOCKER_HOST=tcp://plkrcon38p1:2376 DOCKER_TLS_VERIFY=1 DOCKER_CERT_PATH=~/.docker/itg/ REGISTRY=plkrcon23q1:8083/itg
echo 'pull SMART new version images from nexus docker registry (10.48.106.122:8083)'
docker-compose -f docker-compose.yaml -f docker-compose.override.yaml pull
echo 'Done!'

echo 'recreate SMART new version images and recreate version' $TAG
docker-compose -f docker-compose.yaml -f docker-compose.override.yaml down  
docker-compose -f docker-compose.yaml -f docker-compose.override.yaml up -d 
rm .env
echo 'Taaa daaaa!'
