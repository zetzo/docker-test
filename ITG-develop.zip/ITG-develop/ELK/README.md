# ELK - Elastic + Kibana compose deployment


---

##### Please follow below steps to deploy elastic and kibana 

1. Edit .env file filling system user passwords and kibana/elastic hostnames
2. Create certs (if necessary) by running  
 **docker-compose  -f create-certs.yml up   --build**  

Above will generate certificates for elasticsearch and kibana and store in newly created volumes:
  - elk_stack_elk_cert_vol_ca
  - elk_stack_elk_cert_vol_elh
  - elk_stack_elk_cert_vol_kib
 
3. Finally run:  
 **docker-compose up -d --build**  
  **docker-compose logs -f**


