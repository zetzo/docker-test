db.auth("mongoadmin", "mongoadmin_pass");

db = db.getSiblingDB("capturify");

db.createUser({
  user: "test",
  pwd: "test",
  roles: [
    {
      role: "readWrite",
      db: "capturify"
    }
  ]
});

db.Requests.insert({});

db.Requests.createIndex({ ExecutedDateTime: 1 }, { expireAfterSeconds: 300 });
db.Requests.createIndex({ AddedAtUtc: 1 }, { expireAfterSeconds: 3600 });
