import { browser, by, element, protractor } from 'protractor';

export class LoginPage {
  navigateTo() {
    return browser.get('/');
  }

  navigateToRoute(route: string) {
    return browser.get(`'#/${route}`);
  }

  getCurrentYear() {
    return element(by.css('.signature .year')).getText();
  }

  getAllMenus() {
    return element
      .all(by.css('mat-toolbar button.nav-button'))
      .map(elm => elm.getText());
  }

  getLoginForm() {
    return element.all(by.css('mat-toolbar button.nav-button'));
  }

  getLoginFormTitle() {
    return element(by.css('mat-card-title')).getText();
  }

  getLoginButton() {
    return element(by.css('.login-button'));
  }

  getIBMidLoginButton() {
    return element(by.css('.ibmlogin-button'));
  }

  getUsernameTextbox() {
    return element(by.css('.username-input'));
  }

  getPasswordTextbox() {
    return element(by.css('.password-input'));
  }

  loginToApplication(route) {
    this.navigateToRoute(route);
    this.getUsernameTextbox().sendKeys('test@ibm.com');
    this.getPasswordTextbox().sendKeys('test');
    this.getLoginButton().click();
  }
}
