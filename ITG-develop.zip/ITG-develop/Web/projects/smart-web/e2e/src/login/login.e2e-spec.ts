import { LoginPage } from './login.po';
import { getCurrentRouteUrl } from '../utils/utils';
import { browser, protractor, element, by } from 'protractor';
import { User } from '../../../src/app/core/models/user.model';

describe('Login', () => {
  let page: LoginPage;

  beforeEach(() => (page = new LoginPage()));

  it('should redirect to "login?returnUrl=/about" route', () => {
    page.navigateTo();
    expect(getCurrentRouteUrl()).toEqual('login?returnUrl=%2Fabout');
  });

  it('should display current year in the footer', () => {
    page.navigateTo();
    expect(page.getCurrentYear()).toEqual(new Date().getFullYear().toString());
  });

  it('should display login page', () => {
    page.navigateTo();
    page.getLoginFormTitle().then(title => expect(title).toEqual('Login'));

    page
      .getLoginButton()
      .getText()
      .then(title => expect(title).toEqual('Login'));

    page
      .getIBMidLoginButton()
      .getText()
      .then(title => expect(title).toEqual('Sign in with IBMid'));
  });

  describe('On Sign In', () => {
    beforeAll(() => {
      page.loginToApplication('');
      var EC = protractor.ExpectedConditions;
      browser.wait(
        EC.presenceOf(
          element(by.css('.background .gradient .container-fluid h1'))
        ),
        7000
      );
    });

    it('should set user to local storage on sign in', () => {
      let isAuth = browser.executeScript(
        "return window.localStorage.getItem('itg-AUTH');"
      );
      var userItem = browser.executeScript(
        "return window.localStorage.getItem('currentUser');"
      );

      userItem.then(res => {
        let user = JSON.parse(res.toString()) as User;
        expect(user.username).toEqual('test@ibm.com');
        expect(user.token).toBeDefined();
      });

      expect(isAuth).toEqual('{"isAuthenticated":true}');
    });
  });
});
