import { browser, protractor, by, element } from 'protractor';

export const getCurrentRouteUrl = () =>
  browser.getCurrentUrl().then(url => url.substr(url.lastIndexOf('/') + 1));

export const waitForCssElement = (el: string, time: number) =>
  browser.wait(
    protractor.ExpectedConditions.presenceOf(element(by.css(el))),
    time
  );
