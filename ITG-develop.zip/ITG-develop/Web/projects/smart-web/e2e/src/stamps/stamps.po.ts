import { element, by } from 'protractor';

export class StampsPage {
  getSideToolbarButton() {
    return element(by.css('.mat-menu-trigger'));
  }

  getFilterContainer() {
    return element(by.css('.filter-container'));
  }

  getAdjustButton() {
    return element(by.css('.adjust-btn'));
  }
}
