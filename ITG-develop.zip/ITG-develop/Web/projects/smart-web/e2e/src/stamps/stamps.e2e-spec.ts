import { StampsPage } from './stamps.po';
import { LoginPage } from '../login/login.po';
import { protractor, browser, element, by } from 'protractor';
import { waitForCssElement, getCurrentRouteUrl } from '../utils/utils';

fdescribe('Stamps', () => {
  let page: StampsPage;
  let login: LoginPage;
  var EC = protractor.ExpectedConditions;

  beforeEach(() => (page = new StampsPage()));

  beforeAll(() => {
    login = new LoginPage();
    login.loginToApplication('stamp');
    waitForCssElement('itg-stamp', 5000);
  });

  it('should redirect to "stamp/gallery" route', () => {
    expect(getCurrentRouteUrl()).toEqual('gallery');
  });

  describe('On Side Menu Click', () => {
    beforeAll(() => {
      var sideMenu = element(by.css('.side-menu-icon'));
      browser.wait(EC.elementToBeClickable(sideMenu), 5000);
      sideMenu.click();
      browser.waitForAngular();
    });

    it('side menu should be visible', () => {
      element(by.css('.filter-container'))
        .isPresent()
        .then(isPresent => expect(isPresent).toBe(true));
    });

    describe('On filter enter', () => {
      it('filter chip should appear above', () => {
        var propertySelector = element(by.css('.filter-container')).element(
          by.tagName('mat-select.property-selector')
        );
        browser.wait(EC.elementToBeClickable(propertySelector), 5000);
        propertySelector.click();
        browser.waitForAngular();
        //$('.mat-option[ng-reflect-value="optionA"]').click();
        element(
          by.cssContainingText('mat-option .mat-option-text', 'INN')
        ).click();
        browser.waitForAngular();

        let comparisonSelector = element(by.css('.filter-container')).element(
          by.tagName('mat-select.comparison-selector')
        );
        browser.wait(EC.elementToBeClickable(comparisonSelector), 5000);
        comparisonSelector.click();
        browser.waitForAngular();

        element(
          by.cssContainingText('mat-option .mat-option-text', 'EXACT')
        ).click();
        browser.waitForAngular();

        element(by.css('.value1-input')).sendKeys('test');
        browser.waitForAngular();

        element(by.css('.add-filter-btn')).click();
        browser.waitForAngular();

        element(by.css('mat-chip-list mat-chip div'))
          .isPresent()
          .then(isPresent => expect(isPresent).toBe(true));

        expect(element(by.css('mat-chip-list mat-chip div')).getText()).toEqual(
          'INN = test'
        );
      });
    });

    describe('On filter remove', () => {
      it('filter chip should be removed', () => {
        let removeBtn = element(by.css('mat-chip-list mat-chip i.fa-times'));
        //browser.wait(EC.elementToBeClickable(removeBtn), 5000);
        removeBtn.click();
        browser.waitForAngular();

        element(by.css('mat-chip-list mat-chip div'))
          .isPresent()
          .then(isPresent => expect(isPresent).toBe(false));
      });
    });

    afterAll(() => {
      var sideMenu = element(by.css('.side-menu-icon'));
      browser.wait(EC.elementToBeClickable(sideMenu), 5000);
      sideMenu.click();
      browser.waitForAngular();
    });
  });

  describe('On pattern tile checked', () => {
    it('number of selected tiles shall be displayed in action confirmation', () => {
      var tileCheckboxes = element.all(by.css('.mat-checkbox-inner-container'));
      tileCheckboxes[0].click();
      browser.waitForAngular();
      tileCheckboxes[1].click();
      browser.waitForAngular();

      // var sideMenu = element(by.css('.side-menu-icon'));
      // browser.wait(EC.elementToBeClickable(sideMenu), 5000);
      // sideMenu.click();
      // browser.waitForAngular();

      // let adjustBtn = page.getAdjustButton();
      // browser.wait(EC.elementToBeClickable(adjustBtn), 2000);
      // adjustBtn.click();
      // browser.waitForAngular();

      // element(by.css('itg-stamp-confirmation-dialog'))
      //   .isPresent()
      //   .then(isPresent => expect(isPresent).toBe(true));

      // let description = element(by.css('itg-stamp-confirmation-dialog div p')).getText();

      // expect(description).toContain('Number of selected patterns: 2');
    });
  });
});
