import { AboutPage } from './about.po';
import { getCurrentRouteUrl } from '../../utils/utils';
import { browser, protractor, element, by } from 'protractor';
import { LoginPage } from '../../login/login.po';

describe('About Page', () => {
  let page: AboutPage;
  let login: LoginPage;
  var EC = protractor.ExpectedConditions;

  beforeEach(() => (page = new AboutPage()));

  beforeAll(() => {
    //page.navigateTo();
    login = new LoginPage();

    browser.get('/about');
    login.getUsernameTextbox().sendKeys('test@ibm.com');
    login.getPasswordTextbox().sendKeys('test');
    login.getLoginButton().click();

    browser.wait(
      EC.presenceOf(
        element(by.css('.background .gradient .container-fluid h1'))
      ),
      7000
    );
  });

  it('should display main heading', () => {
    expect(page.getParagraphText()).toEqual(
      'STAMP MATCHING AND RECOGNITION TOOL'
    );
  });

  it('should display "Messages for User" section', () => {
    browser.wait(
      EC.presenceOf(element(by.css('.actions .ng-star-inserted'))),
      4000
    );

    page
      .getMessagesForUser()
      .isPresent()
      .then(isPresent => expect(isPresent).toBe(true));
  });

  it('should display "Version info" section', () => {
    browser.wait(
      EC.presenceOf(element(by.css('.version-card .ng-star-inserted'))),
      4000
    );

    page
      .getVersionInfo()
      .isPresent()
      .then(isPresent => expect(isPresent).toBe(true));
  });
});
