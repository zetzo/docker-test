import browser from 'browser-detect';
import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  OnDestroy
} from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable, combineLatest, Subject } from 'rxjs';
import { environment as env } from '../../environments/environment';
import {
  authLogin,
  authLogout,
  routeAnimations,
  AppState,
  LocalStorageService,
  selectIsAuthenticated,
  selectSettingsStickyHeader,
  selectSettingsLanguage,
  selectEffectiveTheme
} from '../core/core.module';
import {
  actionSettingsChangeAnimationsPageDisabled,
  actionSettingsChangeLanguage,
  actionSettingsToogleAdminTabVisibility,
  actionSettingsChangeTheme,
  actionChangeUserSettings
} from '../core/settings/settings.actions';
import { User } from '../core/models/user.model';
import { AuthenticationService } from '../core/auth/auth.service';
import { select as adminSelect } from '../core/admin/admin.selectors';
import { NavItemModel } from '../core/models/navigation.model';
import { selectNavigationItems } from '../core/settings/settings.selectors';
import { adminLogout } from '../core/admin/admin.actions';
import { setUserSettings } from '../core/auth/auth.actions';
import { UserSettings } from '../core/models/user-settings.model';
import { takeUntil } from 'rxjs/operators';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ConfigurationService } from '../core/configuration/configuration.service';

@Component({
  selector: 'itg-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations: [routeAnimations],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements OnInit, OnDestroy {
  isProd = env.production;
  envName = env.envName;
  version = env.versions.app;
  year = new Date().getFullYear();
  deviceInfo: any = null;
  browserSupported: boolean = true;
  logo = require('../../assets/ibm-logo.png');
  smartbyibm = require('../../assets/smartbyibm.png');
  imperialbrands = require('../../assets/imperialbrands2.png');
  navItems: NavItemModel[];
  language: string;

  navigation = [
    { link: 'about', label: 'itg.menu.about', auth: true },
    { link: 'stamp', label: 'itg.menu.stamps', auth: true },
    { link: 'admin', label: 'itg.menu.admin', auth: false },
    { link: 'matching', label: 'itg.menu.matching', auth: true }
  ];

  navigationSideMenu = [
    ...this.navigation,
    { link: 'settings', label: 'itg.menu.settings' }
  ];

  isAuthenticated$: Observable<boolean>;
  hasAdminPermission$: Observable<boolean>;
  stickyHeader$: Observable<boolean>;
  language$: Observable<string>;
  theme$: Observable<string>;
  currentUser$: Observable<User>;
  navigationItems$: Observable<NavItemModel[]>;
  unsubscribeSignal: Subject<void> = new Subject();

  constructor(
    private store: Store<AppState>,
    private storageService: LocalStorageService,
    private authenticationService: AuthenticationService,
    private deviceService: DeviceDetectorService,
    private configuration: ConfigurationService
  ) {
    this.detectDevice();
  }

  private static isIEorEdgeOrSafari() {
    return ['ie', 'edge', 'safari'].includes(browser().name);
  }

  ngOnInit(): void {
    this.storageService.testLocalStorage();
    if (AppComponent.isIEorEdgeOrSafari()) {
      this.store.dispatch(
        actionSettingsChangeAnimationsPageDisabled({
          pageAnimationsDisabled: true
        })
      );
    }

    this.isAuthenticated$ = this.store.pipe(select(selectIsAuthenticated));
    this.hasAdminPermission$ = this.store.pipe(select(adminSelect.isAdmin));
    this.stickyHeader$ = this.store.pipe(select(selectSettingsStickyHeader));
    this.language$ = this.store.pipe(select(selectSettingsLanguage));
    this.theme$ = this.store.pipe(select(selectEffectiveTheme));
    this.currentUser$ = this.authenticationService.currentUser;
    this.navigationItems$ = this.store.pipe(select(selectNavigationItems));
    this.hasAdminPermission$
      .pipe(takeUntil(this.unsubscribeSignal.asObservable()))
      .subscribe(x => {
        if (x) {
          this.store.dispatch(
            actionSettingsToogleAdminTabVisibility({ value: x })
          );
        }
      });

    this.language$
      .pipe(takeUntil(this.unsubscribeSignal.asObservable()))
      .subscribe(x => (this.language = x));

    this.currentUser$
      .pipe(takeUntil(this.unsubscribeSignal.asObservable()))
      .subscribe(x => {
        if (x && x.settings != null) {
          let usersettings = JSON.parse(x.settings) as UserSettings;
          this.store.dispatch(
            actionChangeUserSettings({
              settings: {
                language: usersettings.language,
                theme: usersettings.theme.toUpperCase()
              }
            })
          );
        }
      });
  }

  ngOnDestroy(): void {
    this.unsubscribeSignal.next();
  }

  detectDevice() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    let version: number = +this.deviceInfo.browser_version;

    switch (this.deviceInfo.browser) {
      case 'IE':
      case 'MS-Edge':
        this.browserSupported = false;
        break;
      case 'Firefox':
        if (version < 51) {
          this.browserSupported = false;
        }
        break;
      case 'Chrome':
        // what is minimal chrome version?
        if (version < 50) {
          this.browserSupported = false;
        }
        break;
      default:
        break;
    }
  }

  openDocumentationPage() {
    console.log(this.language);
    switch (this.language) {
      case 'en':
        window.open(this.configuration.settings.docUrlEn, '_blank');
        break;
      case 'ru':
        window.open(this.configuration.settings.docUrlRu, '_blank');
        break;
      default:
        window.open(this.configuration.settings.docUrlEn, '_blank');
        break;
    }
  }

  onLogoutClick() {
    this.store.dispatch(authLogout());
    this.store.dispatch(adminLogout());
  }

  onLanguageSelect({ value: language }) {
    this.store.dispatch(actionSettingsChangeLanguage({ language }));
  }
}
