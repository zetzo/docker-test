import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, ErrorHandler, APP_INITIALIZER } from '@angular/core';

import { SharedModule } from './shared/shared.module';
import { CoreModule } from './core/core.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app/app.component';
import { StampsModule } from '../../../stamps/src/lib/stamps.module';
import { AppErrorHandler } from './core/error/app-error-handler.service';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { ConfigurationHttpService } from './core/configuration/configuration.http.service';
import { MatPaginatorIntl } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { PaginatorI18n } from './core/paginators/paginator.i18n';

export function app_Init(settingsHttpService: ConfigurationHttpService) {
  return () => settingsHttpService.initializeApp();
}

@NgModule({
  imports: [
    // angular
    BrowserAnimationsModule,
    BrowserModule,

    // core & shared
    CoreModule,
    SharedModule,
    StampsModule,

    // app
    AppRoutingModule,
    DeviceDetectorModule.forRoot()
  ],
  providers: [
    { provide: ErrorHandler, useClass: AppErrorHandler },
    {
      provide: APP_INITIALIZER,
      useFactory: app_Init,
      deps: [ConfigurationHttpService],
      multi: true
    },
    {
      provide: MatPaginatorIntl,
      deps: [TranslateService],
      useFactory: (translateService: TranslateService) =>
        new PaginatorI18n(translateService).getPaginatorIntl()
    }
  ],
  declarations: [AppComponent],
  bootstrap: [AppComponent]
})
export class AppModule {}
