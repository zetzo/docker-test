import { createAction, props } from '@ngrx/store';
import { HttpErrorResponse } from '@angular/common/http';
import { AppError } from '../models/error/app-error.model';

export const setError = createAction(
  '[Error] Set error',
  props<{ value: AppError }>()
);

export const setHttpError = createAction(
  '[Error] Set http error',
  props<{ value: HttpErrorResponse; exceptionId: string }>()
);

export const cleanErrors = createAction('[Error] Clean errors');

export const errorLogSaved = createAction(
  '[Error] Error Log Saved By Service',
  props<{ errorId: string }>()
);

export const redirectToUserToConfirmPage = createAction(
  '[Error] User Not Confirmed'
);

export const redirectToGalleryPage = createAction(
  '[Error] Redirect Back To Gallery'
);

export const redirectTo = createAction(
  '[Error] Redirect To',
  props<{ url: string }>()
);
