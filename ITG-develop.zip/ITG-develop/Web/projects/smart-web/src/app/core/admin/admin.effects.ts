import { Injectable } from '@angular/core';
import { Actions, ofType, createEffect } from '@ngrx/effects';
import { of } from 'rxjs';
import { tap, switchMap, catchError, map } from 'rxjs/operators';
import { LocalStorageService } from '../local-storage/local-storage.service';
import { ApiService } from '../services/api.service';
import { action } from './admin.actions';
import { Envelope } from '../models/common/envelope.model';
import { UserToDisplay } from '../models/user-to-display.model';
import { Role } from '../models/role/role.model';
import { Permission } from '../models/role/permission.model';
import { LogEntry } from '../models/changes/log.model';
import { PagedResult } from '../models/common/page-result.model';
import { HttpParams, HttpHeaders } from '@angular/common/http';
import { ConfigurationService } from '../configuration/configuration.service';
import { FileElement } from '../models/folder-structure/file-element.model';
import { NotificationService } from '../notifications/notification.service';
import { TranslateService } from '@ngx-translate/core';

export const ADMIN_KEY = 'ADMIN';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*'
  })
};

@Injectable()
export class AdminEffects {
  constructor(
    private actions$: Actions,
    private service: ApiService,
    private configuration: ConfigurationService,
    private notification: NotificationService,
    private localStorageService: LocalStorageService,
    private readonly translate: TranslateService
  ) {}

  loginPullUsers = createEffect(() =>
    this.actions$.pipe(
      ofType(action.adminLogin),
      tap(() =>
        this.localStorageService.setItem(ADMIN_KEY, {
          hasAdminPermission: true
        })
      ),
      switchMap(() =>
        this.service
          .get<Envelope<UserToDisplay[]>>(
            `${this.configuration.settings.apiUrl}/user`
          )
          .pipe(
            map(payload =>
              action.usersRetrieveSuccess({ users: payload.result })
            ),
            catchError(error => of(action.onApiError({ error })))
          )
      )
    )
  );

  adminLogout = createEffect(
    () =>
      this.actions$.pipe(
        ofType(action.adminLogout),
        tap(() => {
          this.localStorageService.setItem('ADMIN', {
            hasAdminPermission: false
          });
        })
      ),
    { dispatch: false }
  );

  loginPullRoles = createEffect(() =>
    this.actions$.pipe(
      ofType(action.adminLogin, action.pullRoles),
      switchMap(() =>
        this.service
          .get<Envelope<Role[]>>(`${this.configuration.settings.apiUrl}/role`)
          .pipe(
            map(payload =>
              action.rolesRetrieveSuccess({ roles: payload.result })
            ),
            catchError(error => of(action.onApiError({ error })))
          )
      )
    )
  );

  loginPullPermissions = createEffect(() =>
    this.actions$.pipe(
      ofType(action.adminLogin),
      switchMap(() =>
        this.service
          .get<Envelope<Permission[]>>(
            `${this.configuration.settings.apiUrl}/role/permission`
          )
          .pipe(
            map(payload =>
              action.permissionsRetrieveSuccess({
                permissions: payload.result
              })
            ),
            catchError(error => of(action.onApiError({ error })))
          )
      )
    )
  );

  roleUpdateRequested = createEffect(() =>
    this.actions$.pipe(
      ofType(action.roleUpdate),
      switchMap(payload =>
        this.service
          .put(
            `${this.configuration.settings.apiUrl}/role/${payload.role.id}`,
            payload.role
          )
          .pipe(
            map(result => action.roleUpdateSuccess({ role: result.result })),
            catchError(error => of(action.onApiError({ error })))
          )
      )
    )
  );

  roleCreateRequested = createEffect(() =>
    this.actions$.pipe(
      ofType(action.roleCreate),
      switchMap(payload =>
        this.service
          .post(`${this.configuration.settings.apiUrl}/role`, payload.role)
          .pipe(
            map(result => action.pullRoles()),
            catchError(error => of(action.onApiError({ error })))
          )
      )
    )
  );

  userUpdateRequested = createEffect(() =>
    this.actions$.pipe(
      ofType(action.userUpdate),
      switchMap(payload =>
        this.service
          .put(`${this.configuration.settings.apiUrl}/user`, payload.user)
          .pipe(
            map(result => action.userUpdateSuccess({ user: result.result })),
            catchError(error => of(action.onApiError({ error })))
          )
      )
    )
  );

  changeLogRequested = createEffect(() =>
    this.actions$.pipe(
      ofType(action.changeLogRequested),
      switchMap(v =>
        this.service
          .get<Envelope<PagedResult<LogEntry>>>(
            `${this.configuration.settings.apiUrl}/log`,
            new HttpParams()
              .set('pageIndex', v.pageIndex.toString())
              .set('pageSize', v.pageSize.toString()),
            httpOptions
          )
          .pipe(
            map(payload =>
              action.changeLogRetrieveSuccess({
                changeLog: payload.result
              })
            ),
            catchError(error => of(action.onApiError({ error })))
          )
      )
    )
  );

  loginPullDirectories = createEffect(() =>
    this.actions$.pipe(
      ofType(action.adminLogin, action.directoriesRequested),
      switchMap(() =>
        this.service
          .get<Envelope<FileElement[]>>(
            `${this.configuration.settings.apiUrl}/patternaction/folder/structure`
          )
          .pipe(
            map(payload =>
              action.directoriesRetrieveSuccess({ directories: payload.result })
            ),
            catchError(error => of(action.onApiError({ error })))
          )
      )
    )
  );

  onDataMappingsUpload = createEffect(() =>
    this.actions$.pipe(
      ofType(action.uploadMappingsData),
      switchMap(v => {
        let formData = new FormData();
        formData.append('file', v.file);

        return this.service
          .uploadFile(
            `${this.configuration.settings.apiUrl}/patterns/mapping`,
            formData
          )
          .pipe(
            tap(() =>
              this.notification.success(
                this.translate.instant('itg.notification.fileuploadsuccess')
              )
            ),
            map(payload => action.uploadMappingsDataFinished()),
            catchError(error =>
              of(action.uploadMappingsDataError({ error: error }))
            )
          );
      })
    )
  );

  onLoadError$ = createEffect(() =>
    this.actions$.pipe(
      ofType(action.uploadMappingsDataError),
      switchMap(value => {
        this.notification.error(value.error);
        return of(action.uploadMappingsDataFinished());
      })
    )
  );
}
