import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppState } from '../core.state';
import { Observable, of } from 'rxjs';
import { UserToDisplay } from '../models/user-to-display.model';
import { select } from './admin.selectors';
import { Permission } from '../models/role/permission.model';
import { Role } from '../models/role/role.model';
import { PagedResult } from '../models/common/page-result.model';
import { LogEntry } from '../models/changes/log.model';
import { action } from './admin.actions';
import { FileElement } from '../models/folder-structure/file-element.model';

@Injectable()
export class AdminFacade {
  constructor(private store: Store<AppState>) {}

  get users$(): Observable<UserToDisplay[]> {
    return this.store.select(select.users);
  }

  get roles$(): Observable<Role[]> {
    return this.store.select(select.roles);
  }

  get permissions$(): Observable<Permission[]> {
    return this.store.select(select.permissions);
  }

  get logs$(): Observable<PagedResult<LogEntry>> {
    return this.store.select(select.logs);
  }

  get loaded$(): Observable<boolean> {
    return this.store.select(select.loaded);
  }

  get directories$(): Observable<FileElement[]> {
    return this.store.select(select.directories);
  }

  get uploading$(): Observable<boolean> {
    return this.store.select(select.uploading);
  }

  getLogEntriesPaged(pageIndex: number = 1, pageSize: number = 30) {
    this.store.dispatch(
      action.changeLogRequested({
        pageIndex: pageIndex,
        pageSize: pageSize
      })
    );
  }

  updateRole(role: Role) {
    this.store.dispatch(action.roleUpdate({ role: role }));
  }

  createRole(role: Role) {
    this.store.dispatch(action.roleCreate({ role: role }));
  }

  updateUser(user: UserToDisplay) {
    this.store.dispatch(action.userUpdate({ user: user }));
  }

  dispatchAdminLogin() {
    this.store.dispatch(action.adminLogin({ value: true }));
  }

  pullDirectories() {
    this.store.dispatch(action.directoriesRequested());
  }

  uploadMappings(file: File) {
    this.store.dispatch(action.uploadMappingsData({ file: file }));
  }
}
