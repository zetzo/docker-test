export class Configuration {
  apiUrl: string;
  docUrlEn: string;
  docUrlRu: string;
}
