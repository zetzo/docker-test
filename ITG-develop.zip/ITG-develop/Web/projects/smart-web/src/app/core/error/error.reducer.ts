import { ErrorState } from './error.models';
import { createReducer, on, Action } from '@ngrx/store';
import {
  setError,
  setHttpError,
  cleanErrors,
  errorLogSaved
} from './error.actions';
import { state } from '@angular/animations';

export const initialState: ErrorState = {
  error: null,
  httpError: null,
  errorId: null
};

const reducer = createReducer(
  initialState,
  on(setError, (state, payload) => ({
    ...state,
    error: payload.value,
    httpError: null,
    errorId: null
  })),
  on(setHttpError, (state, payload) => ({
    ...state,
    error: null,
    httpError: payload.value,
    errorId: payload.exceptionId
  })),
  on(cleanErrors, state => ({
    ...state,
    error: null,
    httpError: null,
    errorId: null
  })),
  on(errorLogSaved, (state, payload) => ({
    ...state,
    errorId: payload.errorId
  }))
);

export function errorReducer(
  state: ErrorState | undefined,
  action: Action
): ErrorState {
  return reducer(state, action);
}
