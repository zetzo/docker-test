import { ConfigurationService } from './configuration.service';
import { Configuration } from './configuration';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ConfigurationHttpService {
  constructor(
    private http: HttpClient,
    private settingsService: ConfigurationService
  ) {}

  initializeApp(): Promise<any> {
    console.log(environment.envName);
    return new Promise(resolve => {
      this.http
        .get('assets/settings.json')
        .toPromise()
        .then(response => {
          this.settingsService.settings = <Configuration>response;
          resolve();
        });
    });
  }
}
