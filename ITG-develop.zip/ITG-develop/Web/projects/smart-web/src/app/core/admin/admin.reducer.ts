import { AdminState } from './admin.models';

import { createReducer, on, Action } from '@ngrx/store';
import { action } from './admin.actions';

export const initialState: AdminState = {
  hasAdminPermission: false,
  logs: null,
  roleList: [],
  userList: [],
  permissionList: [],
  directories: [],
  loaded: false,
  fileUploading: false,
  fileUploadingError: ''
};

const reducer = createReducer(
  initialState,
  on(action.adminLogin, (state, payload) => ({
    ...state,
    hasAdminPermission: payload.value,
    loaded: true
  })),
  on(action.adminLogout, state => ({
    ...state,
    hasAdminPermission: false,
    roleList: [],
    permissionList: [],
    userList: [],
    logs: null,
    loaded: false,
    directories: [],
    fileUploading: false
  })),
  on(action.setAdminPermission, (state, payload) => ({
    ...state,
    hasAdminPermission: payload.value
  })),
  on(action.usersRetrieveSuccess, (state, payload) => ({
    ...state,
    userList: payload.users
  })),
  on(action.rolesRetrieveSuccess, (state, payload) => ({
    ...state,
    roleList: payload.roles
  })),
  on(action.permissionsRetrieveSuccess, (state, payload) => ({
    ...state,
    permissionList: payload.permissions
  })),
  on(action.roleUpdateSuccess, (state, payload) => ({
    ...state,
    roleList: state.roleList.map((item, index) => {
      if (payload.role.id == item.id) {
        return Object.assign(item, payload.role);
      }

      return item;
    })
  })),
  on(action.userUpdateSuccess, (state, payload) => ({
    ...state,
    userList: state.userList.map((item, index) => {
      if (payload.user.username == item.username) {
        return Object.assign(item, payload.user);
      }
      return item;
    })
  })),
  on(action.changeLogRetrieveSuccess, (state, payload) => ({
    ...state,
    logs: payload.changeLog
  })),
  on(action.directoriesRetrieveSuccess, (state, payload) => ({
    ...state,
    directories: payload.directories
  })),
  on(action.uploadMappingsData, state => ({
    ...state,
    fileUploading: true
  })),
  on(action.uploadMappingsDataError, (state, payload) => ({
    ...state,
    fileUploading: false,
    fileUploadingError: payload.error
  })),

  on(action.uploadMappingsDataFinished, state => ({
    ...state,
    fileUploading: false
  }))
);

export function adminReducer(
  state: AdminState | undefined,
  action: Action
): AdminState {
  return reducer(state, action);
}
