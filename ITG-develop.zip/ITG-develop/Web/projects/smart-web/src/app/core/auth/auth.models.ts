import { User } from '../models/user.model';

export interface AuthState {
  isAuthenticated: boolean;
  incorrectCredencials: boolean;
  user: User;
}
