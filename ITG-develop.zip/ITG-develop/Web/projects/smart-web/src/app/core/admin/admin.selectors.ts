import { createSelector } from '@ngrx/store';
import { selectAdminState } from '../core.state';
import { AdminState } from './admin.models';
import { Role } from '../models/role/role.model';
import { UserToDisplay } from '../models/user-to-display.model';

export const admin = createSelector(
  selectAdminState,
  (state: AdminState) => state
);

export const isAdmin = createSelector(
  selectAdminState,
  (state: AdminState) => state.hasAdminPermission
);

export const users = createSelector(
  selectAdminState,
  (state: AdminState) => state.userList
);

export const roles = createSelector(
  selectAdminState,
  (state: AdminState) => state.roleList
);

export const permissions = createSelector(
  selectAdminState,
  (state: AdminState) => state.permissionList
);

export const logs = createSelector(
  selectAdminState,
  (state: AdminState) => state.logs
);

export const loaded = createSelector(
  selectAdminState,
  (state: AdminState) => state.loaded
);

export const directories = createSelector(
  selectAdminState,
  (state: AdminState) => state.directories
);

export const uploading = createSelector(
  selectAdminState,
  (state: AdminState) => state.fileUploading
);

export const select = {
  isAdmin,
  users,
  roles,
  permissions,
  logs,
  loaded,
  directories,
  uploading
};
