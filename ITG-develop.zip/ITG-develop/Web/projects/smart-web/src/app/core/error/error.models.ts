import { HttpErrorResponse } from '@angular/common/http';
import { AppError } from '../models/error/app-error.model';

export interface ErrorState {
  error: AppError;
  httpError: HttpErrorResponse;
  errorId: string;
}
