import { createAction, props } from '@ngrx/store';
import { UserToDisplay } from '../models/user-to-display.model';
import { Role } from '../models/role/role.model';
import { Permission } from '../models/role/permission.model';
import { HttpErrorResponse } from '@angular/common/http';
import { PagedResult } from '../models/common/page-result.model';
import { LogEntry } from '../models/changes/log.model';
import { FileElement } from '../models/folder-structure/file-element.model';

export const adminLogin = createAction(
  '[Admin] Login',
  props<{ value: boolean }>()
);

export const adminLogout = createAction('[Admin] Logout');

export const setAdminPermission = createAction(
  '[Admin] Set Admin Permission',
  props<{ value: boolean }>()
);

export const usersRetrieveSuccess = createAction(
  '[Admin] Users Retrieved',
  props<{ users: UserToDisplay[] }>()
);

export const pullRoles = createAction('[Admin] Roles Requested');

export const rolesRetrieveSuccess = createAction(
  '[Admin] Roles Retrieved',
  props<{ roles: Role[] }>()
);

export const permissionsRetrieveSuccess = createAction(
  '[Admin] Permissions Retrieved',
  props<{ permissions: Permission[] }>()
);

export const onApiError = createAction(
  '[Admin] Retrieve Error',
  props<{ error: HttpErrorResponse }>()
);

export const changeLogRequested = createAction(
  '[Admin] Change Log Requested',
  props<{ pageIndex: number; pageSize: number }>()
);

export const changeLogRetrieveSuccess = createAction(
  '[Admin] Change Log Retrieve Success',
  props<{ changeLog: PagedResult<LogEntry> }>()
);

export const roleUpdate = createAction(
  '[Admin] Role Update',
  props<{ role: Role }>()
);

export const roleCreate = createAction(
  '[Admin] Role Create',
  props<{ role: Role }>()
);

export const roleUpdateSuccess = createAction(
  '[Admin] Role Update Success',
  props<{ role: Role }>()
);

export const userUpdate = createAction(
  '[Admin] User Update',
  props<{ user: UserToDisplay }>()
);

export const userUpdateSuccess = createAction(
  '[Admin] User Update Success',
  props<{ user: UserToDisplay }>()
);

export const directoriesRequested = createAction(
  '[Admin] Directories Requested'
);

export const directoriesRetrieveSuccess = createAction(
  '[Admin] Directories Retrieve Success',
  props<{ directories: FileElement[] }>()
);

export const uploadMappingsData = createAction(
  '[Admin] Mappings Upload',
  props<{ file: File }>()
);

export const uploadMappingsDataError = createAction(
  '[Admin] Mappings Upload Error',
  props<{ error: string }>()
);

export const uploadMappingsDataFinished = createAction(
  '[Admin] Mappings Upload Finished'
);

export const action = {
  adminLogin,
  adminLogout,
  setAdminPermission,
  usersRetrieveSuccess,
  pullRoles,
  rolesRetrieveSuccess,
  permissionsRetrieveSuccess,
  onApiError,
  changeLogRequested,
  changeLogRetrieveSuccess,
  roleUpdate,
  roleUpdateSuccess,
  roleCreate,
  userUpdate,
  userUpdateSuccess,
  directoriesRequested,
  directoriesRetrieveSuccess,
  uploadMappingsData,
  uploadMappingsDataError,
  uploadMappingsDataFinished
};
