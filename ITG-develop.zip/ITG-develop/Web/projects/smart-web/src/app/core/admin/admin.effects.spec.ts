import { TestScheduler } from 'rxjs/testing';
import * as assert from 'assert';
import { Observable, of } from 'rxjs';
import { AdminEffects } from './admin.effects';
import { AppState } from '../core.state';
import { Store, StoreModule } from '@ngrx/store';
import { ApiService } from '../services/api.service';
import { LocalStorageService } from '../core.module';
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { adminReducer } from './admin.reducer';
import { EffectsModule, Actions } from '@ngrx/effects';
import { action } from './admin.actions';
import { ApiServiceMock } from '../services/api.service.mock';
import { ConfigurationService } from '../configuration/configuration.service';

const scheduler = new TestScheduler((actual, expected) =>
  assert.deepStrictEqual(actual, expected)
);

describe('AdminEffects', () => {
  let actions$: Observable<any>;
  let effects: AdminEffects;
  let store: Store<AppState>;
  let apiServiceMock = ApiServiceMock;
  apiServiceMock.http = jasmine.createSpyObj('httpClient', [
    'get',
    'post',
    'put',
    'patch'
  ]);
  let configuration = new ConfigurationService();

  let service: jasmine.SpyObj<ApiService>;
  let localStorageService: jasmine.SpyObj<LocalStorageService>;
  const httpClientSpy: jasmine.SpyObj<HttpClient> = jasmine.createSpyObj(
    'httpClient',
    ['get', 'post']
  );

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AdminEffects,
        provideMockActions(() => actions$),
        { provide: HttpClient, useValue: {} },
        Store
      ],
      imports: [
        HttpClientModule,
        StoreModule.forRoot({}),
        StoreModule.forFeature('admin', { adminReducer }),
        EffectsModule.forRoot([AdminEffects]),
        EffectsModule.forFeature([AdminEffects])
      ]
    });

    TestBed.overrideProvider(HttpClient, { useValue: httpClientSpy });
    store = TestBed.get(Store);
    effects = TestBed.get<AdminEffects>(AdminEffects);
    spyOn(store, 'dispatch');
    service = jasmine.createSpyObj('apiServiceMock', ['get', 'post']);
    localStorageService = jasmine.createSpyObj('LocalStorageService', [
      'setItem'
    ]);
  });

  describe('Admin Login', () => {
    it('should setItem on LocalStorageService', () => {
      scheduler.run(helpers => {
        const { hot } = helpers;
        const adminLoginAction = action.adminLogin({ value: true });
        const source = hot('-a', { a: adminLoginAction });
        const actions = new Actions(source);

        service.get.and.returnValue(of({}));

        const effect = new AdminEffects(
          actions,
          service,
          configuration,
          localStorageService
        );

        effect.loginPullUsers.subscribe(_ => {
          expect(localStorageService.setItem).toHaveBeenCalledWith('ADMIN', {
            hasAdminPermission: true
          });
        });
      });
    });

    it('should pull all users', () => {
      scheduler.run(helpers => {
        const { hot } = helpers;
        const adminLoginAction = action.adminLogin({ value: true });
        const source = hot('-a', { a: adminLoginAction });
        const actions = new Actions(source);

        service.get.and.returnValue(of({}));

        const effect = new AdminEffects(
          actions,
          service,
          configuration,
          localStorageService
        );

        effect.loginPullUsers.subscribe(_ => {
          expect(service.get).toHaveBeenCalled();
        });
      });
    });

    it('should pull all roles', () => {
      scheduler.run(helpers => {
        const { cold, hot } = helpers;
        const adminLoginAction = action.adminLogin({ value: true });
        const source = hot('-a', { a: adminLoginAction });
        const actions = new Actions(source);

        service.get.and.returnValue(of({}));

        const effect = new AdminEffects(
          actions,
          service,
          configuration,
          localStorageService
        );

        effect.loginPullRoles.subscribe(_ => {
          expect(service.get).toHaveBeenCalled();
        });
      });
    });

    it('should pull all permissions', () => {
      scheduler.run(helpers => {
        const { hot } = helpers;
        const adminLoginAction = action.adminLogin({ value: true });
        const source = hot('-a', { a: adminLoginAction });
        const actions = new Actions(source);

        service.get.and.returnValue(of({}));

        const effect = new AdminEffects(
          actions,
          service,
          configuration,
          localStorageService
        );

        effect.loginPullPermissions.subscribe(_ => {
          expect(service.get).toHaveBeenCalled();
        });
      });
    });
  });
});
