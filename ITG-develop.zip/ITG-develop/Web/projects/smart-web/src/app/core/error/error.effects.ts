import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Router } from '@angular/router';
import {
  setError,
  setHttpError,
  errorLogSaved,
  redirectToUserToConfirmPage,
  redirectToGalleryPage,
  redirectTo
} from './error.actions';
import { ApiService } from '../services/api.service';
import { tap, switchMap, catchError, map } from 'rxjs/operators';
import { ConfigurationService } from '../configuration/configuration.service';

@Injectable()
export class ErrorEffects {
  constructor(
    private actions$: Actions,
    private router: Router,
    private service: ApiService,
    private configuration: ConfigurationService
  ) {}

  onErrorRedirectToErrorPage = createEffect(
    () =>
      this.actions$.pipe(
        ofType(setError, setHttpError),
        tap(() => {
          this.router.navigate(['error']);
        })
      ),
    { dispatch: false }
  );

  onErrorSendErrorToApi = createEffect(() =>
    this.actions$.pipe(
      ofType(setError),
      switchMap(act =>
        this.service
          .post(`${this.configuration.settings.apiUrl}/log/error`, act.value)
          .pipe(map(payload => errorLogSaved({ errorId: payload.result })))
      )
    )
  );

  onUnconfirmed = createEffect(
    () =>
      this.actions$.pipe(
        ofType(redirectToUserToConfirmPage),
        tap(() => {
          this.router.navigate(['/login/user-to-confirm']);
        })
      ),
    { dispatch: false }
  );

  onDirectoryNotFound = createEffect(
    () =>
      this.actions$.pipe(
        ofType(redirectToGalleryPage),
        tap(() => {
          this.router.navigate(['/stamp/gallery']);
        })
      ),
    { dispatch: false }
  );

  onRedirect = createEffect(
    () =>
      this.actions$.pipe(
        ofType(redirectTo),
        tap(act => {
          this.router.navigate([act.url]);
        })
      ),
    { dispatch: false }
  );
}
