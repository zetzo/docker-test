import { createAction, props } from '@ngrx/store';
import { UserSettings } from '../models/user-settings.model';

export const authLogin = createAction('[Auth] Login');
export const authLogout = createAction('[Auth] Logout');

export const invalidCredencials = createAction('[Auth] Invalid Credencials');

export const setUserSettings = createAction(
  '[Settings] Set user Settings',
  props<{ value: UserSettings }>()
);
