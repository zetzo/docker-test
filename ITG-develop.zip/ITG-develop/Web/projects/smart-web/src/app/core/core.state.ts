import {
  ActionReducerMap,
  MetaReducer,
  createFeatureSelector
} from '@ngrx/store';
import { routerReducer, RouterReducerState } from '@ngrx/router-store';

import { environment } from '../../environments/environment';

import { initStateFromLocalStorage } from './meta-reducers/init-state-from-local-storage.reducer';
import { debug } from './meta-reducers/debug.reducer';
import { AuthState } from './auth/auth.models';
import { authReducer } from './auth/auth.reducer';
import { RouterStateUrl } from './router/router.state';
import { settingsReducer } from './settings/settings.reducer';
import { SettingsState } from './settings/settings.model';
import { AdminState } from './admin/admin.models';
import { adminReducer } from './admin/admin.reducer';
import { MatchingState } from './matching/matching.models';
import { matchingReducer } from './matching/matching.reducer';
import { clearState } from './meta-reducers/clear-state.reducer';
import { patternActionReducer } from './pattern-action/pattern-action.reducer';
import { PatternActionState } from './pattern-action/pattern-action.models';
import { ErrorState } from './error/error.models';
import { errorReducer } from './error/error.reducer';

export const reducers: ActionReducerMap<AppState> = {
  auth: authReducer,
  admin: adminReducer,
  matching: matchingReducer,
  settings: settingsReducer,
  router: routerReducer,
  patternAction: patternActionReducer,
  error: errorReducer
};

export const metaReducers: MetaReducer<AppState>[] = [
  initStateFromLocalStorage,
  clearState
];

if (!environment.production) {
  if (!environment.test) {
    metaReducers.unshift(debug);
  }
}

export const selectAuthState = createFeatureSelector<AppState, AuthState>(
  'auth'
);

export const selectAdminState = createFeatureSelector<AppState, AdminState>(
  'admin'
);

export const selectPatternActionState = createFeatureSelector<
  AppState,
  PatternActionState
>('patternAction');

export const selectMatchingState = createFeatureSelector<
  AppState,
  MatchingState
>('matching');

export const selectSettingsState = createFeatureSelector<
  AppState,
  SettingsState
>('settings');

export const selectRouterState = createFeatureSelector<
  AppState,
  RouterReducerState<RouterStateUrl>
>('router');

export const selectErrorState = createFeatureSelector<AppState, ErrorState>(
  'error'
);

export interface AppState {
  auth: AuthState;
  admin: AdminState;
  matching: MatchingState;
  settings: SettingsState;
  router: RouterReducerState<RouterStateUrl>;
  patternAction: PatternActionState;
  error: ErrorState;
}
