import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ofType, createEffect, Actions } from '@ngrx/effects';
import { tap, switchMap, concatMap } from 'rxjs/operators';
import { LocalStorageService } from '../local-storage/local-storage.service';
import { authLogin, authLogout, setUserSettings } from './auth.actions';
import { AuthenticationService } from './auth.service';
import { ApiService } from '../services/api.service';
import { ConfigurationService } from '../configuration/configuration.service';

export const AUTH_KEY = 'AUTH';

@Injectable()
export class AuthEffects {
  constructor(
    private actions$: Actions,
    private localStorageService: LocalStorageService,
    private router: Router,
    private authenticationService: AuthenticationService,
    private service: ApiService,
    private configuration: ConfigurationService
  ) {}

  login = createEffect(
    () =>
      this.actions$.pipe(
        ofType(authLogin),
        tap(() =>
          this.localStorageService.setItem(AUTH_KEY, { isAuthenticated: true })
        )
      ),
    { dispatch: false }
  );

  logout = createEffect(
    () =>
      this.actions$.pipe(
        ofType(authLogout),
        tap(() => {
          this.router.navigate(['/login']);
          this.localStorageService.setItem(AUTH_KEY, {
            isAuthenticated: false
          });
          this.authenticationService.logout();
        })
      ),
    { dispatch: false }
  );

  setSettings = createEffect(
    () =>
      this.actions$.pipe(
        ofType(setUserSettings),
        concatMap(action =>
          this.service.put(
            `${this.configuration.settings.apiUrl}/user/settings`,
            JSON.stringify(action.value)
          )
        )
      ),
    { dispatch: false }
  );
}
