import { Injectable, ErrorHandler } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { NotificationService } from '../notifications/notification.service';
import { TranslateService } from '@ngx-translate/core';
import { ErrorFacade } from './error.facade';
import { AppError } from '../models/error/app-error.model';

/** Application-wide error handler that adds a UI notification to the error handling
 * provided by the default Angular ErrorHandler.
 */
@Injectable()
export class AppErrorHandler extends ErrorHandler {
  constructor(
    private notificationsService: NotificationService,
    private readonly translate: TranslateService,
    private facade: ErrorFacade
  ) {
    super();
  }

  handleError(error: Error | HttpErrorResponse) {
    if (error instanceof HttpErrorResponse) {
      this.handleServiceError(error);
    } else {
      this.handleAppError(error);
    }
  }

  handleAppError(error: Error) {
    let displayMessage = 'An error occurred.';

    if (!environment.production) {
      displayMessage += ' See console for details.';
    }

    let routeUrl: string;

    this.facade.route$.subscribe(x => (routeUrl = x)).unsubscribe();

    let appError: AppError = {
      filename: error.name,
      message: error.message,
      stack: error.stack,
      route: routeUrl
    };

    this.notificationsService.error(displayMessage);
    this.facade.setError(appError);
    super.handleError(error);
  }

  handleServiceError(err: HttpErrorResponse) {
    /* ifology to be eliminated soon */

    if (err.status == 401) {
      this.notificationsService.error(
        this.translate.instant('itg.exception.message.unauthorized')
      );
      this.facade.dispatchLogoutOnUnauthorized();
    }

    if (err.status == 403) {
      this.notificationsService.error(
        this.translate.instant('itg.exception.message.missingpermissions')
      );
      this.facade.setHttpError(err, err.error.exceptionId || null);
      return;
    }

    if (err.status == 400 && err.error.customErrorCode == 1003) {
      this.facade.setHttpError(err, null);
      this.facade.navigateToUnconfirmedPage();
      return;
    }

    if (err.status == 400 && err.error.customErrorCode == 1002) {
      this.notificationsService.error(
        this.translate.instant('itg.exception.message.incorrectcredencials')
      );
      this.facade.navigateTo('/login');
      return;
    }

    if (err.status == 404 && err.error.customErrorCode == 1006) {
      return;
    }

    if (err.error.customErrorCode == 1005) {
      this.notificationsService.warn(
        this.translate.instant('itg.exception.message.directorynotexist')
      );
      this.facade.navigateToGalleryPage();
      return;
    }

    this.notificationsService.error(
      this.translate.instant('itg.exception.message.erroroccurred')
    );

    this.facade.setHttpError(err, err.error.exceptionId || null);
  }
}
