import { adminReducer, initialState } from './admin.reducer';
import { action } from './admin.actions';
import { Role } from '../models/role/role.model';
import { AdminState } from './admin.models';
import { UserToDisplay } from '../models/user-to-display.model';

const roles: Role[] = [
  {
    id: 1,
    name: 'test_role',
    description: 'test role',
    permissions: [
      {
        id: 1,
        name: 'test',
        description: 'test permission'
      }
    ],
    isActive: true
  },
  {
    id: 2,
    name: 'test_role2',
    description: 'test role2',
    permissions: [
      {
        id: 1,
        name: 'test',
        description: 'test permission'
      }
    ],
    isActive: true
  }
];

const users: UserToDisplay[] = [
  {
    username: 'test@ibm.com',
    firstName: 'test',
    lastName: 'test',
    roles: [
      {
        id: 1,
        name: 'test_role',
        description: 'test role',
        permissions: [
          {
            id: 1,
            name: 'test',
            description: 'test permission'
          }
        ],
        isActive: true
      }
    ],
    isAdmin: true,
    isConfirmed: true
  },
  {
    username: 'test2@ibm.com',
    firstName: 'test',
    lastName: 'test',
    roles: [
      {
        id: 1,
        name: 'test_role',
        description: 'test role',
        permissions: [
          {
            id: 1,
            name: 'test',
            description: 'test permission'
          }
        ],
        isActive: true
      }
    ],
    isAdmin: true,
    isConfirmed: true
  }
];

const INITIAL_STATE: AdminState = {
  hasAdminPermission: false,
  logs: null,
  userList: users,
  roleList: roles,
  permissionList: [],
  loaded: false
};

describe('AdminReducer', () => {
  describe('On Init', () => {
    it('should return the default state', () => {
      const action = {} as any;
      const state = adminReducer(undefined, action);

      expect(state).toBe(initialState);
    });
  });

  describe('On Admin Login', () => {
    it('has admin permission should be set to true', () => {
      const _action = action.adminLogin({ value: true });
      const state = adminReducer(undefined, _action);

      expect(state.hasAdminPermission).toEqual(true);
    });
  });

  describe('On Admin Logout', () => {
    it('store items should be removed', () => {
      const _action = action.adminLogout();
      const state = adminReducer(undefined, _action);

      expect(state.hasAdminPermission).toEqual(false);
      expect(state.userList).toEqual([]);
      expect(state.roleList).toEqual([]);
      expect(state.permissionList).toEqual([]);
      expect(state.logs).toEqual(null);
    });
  });

  describe('On Role Update Success', () => {
    it('role should be updated in store', () => {
      let updatedRole: Role = {
        id: 2,
        name: 'role_changed_name',
        description: 'test role2',
        permissions: [
          {
            id: 1,
            name: 'test',
            description: 'test permission'
          }
        ],
        isActive: true
      };

      const _action = action.roleUpdateSuccess({ role: updatedRole });
      const state = adminReducer(INITIAL_STATE, _action);

      expect(state.roleList[1].name).toEqual('role_changed_name');
    });
  });

  describe('On User Update Success', () => {
    it('user should be updated in store', () => {
      let updatedUser: UserToDisplay = {
        username: 'test@ibm.com',
        firstName: 'FirstName',
        lastName: 'LastName',
        roles: [
          {
            id: 1,
            name: 'test_role',
            description: 'test role',
            permissions: [
              {
                id: 1,
                name: 'test',
                description: 'test permission'
              }
            ],
            isActive: true
          }
        ],
        isAdmin: true,
        isConfirmed: true
      };

      const _action = action.userUpdateSuccess({ user: updatedUser });
      const state = adminReducer(INITIAL_STATE, _action);

      expect(state.userList[0].firstName).toEqual('FirstName');
      expect(state.userList[0].lastName).toEqual('LastName');
    });
  });
});
