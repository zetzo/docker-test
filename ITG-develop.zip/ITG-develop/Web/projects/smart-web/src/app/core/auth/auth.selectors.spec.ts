import { selectAuth, selectIsAuthenticated } from './auth.selectors';
import { AppState } from '../core.state';
import { AuthState } from './auth.models';
import { User } from '../models/user.model';

describe('Auth Selectors', () => {
  // it('selectIsAuthenticated', () => {
  //   const state = createAuthState();
  //   expect(selectIsAuthenticated(state)).toBe(false);
  // });
});

function createAuthState() {
  return {
    auth: {
      isAuthenticated: false
    },
    user: undefined
  };
}
