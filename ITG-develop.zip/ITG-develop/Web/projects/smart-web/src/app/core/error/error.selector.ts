import { createSelector } from '@ngrx/store';
import { selectErrorState } from '../core.state';
import { ErrorState } from './error.models';

export const selectError = createSelector(
  selectErrorState,
  (state: ErrorState) => state.error
);

export const selectHttpError = createSelector(
  selectErrorState,
  (state: ErrorState) => state.httpError
);

export const selectErrorId = createSelector(
  selectErrorState,
  (state: ErrorState) => state.errorId
);
