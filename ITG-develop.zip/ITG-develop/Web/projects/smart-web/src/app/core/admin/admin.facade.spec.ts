import { AppState } from '../core.state';
import { Store, StoreModule } from '@ngrx/store';
import { AdminFacade } from './admin.facade';
import { TestBed } from '@angular/core/testing';
import { ApiService } from '../services/api.service';
import { select } from './admin.selectors';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';

describe('AdminFacade', () => {
  let store: Store<AppState>;
  let facade: AdminFacade;
  let apiService: jasmine.SpyObj<ApiService>;
  const httpClientSpy: jasmine.SpyObj<HttpClient> = jasmine.createSpyObj(
    'httpClient',
    ['get']
  );

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Store, ApiService, { provide: HttpClient, useValue: {} }],
      imports: [StoreModule.forRoot({}), HttpClientTestingModule]
    });

    store = TestBed.get(Store);
    spyOn(store, 'dispatch');
    spyOn(store, 'select');

    facade = new AdminFacade(store);
  });

  describe('On init', () => {
    it('should be created', () => {
      expect(facade).toBeTruthy();
    });
  });

  describe('On Users Get', () => {
    it('store users selector should be called', () => {
      var test = facade.users$;
      expect(store.select).toHaveBeenCalledWith(select.users);
    });
  });

  describe('On Roles Get', () => {
    it('store roles selector should be called', () => {
      var test = facade.roles$;
      expect(store.select).toHaveBeenCalledWith(select.roles);
    });
  });

  describe('On Permissions Get', () => {
    it('store permissions selector should be called', () => {
      var test = facade.permissions$;
      expect(store.select).toHaveBeenCalledWith(select.permissions);
    });
  });

  describe('On Log Entries Retrieve', () => {
    it('store retrieve action should be dispatched', () => {
      facade.getLogEntriesPaged(1, 20);
      expect(store.dispatch).toHaveBeenCalledWith({
        pageIndex: 1,
        pageSize: 20,
        type: '[Admin] Change Log Requested'
      });
    });
  });
});
