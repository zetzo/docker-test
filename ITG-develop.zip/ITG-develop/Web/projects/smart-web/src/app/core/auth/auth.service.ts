import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { User } from '../models/user.model';
import { ApiService } from '../services/api.service';
import { NotificationService } from '../notifications/notification.service';
import { Router } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { ConfigurationService } from '../configuration/configuration.service';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  constructor(
    private service: ApiService,
    private notification: NotificationService,
    private router: Router,
    private configuration: ConfigurationService,
    @Inject(DOCUMENT) private document: Document
  ) {
    const user = JSON.parse(localStorage.getItem('currentUser'));

    this.currentUserSubject = new BehaviorSubject<User>(
      JSON.parse(localStorage.getItem('currentUser'))
    );
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }

  login(login: string, password: string): Observable<User> {
    return this.service
      .post(`${this.configuration.settings.apiUrl}/user/authenticate`, {
        login,
        password
      })
      .pipe(
        map(payload => {
          return this.saveUserToStorage(payload.result);
        })
      );
  }

  requestLoginWithIbmId() {
    this.service
      .post(`${this.configuration.settings.apiUrl}/user/loginrequest`)
      .subscribe(response => {
        this.document.location.href = `${response.result}&redirect_uri=${this.configuration.settings.apiUrl}/user/login`;
      });
  }

  logout() {
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }

  saveUserToStorage(data: any) {
    if (data && data.token) {
      localStorage.setItem('currentUser', JSON.stringify(data));
      this.currentUserSubject.next(data);
    }
    return data;
  }
}
