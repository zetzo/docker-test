import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppState } from '../core.state';
import { Observable, of } from 'rxjs';
import { selectError, selectHttpError, selectErrorId } from './error.selector';
import { selectStateUrl } from '../../core/router/router.selector';
import { HttpErrorResponse } from '@angular/common/http';
import {
  setError,
  setHttpError,
  cleanErrors,
  redirectToUserToConfirmPage,
  redirectToGalleryPage,
  redirectTo
} from './error.actions';
import { AppError } from '../models/error/app-error.model';
import { Router } from '@angular/router';
import { authLogout, invalidCredencials } from '../auth/auth.actions';
import { adminLogout } from '../admin/admin.actions';

@Injectable({ providedIn: 'root' })
export class ErrorFacade {
  constructor(private store: Store<AppState>) {}

  get error$(): Observable<AppError> {
    return this.store.select(selectError);
  }

  get httpError$(): Observable<HttpErrorResponse> {
    return this.store.select(selectHttpError);
  }

  get errorId$(): Observable<string> {
    return this.store.select(selectErrorId);
  }

  get route$(): Observable<string> {
    return this.store.select(selectStateUrl);
  }

  setError(error: AppError) {
    this.store.dispatch(setError({ value: error }));
  }

  setHttpError(error: HttpErrorResponse, exId: string) {
    this.store.dispatch(setHttpError({ value: error, exceptionId: exId }));
  }

  cleanErrors() {
    this.store.dispatch(cleanErrors());
  }

  navigateToUnconfirmedPage() {
    this.store.dispatch(redirectToUserToConfirmPage());
  }

  navigateToGalleryPage() {
    this.store.dispatch(redirectToGalleryPage());
  }

  navigateTo(url: string) {
    this.store.dispatch(invalidCredencials());
    this.store.dispatch(redirectTo({ url: url }));
  }

  dispatchLogoutOnUnauthorized() {
    this.store.dispatch(authLogout());
    this.store.dispatch(adminLogout());
  }
}
