import { Role } from '../models/role/role.model';
import { Permission } from '../models/role/permission.model';
import { UserToDisplay } from '../models/user-to-display.model';
import { PagedResult } from '../models/common/page-result.model';
import { LogEntry } from '../models/changes/log.model';
import { FileElement } from '../models/folder-structure/file-element.model';

export interface AdminState {
  hasAdminPermission: boolean;
  logs: PagedResult<LogEntry>;
  userList: UserToDisplay[];
  roleList: Role[];
  directories: FileElement[];
  permissionList: Permission[];
  loaded: boolean;
  fileUploading: boolean;
  fileUploadingError: String;
}
