# echo 'postgres:11.4'
# docker save -o /f/SRC/ITG/images/postgres.tar postgres:11.4
# echo 'redis:5.0.5'
# docker save -o /f/SRC/ITG/images/redis.tar redis:5.0.5
# echo 'mongo:4.2'
# docker save -o /f/SRC/ITG/images/mongo.tar mongo:4.2
# echo 'rabbitmq:3.7.18-management'
# docker save -o /f/SRC/ITG/images/rabbitmq.tar rabbitmq:3.7.18-management
# echo 'node:12.2.0'
# docker save -o /f/SRC/ITG/images/node.tar node:12.2.0
# echo 'nginx:1.17.6-alpine'
# docker save -o /f/SRC/ITG/images/nginx.tar nginx:1.17.6-alpine
# echo 'jjanzic/docker-python3-opencv'
# docker save -o /f/SRC/ITG/images/python.tar jjanzic/docker-python3-opencv
# echo 'mcr.microsoft.com/dotnet/core/aspnet:2.2'
# docker save -o /f/SRC/ITG/images/aspnet.tar mcr.microsoft.com/dotnet/core/aspnet:2.2
# echo 'mcr.microsoft.com/dotnet/core/sdk:2.2'
# docker save -o /f/SRC/ITG/images/sdk.tar mcr.microsoft.com/dotnet/core/sdk:2.2
# echo 'microsoft/dotnet:2.2-runtime-stretch-slim'
# docker save -o /f/SRC/ITG/images/runtime-stretch-slim.tar microsoft/dotnet:2.2-runtime-stretch-slim 
# echo 'microsoft/dotnet:2.2-sdk-stretch'
# docker save -o /f/SRC/ITG/images/sdk-stretch-slim.tar microsoft/dotnet:2.2-sdk-stretch
# echo 'ubuntu:latest'
# docker save -o /f/SRC/ITG/images/my_ubuntu.tar my_ubuntu:latest


echo 'DOCKER_HOST=tcp://plkrcon38p1:2376 DOCKER_TLS_VERIFY=1 DOCKER_CERT_PATH=~/.docker/itg/'
export DOCKER_HOST=tcp://plkrcon38p1:2376 DOCKER_TLS_VERIFY=1 DOCKER_CERT_PATH=~/.docker/itg/


echo 'start loading...'
echo 'load /f/SRC/ITG/images/postgres.tar'
docker load -i /f/SRC/ITG/images/postgres.tar
echo 'load /f/SRC/ITG/images/redis.tar'
docker load -i /f/SRC/ITG/images/redis.tar
echo 'load /f/SRC/ITG/images/mongo.tar'
docker load -i /f/SRC/ITG/images/mongo.tar
echo 'load /f/SRC/ITG/images/rabbitmq.tar'
docker load -i /f/SRC/ITG/images/rabbitmq.tar
echo 'load /f/SRC/ITG/images/node.tar'
docker load -i /f/SRC/ITG/images/node.tar
echo 'load /f/SRC/ITG/images/nginx.tar'
docker load -i /f/SRC/ITG/images/nginx.tar
echo 'load /f/SRC/ITG/images/python.tar'
docker load -i /f/SRC/ITG/images/python.tar
echo 'load /f/SRC/ITG/images/aspnet.tar'
docker load -i /f/SRC/ITG/images/aspnet.tar
echo 'load /f/SRC/ITG/images/sdk.tar'
docker load -i /f/SRC/ITG/images/sdk.tar
echo 'load /f/SRC/ITG/images/runtime-stretch-slim.tar'
docker load -i /f/SRC/ITG/images/runtime-stretch-slim.tar
echo 'load /f/SRC/ITG/images/sdk-stretch-slim.tar'
docker load -i /f/SRC/ITG/images/sdk-stretch-slim.tar
echo 'load /f/SRC/ITG/images/ubuntu.tar'
docker load -i /f/SRC/ITG/images/my_ubuntu.tar
echo 'completed!'

