> ### Process example.

#### Document

![Invoice](img/good_invoice.png)

#### Good stamp

![Invoice](img/good_stamp.png)

#### Bad stamp

![Invoice](img/bad_stamp.png)

#### Matching Result with good stamp

![GoodResult](img/good_result.png)

#### Matching Result with bad stamp

![GoodResult](img/bad_result.png)

---

### Explanation

All **red dots** on images are key points created by one algorthim and matched between **pattern** and **invoice** by second algorithm **green lines**.

It is not important where the stamp is or it is rotated or not.

Result is a number which represents the smallest distance between key points.

What number it gonna produce depends on 2 conditions

1. Quality of images.
2. Algorithm settings.
