# Architecture

## Introduction

---

#### Smart Application contains **3** modules

1. **Web Application** Module.
2. **Ingest** Module
3. **Matching** Module.

---

## Web Application Module

### Login Screen

![GoodResult](img/login.png)

#### Using **login** button user can use authentication and authorization in application itself, Admin can add user and roles.

---

#### Sign in with IBMid

![GoodResult](img/login_ibm.png)

#### Authentication and authorization is managed by IBM portal.

---

### Main/About Screen

![GoodResult](img/about.png)

#### After logging user gets about page which is a default page. About contains 2 tables.

##### 1. Message table

![GoodResult](img/message_table.png)

Administrator can add messages to notify users about same adintional info related to Smart Application or process that involves in.

##### 2. Version Table

![GoodResult](img/version_table.png)

> version 0.8.0 Dec 4, 2019

> For the client perspactive important are first two numbers in e.g 0.8. First digit is major number and second one is minor.
> means that is a prerelease version called sometime alpha or beta,
> versions bigger then 1.0 are called full versions. The tree nodes below are informating about functionality version provides. After releasing full version e.g 1.3.230. It states version 1 fix/change 3 build number 230.

### Gallery Screen

Gallery Page contains table with pattern minatures. Table can be filtered, paged, items resized.

![GoodResult](img/gallery.png)

#### Gallery Menu

Gallery Menu which is also called hamburger menu contains scrollbar, search input and action buttons. Using scrollbar user can specify how many patterns can be in one row of patterns table (7-12).

![GoodResult](img/gallery_menu.png)
Search input is used for filtering, it consinsts of five elements:

- (1) input field
- (2) label shows what attribute is filtered
- (3) filter icon which allow to choose attribute to filter
- (4) plus icon to add filter
- (5) search icon to execute filters

To add filter insert value in input field (1), select attribute to be filtered (3), click on plus icon button (4).
Multiple filters can be added simultaneously.

![GoodResult](img/gallery_menu_example.png)

There are three types of filters:

- ordinary comparision
- like comparision
- range

To perform ordinary comparision, just enter desired value.
To act as like comparer add '%' to any place in looking phrase, application will recognize it
and will search for records comply with phrase.
To find certain range enter in input field values limited with semicolon eg 'LS-40000;LS-50000',
application will find all items that in range between 40000 to 50000.

Patterns are created from source documents, these documents are held on storage for 48 hours for user manual intervention, such as pattern edit or change source document.
After that time documents are automatically removed from storage.
Three dots (number 6) were created to indicate how much time left to remove source documents.
Dots in gallery menu act as filter, when you click on each new filter will be added, example - green dot was clicked:

![GoodResult](img/gallery_menu_green_dot.png)
This implies application will find all pattern where directory is max 12 hours old, this also mean that pattern was created at this time.

Dots are assigned to following values:

- green - means directory has been created between 0 and 12 ago, so at least 36 hours left to remove
- yellow - means directory has been created between 12 and 24 ago, then 24 hours left to remove
- red - means directory has been created between 24 and 46 ago

#### Gallery Item

Dotted Button is used for post process actions.

![GoodResult](img/gallery_item.png)

After clicking user gets screen below:

![GoodResult](img/gallery_actions.png)

Possible Actions are:

1. Extract specific page.
2. Adjust pattern cutting.
3. Add different pattern file.

When user choose page number and clicks **Extract pattern** button, **ingest module** extracts selected page from contract document and take pattern form that page.

### Matching Screen

![Matching](img/matching_screen.png)

#### Matching Result Table Filter

Filter bar is located on the top of page, it consists of four elements: (1) input field, (2) label indicate which field is filtered, (3) filter icon to choose field to filter, (4) search icon to execute filter.
![Matching](img/matching_result_filter.png)

#### Matching Result Table

The table shows the matching results of pattern comparision to document stamp, it presents fallowing figures:
date created,
contract number,
document file name,
matching score (ingest module compare stamps and gives certain number),
matching score description (descriptive result)

### Administrator Screen

![Administrator](img/administrator.png)

Administator tab consists of four section:

- User section - manage user roles, confirm and disable
- Roles section - give ability to compose role accesses
- Changes section - provides an insight to changes made to certain entities
- Messages section - allow to add message to main screen

#### User Screen

![Administrator](img/administrator_users_main.png)

User screen contains table with user list, table presents basic information such as:

- Username (typically it is an email)
- Firstname
- Lastname
- User roles list
- Is Admin (shows if user has admin privileges)
- Is Confirmed (indicate if user is confirmed by administrator/supervisor)

On right side are visible three buttons related to:

- (1) display user details
- (2) edit user data, user roles
- (3) confirm or disable user

To display user data click on Details button:
![Administrator](img/administrator_users_details.png)

To edit user data, manage user roles click on Edit button, following window appear:
![Administrator](img/administrator_users_edit.png)

To confirm or disable user click on respective button, user signing in by IBM id
has to be confirmed in order to use application. Confirmation or disable can be done by privilige user.

#### Roles screen

![Administrator](img/administrator_roles.png)

Roles screen list all roles as table with following headers:

- Role name
- Role description
- Permission list
- Role activity

Role can be either edited or added,
to edit certain role click Edit button on the right side:
![Administrator](img/administrator_roles_edit.png)

To add new role click on Add new role button on the bottom of the table.

#### Changes screen

![Administrator](img/administrator_changes.png)

Changes provides an insight to changes made to entities like users, roles.
Table shows following information:

- Created - when change was made
- Entity type - what entity has been modified
- Action type - describe what action has taken place
- Action result - describe result of the action, i.e. action was executed successfully or failed
- Related Object Id - identifier of modified object
- Message - shows which object attibutes has been modified and value difference
- User Id - user who performed change

#### Messages screen

![Administrator](img/administrator_messages.png)

Administrator is allow to create message for user, such message will be presented on main screen.

# Smart.Ingest Module

## Extract Patterns flow:

![Ingest](img/smart_ingest.png)

## Matching flow:

![IMatching](img/smart_matching.png)
