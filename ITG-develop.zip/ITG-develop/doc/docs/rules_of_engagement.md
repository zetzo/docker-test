# Rules of engagement

## Image Pattern not properly exported

Some of images cannot be exported because of poor image quality.
In that case warning image will be inserted into database. User
have to fix it. Please download [Paint.Net](https://1drv.ms/u/s!AnD_K7j-17Evq2fYkYt3hQAqIRxB?e=FDdbcG)
Unzip folder and run app using PaintDotNet.exe

![warningimage](img/warning_image.png)

## Fixing warning image pattern

- Please go to image

![warningdetails](img/warning_details.png)

- Click "Directory" button

![warningdirectory](img/warning_directory.png)

- Select image with full page view of orginal document and click download

![warningdirectory](img/warning_crop_pattern.png)

- Start Paint.Net with downloaded image

![warningdirectory](img/paintnet_open_file.png)

- In Paint.Net use Rectangle Select to cut out pattern

![warningdirectory](img/paintnet_rectangle_select.png)

- Use Ctrl+X shortcut to cut image and go to file new, click ok

![warningdirectory](img/paintnet_cut_out.png)

- Use Ctrl+V to copy image from memory

![warningdirectory](img/paintnet_cut_out2.png)

- Please save image with settings showed in screen below

![warningdirectory](img/paintnet_save_image.png)

## Upload fixed image

- Go to image
- Click edit,
- In next screen click 'Select stamp pattern document'
- Upload image fixed in Paint.Net

![warningdirectory](img/warning_upload_fixed.png)

## Retrying pattern export

There is possibility that patterns like those below could be extracted also.
Process must be restarted with different settings. IBM team should be informed
about contract ids that are possible to extract, when such list is provided team will setup retrying process.

![warningdirectory](img/patterns_possible_export.png)

Pattern for LS-35732 Contract successfully extracted

![warningdirectory](img/patterns_possible_export_success.png)

Now we have to set it up as pattern. Task will update new pattern in the next run.

![warningdirectory](img/patterns_possible_export_success2.png)

Correct Pattern in gallery

![warningdirectory](img/patterns_possible_export_success_gallery.png)

## Pattern contrast/brightness fixing

- Please download Image from Pattern directory, don't cut it out form PDF.
- Open Pattern in Paint.Net
  ![warningdirectory](img/pattern_ajustment.png)

- Go to Ajustments->Autolevel

![warningdirectory](img/pattern_ajustment_autolevel.png)

- Change contrast, save file on disk and upload to Smart

![warningdirectory](img/pattern_ajustment_autolevel_contrast.png)
