# Introduction

### Smart Application

#### Purpose:

#### Match Stamps taken from contract documents with stamps from closing documents.

| Version | Date       |
| ------- | ---------- |
| _1.0.2_ | 2020-01-03 |
