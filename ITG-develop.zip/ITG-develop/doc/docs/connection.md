#IBM-ITG Smart Connection

![Server](img/russian_server.png)

## Explanation:

### Two flows:

#### Frist flow

Using powershell scripts documents will be send to IBM sftp server and processed by Smart Application.
There will be 2 scripts one for closing documents one for contracts. Scripts will be scheduled in Windows scheduler.

#### Second flow

Scripts will access Smart Client API. API will be REST service with api key. Connection is going to be made by HTTPS.
Script will get scoring result and depeneding on decision tree will move documents between status folders.
